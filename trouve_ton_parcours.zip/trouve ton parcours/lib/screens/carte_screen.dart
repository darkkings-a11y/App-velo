import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:geolocator/geolocator.dart';
import 'package:latlong2/latlong.dart';
import '../models/parcours.dart';
import '../widgets/profil_altitude.dart';

class CarteScreen extends StatefulWidget {
  final Parcours parcours;

  const CarteScreen({super.key, required this.parcours});

  @override
  State<CarteScreen> createState() => _CarteScreenState();
}

class _CarteScreenState extends State<CarteScreen> {
  static const Color _vert = Color(0xFF00E676);
  static final Distance _dist = Distance(roundResult: false);

  final MapController _map = MapController();
  StreamSubscription<Position>? _sub;

  LatLng? _position;
  double _cap = 0;
  bool _gpsActif = false;
  bool _suivre = false;
  double? _ecartM;

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }

  void _message(String texte) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(texte)));
  }

  // ---------------- GPS en direct ----------------

  Future<void> _boutonGps() async {
    if (!_gpsActif) {
      await _demarrerGps();
      return;
    }
    if (!_suivre) {
      setState(() => _suivre = true);
      if (_position != null) {
        _map.move(_position!, math.max(_map.camera.zoom, 15));
      }
      return;
    }
    _arreterGps();
  }

  Future<void> _demarrerGps() async {
    final actif = await Geolocator.isLocationServiceEnabled();
    if (!actif) {
      _message('Active la localisation de ton téléphone.');
      return;
    }
    var perm = await Geolocator.checkPermission();
    if (perm == LocationPermission.denied) {
      perm = await Geolocator.requestPermission();
    }
    if (perm == LocationPermission.denied || perm == LocationPermission.deniedForever) {
      _message('Autorisation de localisation refusée.');
      return;
    }

    setState(() {
      _gpsActif = true;
      _suivre = true;
    });

    _sub = Geolocator.getPositionStream(
      locationSettings: const LocationSettings(
        accuracy: LocationAccuracy.high,
        distanceFilter: 5,
      ),
    ).listen(_surPosition, onError: (_) => _message('Signal GPS perdu.'));
  }

  void _arreterGps() {
    _sub?.cancel();
    _sub = null;
    setState(() {
      _gpsActif = false;
      _suivre = false;
      _position = null;
      _ecartM = null;
    });
  }

  void _surPosition(Position p) {
    final pos = LatLng(p.latitude, p.longitude);
    double ecart = double.infinity;
    for (final pt in widget.parcours.traceGPS) {
      final d = _dist.as(LengthUnit.Meter, pos, pt);
      if (d < ecart) ecart = d;
    }
    setState(() {
      _position = pos;
      _cap = p.heading >= 0 ? p.heading : 0;
      _ecartM = ecart;
    });
    if (_suivre) {
      _map.move(pos, math.max(_map.camera.zoom, 15));
    }
  }

  // ---------------- Carte ----------------

  MapOptions _optionsCarte(double hauteurEcran) {
    final trace = widget.parcours.traceGPS;
    void surMouvement(MapPosition pos, bool aGeste) {
      if (aGeste && _suivre) setState(() => _suivre = false);
    }

    if (trace.length > 1) {
      return MapOptions(
        initialCameraFit: CameraFit.bounds(
          bounds: LatLngBounds.fromPoints(trace),
          padding: EdgeInsets.fromLTRB(40, 140, 40, hauteurEcran * 0.45),
        ),
        onPositionChanged: surMouvement,
      );
    }
    return MapOptions(
      initialCenter: trace.isNotEmpty ? trace.first : const LatLng(45.75, 4.85),
      initialZoom: 12,
      onPositionChanged: surMouvement,
    );
  }

  void _voirToutLeParcours(double hauteurEcran) {
    final trace = widget.parcours.traceGPS;
    if (trace.length < 2) return;
    _map.fitCamera(CameraFit.bounds(
      bounds: LatLngBounds.fromPoints(trace),
      padding: EdgeInsets.fromLTRB(40, 140, 40, hauteurEcran * 0.45),
    ));
    if (_suivre) setState(() => _suivre = false);
  }

  List<Marker> _marqueurs() {
    final p = widget.parcours;
    final marqueurs = <Marker>[];

    for (int i = 0; i < p.etapes.length; i++) {
      final e = p.etapes[i];
      marqueurs.add(Marker(
        point: e.position,
        width: 220,
        height: 70,
        child: _EtapeMarker(nom: e.nom, enHautADroite: i % 2 == 0),
      ));
    }

    if (p.traceGPS.isNotEmpty) {
      marqueurs.add(Marker(
        point: p.traceGPS.first,
        width: 34,
        height: 34,
        child: Container(
          decoration: BoxDecoration(
            color: _vert,
            shape: BoxShape.circle,
            border: Border.all(color: Colors.white, width: 3),
          ),
          child: const Icon(Icons.flag, color: Colors.black, size: 16),
        ),
      ));
    }

    if (_position != null) {
      marqueurs.add(Marker(
        point: _position!,
        width: 44,
        height: 44,
        child: Transform.rotate(
          angle: _cap * math.pi / 180,
          child: Container(
            decoration: BoxDecoration(
              color: const Color(0xFF2979FF),
              shape: BoxShape.circle,
              border: Border.all(color: Colors.white, width: 3),
            ),
            child: const Icon(Icons.navigation, color: Colors.white, size: 22),
          ),
        ),
      ));
    }
    return marqueurs;
  }

  @override
  Widget build(BuildContext context) {
    final p = widget.parcours;
    final trace = p.traceGPS;
    final hauteur = MediaQuery.of(context).size.height;
    final haut = MediaQuery.of(context).padding.top;

    IconData iconeGps = Icons.my_location;
    Color couleurGps = Colors.white;
    if (_gpsActif && _suivre) {
      couleurGps = _vert;
    } else if (_gpsActif) {
      iconeGps = Icons.location_searching;
      couleurGps = const Color(0xFF2979FF);
    }

    return Scaffold(
      backgroundColor: const Color(0xFF0B0F0D),
      body: Stack(
        children: [
          FlutterMap(
            mapController: _map,
            options: _optionsCarte(hauteur),
            children: [
              // Fond sombre sans noms (les noms des villes sont ajoutés par l'appli)
              TileLayer(
                urlTemplate: 'https://{s}.basemaps.cartocdn.com/dark_nolabels/{z}/{x}/{y}.png',
                subdomains: const ['a', 'b', 'c', 'd'],
                userAgentPackageName: 'com.example.trouve_ton_parcours',
              ),
              if (trace.isNotEmpty)
                PolylineLayer(
                  polylines: [
                    Polyline(points: trace, color: const Color(0x5500E676), strokeWidth: 12),
                    Polyline(points: trace, color: _vert, strokeWidth: 5),
                  ],
                ),
              MarkerLayer(markers: _marqueurs()),
            ],
          ),

          // Titre
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            child: Container(
              padding: EdgeInsets.fromLTRB(8, haut + 6, 16, 24),
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Color(0xDD000000), Color(0x00000000)],
                ),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  IconButton(
                    icon: const Icon(Icons.arrow_back, color: Colors.white),
                    onPressed: () => Navigator.pop(context),
                  ),
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.only(top: 8),
                      child: Text(
                        p.titre,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),

          // Alerte hors parcours
          if (_ecartM != null && _ecartM! > 120)
            Positioned(
              top: haut + 84,
              left: 16,
              right: 16,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                decoration: BoxDecoration(
                  color: const Color(0xEEFF6D00),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  'Hors parcours : à ${_ecartM!.round()} m du tracé',
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                ),
              ),
            ),

          // Boutons ronds à droite
          Positioned(
            right: 14,
            top: haut + 150,
            child: Column(
              children: [
                _BoutonRond(
                  icone: iconeGps,
                  couleur: couleurGps,
                  onTap: _boutonGps,
                ),
                const SizedBox(height: 12),
                _BoutonRond(
                  icone: Icons.zoom_out_map,
                  couleur: Colors.white,
                  onTap: () => _voirToutLeParcours(hauteur),
                ),
              ],
            ),
          ),

          // Panneau du bas
          DraggableScrollableSheet(
            initialChildSize: 0.40,
            minChildSize: 0.40,
            maxChildSize: 0.90,
            builder: (context, scroll) {
              return Container(
                decoration: const BoxDecoration(
                  color: Color(0xFF111614),
                  borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
                  boxShadow: [BoxShadow(color: Colors.black54, blurRadius: 12)],
                ),
                child: ListView(
                  controller: scroll,
                  padding: const EdgeInsets.fromLTRB(16, 10, 16, 24),
                  children: [
                    Center(
                      child: Container(
                        width: 40,
                        height: 4,
                        decoration: BoxDecoration(
                          color: Colors.white24,
                          borderRadius: BorderRadius.circular(2),
                        ),
                      ),
                    ),
                    const SizedBox(height: 14),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        _stat('Distance totale', '${p.distanceKm.toStringAsFixed(1)} km', Colors.white),
                        _stat('Dénivelé positif', '+${p.denivelePos} m', _vert),
                        _stat('Dénivelé négatif', '-${p.deniveleNeg} m', const Color(0xFFFF8A65)),
                      ],
                    ),
                    const SizedBox(height: 14),
                    SizedBox(
                      height: 130,
                      child: ProfilAltitude(
                        distancesKm: p.distancesKm,
                        altitudes: p.altitudes,
                        repereKm: p.etapes.map((e) => e.distanceKm).toList(),
                      ),
                    ),
                    const SizedBox(height: 14),
                    SizedBox(
                      height: 50,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF2E9E4F),
                          foregroundColor: Colors.white,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(25)),
                        ),
                        onPressed: () {
                          _message('Parcours enregistré dans vos favoris !');
                        },
                        child: const Text(
                          'Enregistrer',
                          style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
                        ),
                      ),
                    ),
                    if (p.troncons.isNotEmpty) ...[
                      const SizedBox(height: 22),
                      const Text(
                        'Détail par tronçon',
                        style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 6),
                      ...p.troncons.map(_ligneTroncon),
                    ],
                    const SizedBox(height: 16),
                    const Text(
                      '© OpenStreetMap contributors © CARTO',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.white30, fontSize: 10),
                    ),
                  ],
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _stat(String label, String valeur, Color couleur) {
    return Column(
      children: [
        Text(label, style: const TextStyle(color: Colors.white60, fontSize: 11)),
        const SizedBox(height: 4),
        Text(valeur, style: TextStyle(color: couleur, fontSize: 18, fontWeight: FontWeight.bold)),
      ],
    );
  }

  Widget _ligneTroncon(TronconParcours t) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 10),
      decoration: const BoxDecoration(
        border: Border(bottom: BorderSide(color: Colors.white12)),
      ),
      child: Row(
        children: [
          Expanded(
            child: Text(
              '${t.depart} → ${t.arrivee}',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(color: Colors.white, fontSize: 14),
            ),
          ),
          Text('${t.distanceKm.toStringAsFixed(1)} km',
              style: const TextStyle(color: Colors.white70, fontSize: 13)),
          const SizedBox(width: 12),
          Text('+${t.denivelePos} m', style: const TextStyle(color: _vert, fontSize: 13)),
          const SizedBox(width: 8),
          Text('-${t.deniveleNeg} m', style: const TextStyle(color: Color(0xFFFF8A65), fontSize: 13)),
        ],
      ),
    );
  }
}

class _BoutonRond extends StatelessWidget {
  final IconData icone;
  final Color couleur;
  final VoidCallback onTap;

  const _BoutonRond({required this.icone, required this.couleur, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: const Color(0xEE1B211E),
      shape: const CircleBorder(side: BorderSide(color: Colors.white24)),
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Icon(icone, color: couleur, size: 24),
        ),
      ),
    );
  }
}

/// Point sur la ville + trait + étiquette avec le nom.
class _EtapeMarker extends StatelessWidget {
  final String nom;
  final bool enHautADroite;

  const _EtapeMarker({required this.nom, required this.enHautADroite});

  @override
  Widget build(BuildContext context) {
    final etiquette = Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
      decoration: BoxDecoration(
        color: const Color(0xDD000000),
        borderRadius: BorderRadius.circular(6),
        border: Border.all(color: const Color(0x6600E676)),
      ),
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 95),
        child: Text(
          nom,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w600),
        ),
      ),
    );

    return Stack(
      clipBehavior: Clip.none,
      children: [
        Positioned.fill(
          child: CustomPaint(painter: _TraitPainter(enHautADroite)),
        ),
        Positioned(
          left: 105,
          top: 30,
          child: Container(
            width: 10,
            height: 10,
            decoration: BoxDecoration(
              color: Colors.white,
              shape: BoxShape.circle,
              border: Border.all(color: const Color(0xFF00E676), width: 2),
            ),
          ),
        ),
        if (enHautADroite)
          Positioned(left: 125, top: 0, child: etiquette)
        else
          Positioned(right: 125, top: 48, child: etiquette),
      ],
    );
  }
}

class _TraitPainter extends CustomPainter {
  final bool enHautADroite;
  _TraitPainter(this.enHautADroite);

  @override
  void paint(Canvas canvas, Size size) {
    final centre = Offset(size.width / 2, size.height / 2);
    final bout = enHautADroite ? Offset(125, 11) : Offset(95, 59);
    canvas.drawLine(
      centre,
      bout,
      Paint()
        ..color = Colors.white70
        ..strokeWidth = 1.2,
    );
  }

  @override
  bool shouldRepaint(covariant _TraitPainter old) => old.enHautADroite != enHautADroite;
}
