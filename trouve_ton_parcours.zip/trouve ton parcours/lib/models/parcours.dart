import 'package:latlong2/latlong.dart';

/// Une ville traversée par le parcours.
class EtapeVille {
  final String nom;
  final LatLng position;
  final double distanceKm; // distance depuis le départ

  const EtapeVille({
    required this.nom,
    required this.position,
    required this.distanceKm,
  });
}

/// Une portion du parcours entre deux villes.
class TronconParcours {
  final String depart;
  final String arrivee;
  final double distanceKm;
  final int denivelePos;
  final int deniveleNeg;

  const TronconParcours({
    required this.depart,
    required this.arrivee,
    required this.distanceKm,
    required this.denivelePos,
    required this.deniveleNeg,
  });
}

class Parcours {
  final String titre;
  final String distance;
  final String duree;
  final String difficulte;
  final String ville;
  final String denivele; // ex: "450 m D+"
  final List<LatLng> traceGPS;

  // Données détaillées (optionnelles pour rester compatible)
  final List<double> altitudes; // une altitude par point de traceGPS
  final List<double> distancesKm; // distance cumulée (km) par point
  final double distanceKm;
  final int denivelePos;
  final int deniveleNeg;
  final List<EtapeVille> etapes;
  final List<TronconParcours> troncons;

  const Parcours({
    required this.titre,
    required this.distance,
    required this.duree,
    required this.difficulte,
    required this.ville,
    required this.denivele,
    required this.traceGPS,
    this.altitudes = const [],
    this.distancesKm = const [],
    this.distanceKm = 0,
    this.denivelePos = 0,
    this.deniveleNeg = 0,
    this.etapes = const [],
    this.troncons = const [],
  });
}
