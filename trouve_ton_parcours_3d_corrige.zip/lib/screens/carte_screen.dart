import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:latlong2/latlong.dart';
import 'package:maplibre_gl/maplibre_gl.dart' as ml;
import 'package:wakelock_plus/wakelock_plus.dart';
import '../models/parcours.dart';
import '../services/favoris_service.dart';
import '../widgets/profil_altitude.dart';

class CarteScreen extends StatefulWidget {
  final Parcours parcours;

  const CarteScreen({super.key, required this.parcours});

  @override
  State<CarteScreen> createState() => _CarteScreenState();
}

class _CarteScreenState extends State<CarteScreen> {
  static const Color _vert = Color(0xFF00E676);
  static const Color _orange = Color(0xFFFF9100);
  static final Distance _dist = Distance(roundResult: false);

  // Fond de carte vectoriel gratuit, sans clé API (OpenFreeMap, données OpenStreetMap).
  // Le style « liberty » affiche les bâtiments en relief.
  // Pour changer de look : remplace par une autre URL de style MapLibre.
  static const String _styleUrl = 'https://tiles.openfreemap.org/styles/liberty';

  // Réglages de la caméra « effet TomTom » pendant le guidage.
  static const double _inclinaisonGuidage = 60; // 0 = vue du dessus, 60 = vue de derrière
  static const double _zoomGuidage = 17;
  static const double _zoomSuivi = 15.5;

  ml.MapLibreMapController? _ctl;
  bool _styleOk = false;
  ml.Circle? _cerclePosition;
  bool _majPositionEnCours = false;
  StreamSubscription<Position>? _sub;

  // Favori
  bool _favori = false;

  // GPS
  LatLng? _position;
  double _cap = 0;
  double _vitesse = 0;
  bool _gpsActif = false;
  bool _suivre = false;
  double? _ecartM;

  // Mode « Parcours GPS » (guidage)
  bool _modeGps = false;
  bool _termine = false;
  int _idxProgres = 0;
  double _bearingCible = 0;

  // Orientation de la carte pendant le guidage (cap réel si on roule, sinon direction du tracé)
  double _capCarte = 0;
  bool _capConnu = false;

  @override
  void initState() {
    super.initState();
    _chargerFavori();
  }

  @override
  void dispose() {
    _sub?.cancel();
    WakelockPlus.disable();
    super.dispose();
  }

  void _message(String texte) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(texte)));
  }

  ml.LatLng _ml(LatLng p) => ml.LatLng(p.latitude, p.longitude);

  // ---------------- Favoris ----------------

  Future<void> _chargerFavori() async {
    final f = await FavorisService.estFavori(widget.parcours);
    if (mounted) setState(() => _favori = f);
  }

  Future<void> _basculerFavori() async {
    if (_favori) {
      await FavorisService.retirer(widget.parcours);
      _message('Retiré des favoris');
    } else {
      await FavorisService.ajouter(widget.parcours);
      _message('Parcours ajouté aux favoris ❤️');
    }
    if (mounted) setState(() => _favori = !_favori);
  }

  // ---------------- Carte 3D (MapLibre) ----------------

  void _surCarteCreee(ml.MapLibreMapController c) {
    _ctl = c;
  }

  /// Appelé quand le fond de carte est prêt : on dessine le tracé, le départ et les villes.
  Future<void> _surStyleCharge() async {
    final c = _ctl;
    if (c == null) return;
    final p = widget.parcours;
    final trace = p.traceGPS.map(_ml).toList();

    if (trace.length > 1) {
      // Liseré blanc puis trait vert, pour bien ressortir sur le fond clair.
      await c.addLine(ml.LineOptions(
        geometry: trace,
        lineColor: '#FFFFFF',
        lineWidth: 10.0,
        lineOpacity: 0.9,
        lineJoin: 'round',
      ));
      await c.addLine(ml.LineOptions(
        geometry: trace,
        lineColor: '#00B84D',
        lineWidth: 6.0,
        lineJoin: 'round',
      ));
    }

    for (final e in p.etapes) {
      await c.addCircle(ml.CircleOptions(
        geometry: _ml(e.position),
        circleRadius: 5.0,
        circleColor: '#FFFFFF',
        circleStrokeColor: '#00B84D',
        circleStrokeWidth: 2.0,
      ));
      await c.addSymbol(ml.SymbolOptions(
        geometry: _ml(e.position),
        textField: e.nom,
        textSize: 13.0,
        textColor: '#111111',
        textHaloColor: '#FFFFFF',
        textHaloWidth: 2.0,
        textAnchor: 'top',
        textOffset: const Offset(0, 0.8),
        fontNames: const ['Noto Sans Bold'],
      ));
    }

    if (trace.isNotEmpty) {
      await c.addCircle(ml.CircleOptions(
        geometry: trace.first,
        circleRadius: 10.0,
        circleColor: '#00E676',
        circleStrokeColor: '#FFFFFF',
        circleStrokeWidth: 3.0,
      ));
    }

    _styleOk = true;
    if (!mounted) return;
    await _voirToutLeParcours(MediaQuery.of(context).size.height);
    if (_position != null) _majMarqueurPosition(_position!);
  }

  Future<void> _voirToutLeParcours(double hauteurEcran) async {
    final c = _ctl;
    final trace = widget.parcours.traceGPS;
    if (c == null || trace.length < 2) return;

    double minLat = trace.first.latitude, maxLat = trace.first.latitude;
    double minLon = trace.first.longitude, maxLon = trace.first.longitude;
    for (final p in trace) {
      minLat = math.min(minLat, p.latitude);
      maxLat = math.max(maxLat, p.latitude);
      minLon = math.min(minLon, p.longitude);
      maxLon = math.max(maxLon, p.longitude);
    }

    await c.animateCamera(
      ml.CameraUpdate.newLatLngBounds(
        ml.LatLngBounds(
          southwest: ml.LatLng(minLat, minLon),
          northeast: ml.LatLng(maxLat, maxLon),
        ),
        left: 40,
        top: 140,
        right: 40,
        bottom: hauteurEcran * (_modeGps ? 0.40 : 0.45),
      ),
      duration: const Duration(milliseconds: 600),
    );
    if (_suivre && mounted) setState(() => _suivre = false);
  }

  /// Caméra qui suit la position. En guidage : inclinée et tournée dans le sens de la marche.
  Future<void> _suivreCamera(LatLng pos) async {
    final c = _ctl;
    if (c == null) return;
    await c.animateCamera(
      ml.CameraUpdate.newCameraPosition(
        ml.CameraPosition(
          target: _ml(pos),
          zoom: _modeGps ? _zoomGuidage : _zoomSuivi,
          tilt: _modeGps ? _inclinaisonGuidage : 0,
          bearing: _modeGps ? _capCarte : 0,
        ),
      ),
      duration: const Duration(milliseconds: 700),
    );
  }

  /// Point bleu de la position courante.
  Future<void> _majMarqueurPosition(LatLng pos) async {
    final c = _ctl;
    if (c == null || !_styleOk || _majPositionEnCours) return;
    _majPositionEnCours = true;
    try {
      final g = _ml(pos);
      if (_cerclePosition == null) {
        _cerclePosition = await c.addCircle(ml.CircleOptions(
          geometry: g,
          circleRadius: 9.0,
          circleColor: '#2979FF',
          circleStrokeColor: '#FFFFFF',
          circleStrokeWidth: 3.0,
        ));
      } else {
        await c.updateCircle(_cerclePosition!, ml.CircleOptions(geometry: g));
      }
    } catch (_) {
      // on réessaiera à la prochaine position
    } finally {
      _majPositionEnCours = false;
    }
  }

  // ---------------- GPS en direct ----------------

  Future<void> _boutonGps() async {
    if (_modeGps) {
      setState(() => _suivre = true);
      if (_position != null) _suivreCamera(_position!);
      return;
    }
    if (!_gpsActif) {
      await _demarrerGps();
      return;
    }
    if (!_suivre) {
      setState(() => _suivre = true);
      if (_position != null) _suivreCamera(_position!);
      return;
    }
    _arreterGps();
  }

  Future<void> _demarrerGps() async {
    final actif = await Geolocator.isLocationServiceEnabled();
    if (!actif) {
      _message('Active la localisation de ton téléphone.');
      return;
    }
    var perm = await Geolocator.checkPermission();
    if (perm == LocationPermission.denied) {
      perm = await Geolocator.requestPermission();
    }
    if (perm == LocationPermission.denied || perm == LocationPermission.deniedForever) {
      _message('Autorisation de localisation refusée.');
      return;
    }
    if (!mounted) return;

    setState(() {
      _gpsActif = true;
      _suivre = true;
    });

    _sub = Geolocator.getPositionStream(
      locationSettings: const LocationSettings(
        accuracy: LocationAccuracy.high,
        distanceFilter: 5,
      ),
    ).listen(_surPosition, onError: (_) => _message('Signal GPS perdu.'));
  }

  void _arreterGps() {
    _sub?.cancel();
    _sub = null;
    final c = _ctl;
    final cercle = _cerclePosition;
    if (c != null && cercle != null) {
      c.removeCircle(cercle);
    }
    _cerclePosition = null;
    if (!mounted) return;
    setState(() {
      _gpsActif = false;
      _suivre = false;
      _position = null;
      _ecartM = null;
    });
  }

  double _normaliser(double b) => ((b % 360) + 360) % 360;

  void _surPosition(Position p) {
    if (!mounted) return;
    final pos = LatLng(p.latitude, p.longitude);
    final trace = widget.parcours.traceGPS;
    final dists = widget.parcours.distancesKm;
    final n = trace.length;

    int meilleur = _idxProgres;
    double ecart = double.infinity;

    if (n > 0) {
      // On cherche d'abord juste devant la progression (évite de sauter d'un bout à l'autre de la boucle)
      final debut = math.max(0, _idxProgres - 10);
      final fin = math.min(n - 1, _idxProgres + 400);
      for (int i = debut; i <= fin; i++) {
        final d = _dist.as(LengthUnit.Meter, pos, trace[i]);
        if (d < ecart) {
          ecart = d;
          meilleur = i;
        }
      }
      // Si on est très loin, recherche sur tout le tracé
      if (ecart > 400) {
        for (int i = 0; i < n; i++) {
          final d = _dist.as(LengthUnit.Meter, pos, trace[i]);
          if (d < ecart) {
            ecart = d;
            meilleur = i;
          }
        }
      }
    }

    // Point à viser : le tracé le plus proche si on est hors parcours, sinon ~200 m devant
    double bearing = _bearingCible;
    if (n > 0) {
      LatLng cible = trace[meilleur];
      if (ecart <= 60) {
        int j = meilleur;
        if (dists.length == n) {
          final limite = dists[meilleur] + 0.2;
          while (j < n - 1 && dists[j] < limite) {
            j++;
          }
        } else {
          j = math.min(n - 1, meilleur + 20);
        }
        cible = trace[j];
      }
      bearing = _normaliser(_dist.bearing(pos, cible));
    }

    // Orientation de la carte : cap réel si on roule, sinon direction du tracé au départ.
    final enMouvement = p.speed >= 1.0 && p.heading >= 0;
    if (enMouvement) {
      _capCarte = p.heading;
      _capConnu = true;
    } else if (!_capConnu) {
      _capCarte = bearing;
    }

    bool fini = _termine;
    if (_modeGps && !fini && n > 10 && meilleur >= n - 8 && ecart < 60) {
      final total = dists.isNotEmpty ? dists.last : 0.0;
      final parcouru = dists.length == n ? dists[meilleur] : 0.0;
      if (total > 0 && parcouru > total * 0.5) {
        fini = true;
        _message('Parcours terminé, bravo ! 🎉');
      }
    }

    setState(() {
      _position = pos;
      _cap = p.heading >= 0 ? p.heading : 0;
      _vitesse = p.speed >= 0 ? p.speed : 0;
      _ecartM = ecart.isFinite ? ecart : null;
      _idxProgres = meilleur;
      _bearingCible = bearing;
      _termine = fini;
    });

    _majMarqueurPosition(pos);
    if (_suivre) _suivreCamera(pos);
  }

  // ---------------- Mode « Parcours GPS » ----------------

  Future<void> _demarrerModeGps() async {
    if (!_gpsActif) {
      await _demarrerGps();
    }
    if (!_gpsActif) return; // autorisation refusée ou GPS désactivé

    await WakelockPlus.enable(); // garde l'écran allumé pendant le guidage
    if (!mounted) return;
    setState(() {
      _modeGps = true;
      _suivre = true;
      _termine = false;
      _idxProgres = 0;
      _capConnu = false;
    });
    if (_position != null) _suivreCamera(_position!);
  }

  Future<void> _terminerModeGps() async {
    await WakelockPlus.disable();
    _arreterGps();
    if (!mounted) return;
    setState(() {
      _modeGps = false;
      _termine = false;
    });
    _voirToutLeParcours(MediaQuery.of(context).size.height);
  }

  String _boussole(double b) {
    const noms = ['Nord', 'Nord-Est', 'Est', 'Sud-Est', 'Sud', 'Sud-Ouest', 'Ouest', 'Nord-Ouest'];
    return noms[((b + 22.5) / 45).floor() % 8];
  }

  // ---------------- Interface ----------------

  @override
  Widget build(BuildContext context) {
    final p = widget.parcours;
    final trace = p.traceGPS;
    final hauteur = MediaQuery.of(context).size.height;
    final haut = MediaQuery.of(context).padding.top;

    IconData iconeGps = Icons.my_location;
    Color couleurGps = Colors.white;
    if (_gpsActif && _suivre) {
      couleurGps = _vert;
    } else if (_gpsActif) {
      iconeGps = Icons.location_searching;
      couleurGps = const Color(0xFF2979FF);
    }

    final depart = trace.isNotEmpty ? trace.first : const LatLng(45.75, 4.85);

    return Scaffold(
      backgroundColor: const Color(0xFF0B0F0D),
      body: Stack(
        children: [
          // Carte 3D : on coupe le suivi dès que l'utilisateur touche la carte.
          Listener(
            onPointerDown: (_) {
              if (_suivre) setState(() => _suivre = false);
            },
            child: ml.MapLibreMap(
              styleString: _styleUrl,
              initialCameraPosition: ml.CameraPosition(
                target: _ml(depart),
                zoom: 12,
              ),
              onMapCreated: _surCarteCreee,
              onStyleLoadedCallback: _surStyleCharge,
              compassEnabled: false,
              rotateGesturesEnabled: true,
              tiltGesturesEnabled: true,
            ),
          ),

          // Titre + cœur favori
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            child: Container(
              padding: EdgeInsets.fromLTRB(8, haut + 6, 8, 24),
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Color(0xDD000000), Color(0x00000000)],
                ),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  IconButton(
                    icon: const Icon(Icons.arrow_back, color: Colors.white),
                    onPressed: () => Navigator.pop(context),
                  ),
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.only(top: 8),
                      child: Text(
                        p.titre,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                  IconButton(
                    tooltip: _favori ? 'Retirer des favoris' : 'Ajouter aux favoris',
                    icon: Icon(
                      _favori ? Icons.favorite : Icons.favorite_border,
                      color: _favori ? Colors.redAccent : Colors.white,
                      size: 28,
                    ),
                    onPressed: _basculerFavori,
                  ),
                ],
              ),
            ),
          ),

          // Alerte hors parcours (hors mode guidage : le guidage a son propre message)
          if (!_modeGps && _ecartM != null && _ecartM! > 120)
            Positioned(
              top: haut + 84,
              left: 16,
              right: 16,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                decoration: BoxDecoration(
                  color: const Color(0xEEFF6D00),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  'Hors parcours : à ${_ecartM!.round()} m du tracé',
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                ),
              ),
            ),

          // Boutons ronds à droite
          Positioned(
            right: 14,
            bottom: _modeGps ? 290 : hauteur * 0.40 + 14,
            child: Column(
              children: [
                _BoutonRond(
                  icone: iconeGps,
                  couleur: couleurGps,
                  onTap: _boutonGps,
                ),
                const SizedBox(height: 12),
                _BoutonRond(
                  icone: Icons.zoom_out_map,
                  couleur: Colors.white,
                  onTap: () => _voirToutLeParcours(hauteur),
                ),
              ],
            ),
          ),

          // Panneau du bas : guidage GPS ou résumé du parcours
          if (_modeGps)
            Positioned(left: 0, right: 0, bottom: 0, child: _panneauGps())
          else
            DraggableScrollableSheet(
              initialChildSize: 0.40,
              minChildSize: 0.40,
              maxChildSize: 0.90,
              builder: (context, scroll) {
                return Container(
                  decoration: const BoxDecoration(
                    color: Color(0xFF111614),
                    borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
                    boxShadow: [BoxShadow(color: Colors.black54, blurRadius: 12)],
                  ),
                  child: ListView(
                    controller: scroll,
                    padding: const EdgeInsets.fromLTRB(16, 10, 16, 24),
                    children: [
                      Center(
                        child: Container(
                          width: 40,
                          height: 4,
                          decoration: BoxDecoration(
                            color: Colors.white24,
                            borderRadius: BorderRadius.circular(2),
                          ),
                        ),
                      ),
                      const SizedBox(height: 14),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          _stat('Distance totale', '${p.distanceKm.toStringAsFixed(1)} km', Colors.white),
                          _stat('Dénivelé positif', '+${p.denivelePos} m', _vert),
                          _stat('Dénivelé négatif', '-${p.deniveleNeg} m', const Color(0xFFFF8A65)),
                        ],
                      ),
                      const SizedBox(height: 14),
                      SizedBox(
                        height: 130,
                        child: ProfilAltitude(
                          distancesKm: p.distancesKm,
                          altitudes: p.altitudes,
                          repereKm: p.etapes.map((e) => e.distanceKm).toList(),
                        ),
                      ),
                      const SizedBox(height: 14),
                      SizedBox(
                        height: 50,
                        child: ElevatedButton.icon(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFF2E9E4F),
                            foregroundColor: Colors.white,
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(25)),
                          ),
                          onPressed: _demarrerModeGps,
                          icon: const Icon(Icons.navigation),
                          label: const Text(
                            'Parcours GPS',
                            style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
                          ),
                        ),
                      ),
                      if (p.troncons.isNotEmpty) ...[
                        const SizedBox(height: 70),
                        const Text(
                          'Détail par tronçon',
                          style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold),
                        ),
                        const SizedBox(height: 6),
                        ...p.troncons.map(_ligneTroncon),
                      ],
                      const SizedBox(height: 16),
                      const Text(
                        '© OpenStreetMap contributors · © OpenFreeMap',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Colors.white30, fontSize: 10),
                      ),
                    ],
                  ),
                );
              },
            ),
        ],
      ),
    );
  }

  /// Panneau affiché pendant le guidage « Parcours GPS ».
  Widget _panneauGps() {
    final p = widget.parcours;
    final n = p.traceGPS.length;
    final aDonnees = n > 0 && p.distancesKm.length == n;

    final idx = math.max(0, math.min(_idxProgres, n - 1));
    final parcouru = aDonnees ? p.distancesKm[idx] : 0.0;
    final restant = math.max(0.0, p.distanceKm - parcouru);

    EtapeVille? prochaine;
    for (final e in p.etapes) {
      if (e.distanceKm > parcouru + 0.05) {
        prochaine = e;
        break;
      }
    }

    final horsTrace = (_ecartM ?? 0) > 60;
    String consigne;
    Color couleur;
    if (_termine) {
      consigne = 'Parcours terminé, bravo !';
      couleur = _vert;
    } else if (_position == null) {
      consigne = 'Recherche du signal GPS…';
      couleur = Colors.white70;
    } else if (horsTrace) {
      consigne = 'Rejoins le tracé (${_ecartM!.round()} m) vers le ${_boussole(_bearingCible)}';
      couleur = _orange;
    } else {
      consigne = 'Suis le tracé vers le ${_boussole(_bearingCible)}';
      couleur = _vert;
    }

    // La carte est tournée dans le sens de la marche : la flèche est relative au haut de l'écran.
    final angleFleche = (_bearingCible - _capCarte) * math.pi / 180;

    return Container(
      padding: EdgeInsets.fromLTRB(16, 14, 16, 16 + MediaQuery.of(context).padding.bottom),
      decoration: const BoxDecoration(
        color: Color(0xFF111614),
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        boxShadow: [BoxShadow(color: Colors.black54, blurRadius: 12)],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            children: [
              if (_position != null && !_termine)
                Transform.rotate(
                  angle: angleFleche,
                  child: Icon(Icons.navigation, color: couleur, size: 48),
                )
              else
                Icon(_termine ? Icons.emoji_events : Icons.gps_not_fixed, color: couleur, size: 44),
              const SizedBox(width: 14),
              Expanded(
                child: Text(
                  consigne,
                  style: TextStyle(color: couleur, fontSize: 17, fontWeight: FontWeight.bold),
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _stat('Parcouru', '${parcouru.toStringAsFixed(1)} km', Colors.white),
              _stat('Restant', '${restant.toStringAsFixed(1)} km', Colors.white),
              _stat(
                prochaine != null ? 'Prochaine : ${prochaine.nom}' : 'Arrivée',
                prochaine != null
                    ? 'dans ${math.max(0.0, prochaine.distanceKm - parcouru).toStringAsFixed(1)} km'
                    : '${restant.toStringAsFixed(1)} km',
                _vert,
              ),
            ],
          ),
          const SizedBox(height: 14),
          SizedBox(
            width: double.infinity,
            height: 46,
            child: OutlinedButton.icon(
              style: OutlinedButton.styleFrom(
                foregroundColor: const Color(0xFFFF8A65),
                side: const BorderSide(color: Color(0xFFFF8A65)),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(23)),
              ),
              onPressed: _terminerModeGps,
              icon: const Icon(Icons.stop_circle_outlined),
              label: const Text('Arrêter le GPS', style: TextStyle(fontWeight: FontWeight.bold)),
            ),
          ),
        ],
      ),
    );
  }

  Widget _stat(String label, String valeur, Color couleur) {
    return Column(
      children: [
        ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 120),
          child: Text(
            label,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(color: Colors.white60, fontSize: 11),
          ),
        ),
        const SizedBox(height: 4),
        Text(valeur, style: TextStyle(color: couleur, fontSize: 18, fontWeight: FontWeight.bold)),
      ],
    );
  }

  Widget _ligneTroncon(TronconParcours t) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 10),
      decoration: const BoxDecoration(
        border: Border(bottom: BorderSide(color: Colors.white12)),
      ),
      child: Row(
        children: [
          Expanded(
            child: Text(
              '${t.depart} → ${t.arrivee}',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(color: Colors.white, fontSize: 14),
            ),
          ),
          Text('${t.distanceKm.toStringAsFixed(1)} km',
              style: const TextStyle(color: Colors.white70, fontSize: 13)),
          const SizedBox(width: 12),
          Text('+${t.denivelePos} m', style: const TextStyle(color: _vert, fontSize: 13)),
          const SizedBox(width: 8),
          Text('-${t.deniveleNeg} m', style: const TextStyle(color: Color(0xFFFF8A65), fontSize: 13)),
        ],
      ),
    );
  }
}

class _BoutonRond extends StatelessWidget {
  final IconData icone;
  final Color couleur;
  final VoidCallback onTap;

  const _BoutonRond({required this.icone, required this.couleur, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: const Color(0xEE1B211E),
      shape: const CircleBorder(side: BorderSide(color: Colors.white24)),
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Icon(icone, color: couleur, size: 24),
        ),
      ),
    );
  }
}
