# Carte 3D (MapLibre) – à faire après `flutter pub get`

Ce qui a changé : `flutter_map` est remplacé par `maplibre_gl` (carte vectorielle inclinable).
Seuls `pubspec.yaml` et `lib/screens/carte_screen.dart` ont été modifiés.

## Android (`android/`)
- `android/settings.gradle` : Kotlin >= 2.1.0
  `id "org.jetbrains.kotlin.android" version "2.1.0" apply false`
- `android/app/build.gradle` : `minSdk` >= 21
- `AndroidManifest.xml` : permissions INTERNET, ACCESS_FINE_LOCATION, ACCESS_COARSE_LOCATION

## iOS (`ios/Runner/Info.plist`)
- `NSLocationWhenInUseUsageDescription` avec une phrase d'explication

## Réglages de l'effet TomTom (en haut de `carte_screen.dart`)
- `_inclinaisonGuidage` : 0 (vue du dessus) à 60 (vue de derrière)
- `_zoomGuidage`, `_zoomSuivi`
- `_styleUrl` : style de la carte (OpenFreeMap « liberty », sans clé API)

## Si les noms de villes n'apparaissent pas sur la carte
La police `Noto Sans Bold` (dans `fontNames`) doit exister dans le style choisi.

## Vue GPS façon TomTom (réglages en haut de `carte_screen.dart`)
- `_decalageAvantM` : plus la valeur est grande, plus ta position descend dans l'écran (90 par défaut)
- `_zoomGuidage` : 17.5 par défaut ; `_inclinaisonGuidage` : 60 (maximum)
- Bandeau en haut : icône du virage + distance + consigne (calculés depuis le tracé)
- Pastille : rouge « Vous n'êtes pas sur le parcours » / verte « Vous êtes sur le parcours »
- Hors parcours : itinéraire bleu (BRouter) pour rejoindre le tracé, avec ses propres virages

## Page de démarrage (splash)
- Image : `assets/splash.jpg` (remplace le fichier pour changer l'image)
- Durée : `_dureeSecondes` dans `lib/screens/splash_screen.dart` (3 s par défaut)

## Styles de parcours (dans `lib/services/routage_service.dart`)
Chaque style a son propre profil BRouter, envoyé au serveur au premier calcul (`_texteProfilRoute`, `_texteProfilBalade`, `_texteProfilVtt`).
Si un profil est refusé, l'appli retombe sur un profil standard (fastbike / safety / mtb, puis trekking) et l'indique par un message.

- **Route** : routes goudronnées (départementales, secondaires, tertiaires). Primaires évitées, chemins, sentiers et pavés très pénalisés.
- **Balade** : pistes cyclables, voies vertes, chemins de parc, bords de l'eau et zones vertes favorisés. Routes à circulation très pénalisées, côtes évitées.
- **VTT** : chemins, pistes et sentiers, de préférence en forêt. Bitume quasi interdit, villes évitées, sentiers trop techniques évités.

Après calcul, chaque boucle est analysée (part de chemins, de pistes cyclables, de routes à circulation…) :
les boucles conformes au style passent en premier (`_conforme`, `_score`). Les seuils sont réglables dans ces deux fonctions.

### VTT : « au plus près »
Si la zone demandée n'a pas assez de chemins (ex. Lyon centre), l'appli interroge OpenStreetMap (Overpass) pour trouver
les chemins les plus proches (rayon 4, 10, 20, 35 puis 55 km) et fait partir les boucles de là.
Un message indique alors d'où partent les parcours et à quelle distance. Si Overpass ne répond pas, le départ reste le point demandé.
Réglages : `_zonesVtt` (rayons), `_regrouperZones` (`voisins.length < 40` = densité de chemins minimale).

## Boutons de la carte (à droite)
De haut en bas : feuille de route écrite, nord, ma position, voir tout le parcours.
- **Feuille de route** : « Tournez à droite sur la rue de la Paix – pendant 500 m », changements de rue, villes traversées, kilomètres. Bouton « Copier » pour la coller ailleurs.
  Les noms de rues se chargent dès l'ouverture de la carte (`lib/services/rues_service.dart`), donc ils sont déjà là quand on ouvre la feuille. Deux sources en parallèle : la rue à chaque virage (Géoplateforme IGN, quelques secondes) puis toutes les rues du tracé (OpenStreetMap / Overpass, 3 serveurs interrogés en décalé) qui remplace la première quand elle arrive.
  Hors connexion, la feuille s'affiche sans noms de rues et propose de réessayer. Les chemins sans nom s'appellent « le sentier », « la piste cyclable », etc.
- **Nord** : remet la carte face au nord et arrête le suivi (sinon la carte se retournerait aussitôt dans le sens de la marche). Un appui sur « ma position » reprend le suivi.

## Import GPX
Bouton « importer » (flèche vers le haut) en haut de l'accueil et de la page des favoris. Il ouvre le sélecteur de fichiers du téléphone ;
le GPX choisi est lu (`lib/services/gpx_service.dart`), ajouté aux favoris, et s'ouvre sur la carte (GPS, feuille de route, profil d'altitude comme les autres parcours).
Dépendances ajoutées dans `pubspec.yaml` : `file_picker`, `xml`. Aucune permission Android / iOS supplémentaire.
Le tracé est allégé à 3000 points maximum. Les altitudes viennent du fichier (pas d'altitude dans le GPX = dénivelé à 0).

## Icône et nom de l'application
- Icône : `assets/icon/icon.png` et `assets/icon/icon_foreground.png`, configurés dans `pubspec.yaml` (`flutter_launcher_icons`).
  Elle est appliquée au téléphone par la commande `dart run flutter_launcher_icons`, à lancer dans le workflow GitHub avant `flutter build apk`.
- Nom sous l'icône : `android:label` dans l'AndroidManifest. Réglé par une commande `sed` dans le workflow GitHub (voir ci-dessous).
  Étapes à ajouter dans `.github/workflows/...yml`, juste avant `flutter build apk --release` :

      - run: dart run flutter_launcher_icons
      - run: sed -i 's/android:label="[^"]*"/android:label="TotoPa"/' android/app/src/main/AndroidManifest.xml

## GPX recommandés (base livrée avec l'appli) + popularité
À la recherche, l'appli affiche d'abord les GPX recommandés de la zone (badge « Recommandé », nombre de consultations), triés du plus au moins populaire,
puis les parcours générés par BRouter (badge « Généré automatiquement »).

Pour ajouter des GPX : mettre les fichiers `.gpx` dans `assets/gpx/` et les déclarer dans `assets/gpx/index.json` :

    [
      {
        "fichier": "lyon_boucle_fourviere.gpx",
        "titre": "Boucle Fourvière",
        "style": "route",
        "popularite": 50,
        "verifie": true
      }
    ]

- `style` : `route`, `balade` ou `vtt` (sans `style` : proposé pour tous les styles).
- `popularite` : valeur de départ (à toi de la fixer) ; chaque ouverture du parcours sur le téléphone ajoute +1 (compteur local à chaque téléphone).
- `lat`, `lon`, `km` (facultatifs) : départ et longueur du GPX. S'ils manquent, l'appli les lit dans le fichier ; avec beaucoup de fichiers, les renseigner accélère la recherche.
- Un GPX est proposé si son départ est à moins de 30 km de la ville cherchée et si sa longueur est à ±35 % de la distance choisie (`BaseGpxService.pourVille`).

## Itinéraires balisés réels (OpenStreetMap) + 3 parcours générés
À chaque recherche, l'accueil affiche : tes GPX de `assets/gpx/` (s'il y en a), jusqu'à 10 itinéraires vélo / VTT balisés qui existent réellement
(`lib/services/itineraires_osm_service.dart`, API Overpass, données OpenStreetMap), puis 3 parcours générés à la volée par BRouter.
- Style VTT -> relations OpenStreetMap `route=mtb` ; route et balade -> `route=bicycle`.
- OpenStreetMap ne contient pas de popularité : classement par importance du réseau (international, national, régional, local) puis par longueur.
- Ce sont des tronçons d'itinéraires (limités à la zone autour de la ville), souvent à sens unique, pas des boucles de la longueur choisie.
- Pas d'altitude dans OpenStreetMap : elle est demandée à Open-Meteo (~100 points par itinéraire) ; en cas d'échec, dénivelé à 0.
- Pas de recherche des villes traversées pour ces itinéraires (pour aller vite).

## Design façon Komoot (accueil, favoris, plusieurs parcours sur la carte)
Fichiers nouveaux ou refaits : `lib/screens/decouvrir_screen.dart` (nouveau), `lib/screens/accueil_screen.dart` (devient la coque avec barre du bas),
`lib/screens/favoris_screen.dart`, `lib/widgets/tuile_parcours.dart` (nouveau), `lib/main.dart` (thème clair vert). `carte_screen.dart` (détail + GPS) n'est pas modifié.
Le workflow GitHub (`build_apk.yml`) n'a pas besoin de changer.

- **Barre du bas** : Découvrir / Favoris / Importer. « Importer » ouvre le sélecteur GPX sans quitter l'onglet.
- **Découvrir** : carte plein écran, barre de recherche flottante (ville ou bouton « ma position »), puces Route / Balade / VTT et distance (10 à 100 km).
  Changer de type ou de distance relance la recherche automatiquement.
- **Plusieurs parcours sur la carte** : tous les résultats sont tracés en même temps, chacun avec son numéro (le même que dans la liste).
  Le parcours sélectionné est en vert, les autres en gris. On sélectionne en touchant la carte près d'un tracé, ou en touchant sa carte dans la liste.
  Un deuxième appui sur la carte sélectionnée (bouton « Ouvrir le parcours ») ouvre le détail et le guidage GPS comme avant.
- **Liste du bas** (à tirer vers le haut) : numéro, titre, origine (Recommandé / Balisé / Généré), distance, durée, dénivelé, mini profil d'altitude, météo du lieu.
- Réglages : couleurs `_vertCarte` / `_grisCarte` et épaisseurs dans `_dessiner()` ; nombre de parcours générés dans `_genererParcours()` (`.take(3)`).
