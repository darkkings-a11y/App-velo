import 'package:flutter/material.dart';
import '../widgets/import_gpx.dart';
import 'carte_screen.dart';
import 'decouvrir_screen.dart';
import 'favoris_screen.dart';

/// Coque de l'application façon Komoot : barre de navigation en bas
/// (Découvrir / Favoris / Importer) autour de l'écran Découvrir et de la liste des favoris.
class AccueilScreen extends StatefulWidget {
  const AccueilScreen({super.key});

  @override
  State<AccueilScreen> createState() => _AccueilScreenState();
}

class _AccueilScreenState extends State<AccueilScreen> {
  int _onglet = 0; // 0 = Découvrir, 1 = Favoris
  int _versionFavoris = 0; // change pour forcer le rechargement de la liste des favoris

  Future<void> _importer() async {
    final p = await importerGpx(context);
    if (!mounted) return;
    setState(() => _versionFavoris++);
    if (p != null) {
      await Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => CarteScreen(parcours: p)),
      );
      if (mounted) setState(() => _versionFavoris++);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: _onglet,
        children: [
          // Découvrir reste vivant en arrière-plan : la carte et les parcours ne sont pas perdus.
          const DecouvrirScreen(),
          _onglet == 1
              ? FavorisScreen(key: ValueKey(_versionFavoris))
              : const SizedBox.shrink(),
        ],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _onglet,
        onDestinationSelected: (i) {
          if (i == 2) {
            _importer(); // « Importer » ouvre le sélecteur de fichiers sans changer d'onglet
            return;
          }
          setState(() => _onglet = i);
        },
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.explore_outlined),
            selectedIcon: Icon(Icons.explore),
            label: 'Découvrir',
          ),
          NavigationDestination(
            icon: Icon(Icons.favorite_border),
            selectedIcon: Icon(Icons.favorite),
            label: 'Favoris',
          ),
          NavigationDestination(
            icon: Icon(Icons.upload_file_outlined),
            selectedIcon: Icon(Icons.upload_file),
            label: 'Importer',
          ),
        ],
      ),
    );
  }
}
