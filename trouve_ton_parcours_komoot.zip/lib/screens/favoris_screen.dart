import 'package:flutter/material.dart';
import '../models/parcours.dart';
import '../services/favoris_service.dart';
import '../widgets/import_gpx.dart';
import '../widgets/tuile_parcours.dart';
import 'carte_screen.dart';

class FavorisScreen extends StatefulWidget {
  const FavorisScreen({super.key});

  @override
  State<FavorisScreen> createState() => _FavorisScreenState();
}

class _FavorisScreenState extends State<FavorisScreen> {
  List<Parcours>? _favoris;

  @override
  void initState() {
    super.initState();
    _recharger();
  }

  Future<void> _recharger() async {
    final liste = await FavorisService.charger();
    if (mounted) setState(() => _favoris = liste);
  }

  @override
  Widget build(BuildContext context) {
    final favoris = _favoris;

    return Scaffold(
      backgroundColor: const Color(0xFFF6F8F6),
      appBar: AppBar(
        title: const Text('Mes parcours', style: TextStyle(fontWeight: FontWeight.bold)),
        backgroundColor: Colors.white,
        foregroundColor: const Color(0xFF16201B),
        elevation: 0,
        scrolledUnderElevation: 1,
        actions: [
          IconButton(
            icon: const Icon(Icons.upload_file),
            tooltip: 'Importer un fichier GPX',
            onPressed: () async {
              await importerGpx(context);
              _recharger();
            },
          ),
        ],
      ),
      body: favoris == null
          ? const Center(child: CircularProgressIndicator(color: TuileParcours.vert))
          : favoris.isEmpty
              ? const Center(
                  child: Padding(
                    padding: EdgeInsets.symmetric(horizontal: 32),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.favorite_border, size: 64, color: Color(0xFF9AA6A0)),
                        SizedBox(height: 16),
                        Text(
                          'Aucun parcours enregistré.',
                          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Color(0xFF37413C)),
                        ),
                        SizedBox(height: 8),
                        Text(
                          "Appuie sur le ❤ d'un parcours, ou importe un fichier GPX avec le bouton en haut.",
                          textAlign: TextAlign.center,
                          style: TextStyle(fontSize: 14, color: Color(0xFF6B7A73)),
                        ),
                      ],
                    ),
                  ),
                )
              : ListView.builder(
                  padding: const EdgeInsets.fromLTRB(14, 14, 14, 24),
                  itemCount: favoris.length,
                  itemBuilder: (context, index) {
                    final p = favoris[index];
                    return TuileParcours(
                      parcours: p,
                      onTap: () async {
                        await Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => CarteScreen(parcours: p)),
                        );
                        _recharger();
                      },
                      fin: IconButton(
                        icon: const Icon(Icons.favorite, color: Colors.redAccent),
                        tooltip: 'Retirer des favoris',
                        onPressed: () async {
                          await FavorisService.retirer(p);
                          _recharger();
                        },
                      ),
                    );
                  },
                ),
    );
  }
}
