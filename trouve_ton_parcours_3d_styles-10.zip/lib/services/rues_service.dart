import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;
import 'package:http/http.dart' as http;
import 'package:latlong2/latlong.dart';

/// Une portion du parcours sur une même rue / un même chemin.
class SegmentRue {
  final double debutM; // distance depuis le départ, en mètres
  final double finM;
  final String? nom; // nom OSM de la rue (null si la voie n'a pas de nom)
  final String type; // description si pas de nom : « le sentier », « la piste cyclable »…

  const SegmentRue({required this.debutM, required this.finM, required this.nom, required this.type});

  /// Identité de la portion (deux portions de même identité sont fusionnées).
  String get cle => nom ?? type;

  /// Pour une phrase : « la rue de la Paix », « le sentier ». Vide si on ne connaît pas la voie.
  String get phrase => nom != null ? RuesService.avecArticle(nom!) : type;
}

class _Voie {
  final String? nom;
  final String type;
  const _Voie(this.nom, this.type);
}

/// Retrouve le nom des rues le long d'un tracé (données OpenStreetMap via Overpass).
class RuesService {
  static const List<String> _serveurs = [
    'https://overpass-api.de/api/interpreter',
    'https://overpass.kumi.systems/api/interpreter',
    'https://overpass.private.coffee/api/interpreter',
  ];

  // Précision de rattachement d'un point du tracé à une rue (mètres).
  static const double _rayonM = 30;

  /// Null si OpenStreetMap n'a pas répondu.
  static Future<List<SegmentRue>?> charger(List<LatLng> trace, List<double> cumM) async {
    if (trace.length < 2 || cumM.length != trace.length) return null;

    // 1. Points du tracé tous les ~15 m (avec leur distance depuis le départ).
    final echantillons = <LatLng>[];
    final distances = <double>[];
    for (int i = 0; i < trace.length; i++) {
      if (i == 0) {
        echantillons.add(trace[0]);
        distances.add(0);
        continue;
      }
      final d = cumM[i] - cumM[i - 1];
      final n = math.max(1, (d / 15).ceil());
      for (int k = 1; k <= n; k++) {
        final t = k / n;
        echantillons.add(LatLng(
          trace[i - 1].latitude + (trace[i].latitude - trace[i - 1].latitude) * t,
          trace[i - 1].longitude + (trace[i].longitude - trace[i - 1].longitude) * t,
        ));
        distances.add(cumM[i - 1] + d * t);
      }
    }

    // 2. Rues proches du tracé, par tronçons de ~6 km pour ne pas surcharger le serveur.
    final polyline = <LatLng>[];
    double derniere = -1e9;
    for (int i = 0; i < echantillons.length; i++) {
      if (distances[i] - derniere >= 120 || i == echantillons.length - 1) {
        polyline.add(echantillons[i]);
        derniere = distances[i];
      }
    }
    const taille = 40;
    final morceaux = <List<LatLng>>[];
    for (int i = 0; i < polyline.length - 1; i += taille - 1) {
      morceaux.add(polyline.sublist(i, math.min(polyline.length, i + taille)));
    }

    final voies = <Map<String, dynamic>>[];
    final vus = <int>{};
    bool aucuneReponse = true;
    for (int i = 0; i < morceaux.length; i += 4) {
      final lot = morceaux.skip(i).take(4).toList();
      final reponses = await Future.wait(lot.map(_voiesProches));
      for (final r in reponses) {
        if (r == null) continue; // ce tronçon restera sans nom
        aucuneReponse = false;
        for (final w in r) {
          final id = w['id'];
          if (id is int && vus.add(id)) voies.add(w);
        }
      }
    }
    if (aucuneReponse || voies.isEmpty) return null;

    // 3. Les rues sont découpées en petits points (tous les ~10 m) rangés par case.
    final latRef = trace.first.latitude;
    final kLon = math.cos(latRef * math.pi / 180);
    const cellule = 0.0004; // ~45 m
    final cases = <int, List<int>>{}; // case -> indices de points
    final ptsLat = <double>[];
    final ptsLon = <double>[];
    final ptsVoie = <int>[];
    int cleCase(int i, int j) => i * 100003 + j;

    final infos = <_Voie>[];
    for (final w in voies) {
      final tags = (w['tags'] as Map?)?.cast<String, dynamic>() ?? const {};
      final geom = w['geometry'] as List?;
      if (geom == null || geom.length < 2) continue;
      final idx = infos.length;
      infos.add(_Voie(_nomDe(tags), _typeDe(tags)));
      for (int g = 0; g < geom.length - 1; g++) {
        final a = geom[g] as Map;
        final b = geom[g + 1] as Map;
        final lat1 = (a['lat'] as num).toDouble(), lon1 = (a['lon'] as num).toDouble();
        final lat2 = (b['lat'] as num).toDouble(), lon2 = (b['lon'] as num).toDouble();
        final dx = (lon2 - lon1) * 111320 * kLon;
        final dy = (lat2 - lat1) * 110540;
        final n = math.max(1, (math.sqrt(dx * dx + dy * dy) / 10).ceil());
        for (int k = 0; k <= n; k++) {
          final t = k / n;
          final la = lat1 + (lat2 - lat1) * t;
          final lo = lon1 + (lon2 - lon1) * t;
          final id = ptsLat.length;
          ptsLat.add(la);
          ptsLon.add(lo);
          ptsVoie.add(idx);
          cases.putIfAbsent(cleCase((la / cellule).floor(), (lo / cellule).floor()), () => []).add(id);
        }
      }
    }

    // 4. Pour chaque point du tracé : la rue la plus proche.
    final choix = List<int>.filled(echantillons.length, -1);
    for (int s = 0; s < echantillons.length; s++) {
      final la = echantillons[s].latitude;
      final lo = echantillons[s].longitude;
      final ci = (la / cellule).floor();
      final cj = (lo / cellule).floor();
      double meilleure = _rayonM;
      int voie = -1;
      for (int di = -1; di <= 1; di++) {
        for (int dj = -1; dj <= 1; dj++) {
          final liste = cases[cleCase(ci + di, cj + dj)];
          if (liste == null) continue;
          for (final id in liste) {
            final dx = (ptsLon[id] - lo) * 111320 * kLon;
            final dy = (ptsLat[id] - la) * 110540;
            final d = math.sqrt(dx * dx + dy * dy);
            if (d < meilleure) {
              meilleure = d;
              voie = ptsVoie[id];
            }
          }
        }
      }
      choix[s] = voie;
    }

    // 5. On lisse (majorité sur ±4 points) pour ne pas changer de rue à chaque carrefour.
    final lisse = List<int>.filled(choix.length, -1);
    for (int s = 0; s < choix.length; s++) {
      final compte = <String, int>{};
      final reps = <String, int>{};
      for (int k = math.max(0, s - 4); k <= math.min(choix.length - 1, s + 4); k++) {
        if (choix[k] < 0) continue;
        final v = infos[choix[k]];
        final cle = v.nom ?? v.type;
        compte[cle] = (compte[cle] ?? 0) + 1;
        reps[cle] = choix[k];
      }
      if (compte.isEmpty) continue;
      final best = compte.entries.reduce((a, b) => a.value >= b.value ? a : b).key;
      lisse[s] = reps[best]!;
    }

    // 6. Portions continues sur la même rue ; celles de moins de 40 m sont absorbées.
    final bruts = <SegmentRue>[];
    for (int s = 0; s < lisse.length; s++) {
      final v = lisse[s] >= 0 ? infos[lisse[s]] : null;
      final nom = v?.nom;
      final type = v?.type ?? '';
      final fin = s + 1 < distances.length ? distances[s + 1] : distances[s];
      if (bruts.isNotEmpty && bruts.last.nom == nom && bruts.last.type == type) {
        final l = bruts.removeLast();
        bruts.add(SegmentRue(debutM: l.debutM, finM: fin, nom: nom, type: type));
      } else {
        bruts.add(SegmentRue(debutM: distances[s], finM: fin, nom: nom, type: type));
      }
    }
    final fusion = <SegmentRue>[];
    for (final seg in bruts) {
      final court = seg.finM - seg.debutM < 40;
      if (fusion.isNotEmpty && court) {
        final l = fusion.removeLast();
        fusion.add(SegmentRue(debutM: l.debutM, finM: seg.finM, nom: l.nom, type: l.type));
      } else if (fusion.isNotEmpty && fusion.last.cle == seg.cle) {
        final l = fusion.removeLast();
        fusion.add(SegmentRue(debutM: l.debutM, finM: seg.finM, nom: l.nom, type: l.type));
      } else {
        fusion.add(seg);
      }
    }
    return fusion;
  }

  /// Rues (avec géométrie) à moins de 25 m d'une ligne brisée.
  /// Les serveurs sont interrogés en décalé (le suivant démarre après 3 s sans réponse) : le premier qui répond gagne.
  static Future<List<Map<String, dynamic>>?> _voiesProches(List<LatLng> ligne) {
    final pts = ligne
        .map((p) => '${p.latitude.toStringAsFixed(5)},${p.longitude.toStringAsFixed(5)}')
        .join(',');
    final requete = '[out:json][timeout:20];way(around:25,$pts)["highway"];out tags geom;';
    final fini = Completer<List<Map<String, dynamic>>?>();
    int echecs = 0;

    void echec() {
      echecs++;
      if (echecs >= _serveurs.length && !fini.isCompleted) fini.complete(null);
    }

    void tenter(String serveur) {
      http
          .post(Uri.parse(serveur), headers: {'User-Agent': 'AppVeloMobile/1.0'}, body: {'data': requete})
          .timeout(const Duration(seconds: 15))
          .then((r) {
        if (fini.isCompleted) return;
        if (r.statusCode != 200) {
          echec();
          return;
        }
        try {
          final data = json.decode(utf8.decode(r.bodyBytes)) as Map<String, dynamic>;
          final elements = (data['elements'] as List?) ?? const [];
          fini.complete(elements.whereType<Map<String, dynamic>>().toList());
        } catch (_) {
          echec();
        }
      }).catchError((_) {
        echec();
      });
    }

    for (int i = 0; i < _serveurs.length; i++) {
      Future.delayed(Duration(seconds: 3 * i), () {
        if (!fini.isCompleted) tenter(_serveurs[i]);
      });
    }
    return fini.future;
  }

  // ---------------------------------------------------------------------------
  // Méthode rapide : le nom de la rue à chaque virage (adresse la plus proche, Géoplateforme IGN)
  // ---------------------------------------------------------------------------

  /// Noms de rues au départ et à chaque virage. Très rapide (quelques secondes), mais moins précis
  /// que [charger] : une adresse proche, pas la voie exacte. Null si rien n'a été trouvé.
  static Future<List<SegmentRue>?> chargerAuxTournants(
    List<LatLng> trace,
    List<double> cumM,
    List<double> tournantsM,
  ) async {
    if (trace.length < 2 || cumM.length != trace.length) return null;
    final totalM = cumM.last;
    final bornes = <double>[0, ...tournantsM.where((m) => m > 20 && m < totalM - 20).take(150)];
    bornes.sort();

    final points = bornes.map((m) => _pointA(trace, cumM, math.min(totalM, m + 15))).toList();
    final noms = List<String?>.filled(points.length, null);
    for (int i = 0; i < points.length; i += 8) {
      final fin = math.min(points.length, i + 8);
      final lot = await Future.wait([for (int k = i; k < fin; k++) _rueDeLAdresse(points[k])]);
      for (int k = i; k < fin; k++) {
        noms[k] = lot[k - i];
      }
    }
    if (noms.every((n) => n == null)) return null;

    final res = <SegmentRue>[];
    for (int i = 0; i < bornes.length; i++) {
      final debut = bornes[i];
      final fin = i + 1 < bornes.length ? bornes[i + 1] : totalM;
      final nom = noms[i];
      if (res.isNotEmpty && res.last.nom == nom) {
        final l = res.removeLast();
        res.add(SegmentRue(debutM: l.debutM, finM: fin, nom: nom, type: ''));
      } else {
        res.add(SegmentRue(debutM: debut, finM: fin, nom: nom, type: ''));
      }
    }
    return res;
  }

  static LatLng _pointA(List<LatLng> trace, List<double> cum, double m) {
    int lo = 0, hi = cum.length - 1;
    while (lo < hi) {
      final mid = (lo + hi) ~/ 2;
      if (cum[mid] < m) {
        lo = mid + 1;
      } else {
        hi = mid;
      }
    }
    if (lo == 0) return trace.first;
    final d = cum[lo] - cum[lo - 1];
    final t = d > 0 ? (m - cum[lo - 1]) / d : 0.0;
    return LatLng(
      trace[lo - 1].latitude + (trace[lo].latitude - trace[lo - 1].latitude) * t,
      trace[lo - 1].longitude + (trace[lo].longitude - trace[lo - 1].longitude) * t,
    );
  }

  static Future<String?> _rueDeLAdresse(LatLng p) async {
    try {
      final uri = Uri.https('data.geopf.fr', '/geocodage/reverse', {
        'lon': p.longitude.toStringAsFixed(6),
        'lat': p.latitude.toStringAsFixed(6),
        'index': 'address',
        'limit': '1',
      });
      final r = await http.get(uri, headers: {'User-Agent': 'AppVeloMobile/1.0'}).timeout(const Duration(seconds: 8));
      if (r.statusCode != 200) return null;
      final data = json.decode(utf8.decode(r.bodyBytes)) as Map<String, dynamic>;
      final features = data['features'] as List?;
      if (features == null || features.isEmpty) return null;
      final props = (features.first as Map)['properties'] as Map?;
      if (props == null) return null;
      final distance = props['distance'];
      if (distance is num && distance > 70) return null;
      var rue = props['street'];
      if (rue is! String || rue.trim().isEmpty) {
        final nom = props['name'];
        if (nom is! String) return null;
        rue = nom.replaceFirst(RegExp(r'^\d+\s*(bis|ter|quater)?\s+', caseSensitive: false), '');
      }
      final s = (rue as String).trim();
      return s.isEmpty ? null : s;
    } catch (_) {
      return null;
    }
  }

  static String? _nomDe(Map<String, dynamic> tags) {
    final nom = tags['name'];
    if (nom is String && nom.trim().isNotEmpty) return nom.trim();
    final ref = tags['ref'];
    if (ref is String && ref.trim().isNotEmpty) return ref.trim().split(';').first.trim();
    return null;
  }

  static String _typeDe(Map<String, dynamic> tags) {
    if (tags['junction'] == 'roundabout') return 'le rond-point';
    switch (tags['highway']) {
      case 'cycleway':
        return 'la piste cyclable';
      case 'path':
        return 'le sentier';
      case 'track':
      case 'bridleway':
        return 'le chemin';
      case 'footway':
        return 'le chemin piéton';
      case 'pedestrian':
        return 'la rue piétonne';
      case 'service':
        return 'la voie de service';
      case 'steps':
        return "l'escalier";
      case 'residential':
      case 'living_street':
        return 'la rue';
      default:
        return 'la route';
    }
  }

  static const Set<String> _feminins = {
    'rue', 'route', 'place', 'impasse', 'avenue', 'allée', 'voie', 'ruelle', 'promenade', 'traverse',
    'montée', 'côte', 'piste', 'esplanade', 'villa', 'cité', 'passerelle', 'digue', 'rampe', 'chaussée',
    'corniche', 'venelle', 'résidence', 'départementale', 'nationale', 'sente', 'allées', 'cour',
  };
  static const Set<String> _masculins = {
    'chemin', 'boulevard', 'quai', 'pont', 'sentier', 'passage', 'cours', 'square', 'port', 'parc',
    'clos', 'hameau', 'lotissement', 'faubourg', 'carrefour', 'mail', 'tunnel', 'viaduc', 'canal',
    'rond-point', 'grand-chemin',
  };

  /// « Rue de la Paix » -> « la rue de la Paix » ; « Avenue Foch » -> « l'avenue Foch ».
  static String avecArticle(String nom) {
    final t = nom.trim();
    if (RegExp(r'^[A-Z]{1,2}\s?\d+[A-Za-z]?$').hasMatch(t)) return 'la $t';
    final espace = t.indexOf(' ');
    if (espace <= 0) return t;
    final premier = t.substring(0, espace).toLowerCase();
    final reste = t.substring(espace);
    final elision = RegExp(r'^[aeiouyàâéèêëîïôöùûh]').hasMatch(premier);
    if (_feminins.contains(premier)) return (elision ? "l'" : 'la ') + premier + reste;
    if (_masculins.contains(premier)) return (elision ? "l'" : 'le ') + premier + reste;
    return t;
  }
}
