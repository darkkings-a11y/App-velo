import 'package:latlong2/latlong.dart';
import '../models/parcours.dart';
import 'rues_service.dart';

enum TypeVirage { gauche, droite, legerGauche, legerDroite, demiTour }

/// Un virage détecté le long d'un tracé.
class Virage {
  final int index;
  final double cumM; // distance depuis le début du tracé, en mètres
  final TypeVirage type;

  const Virage({required this.index, required this.cumM, required this.type});

  String get texte {
    switch (type) {
      case TypeVirage.gauche:
        return 'Tournez à gauche';
      case TypeVirage.droite:
        return 'Tournez à droite';
      case TypeVirage.legerGauche:
        return 'Tournez légèrement à gauche';
      case TypeVirage.legerDroite:
        return 'Tournez légèrement à droite';
      case TypeVirage.demiTour:
        return 'Faites demi-tour';
    }
  }
}

enum GenreLigne { depart, virage, toutDroit, ville, arrivee }

/// Une ligne de la feuille de route écrite.
class LigneRoute {
  final GenreLigne genre;
  final TypeVirage? virage;
  final String texte;
  final double km; // position sur le parcours, en km
  final String? detail; // ex. « pendant 500 m »

  const LigneRoute({required this.genre, required this.texte, required this.km, this.virage, this.detail});
}

class Guidage {
  static final Distance _d = Distance(roundResult: false);

  /// Distance cumulée (en mètres) pour chaque point du tracé.
  static List<double> cumulM(List<LatLng> pts) {
    final cum = <double>[];
    double total = 0;
    for (int i = 0; i < pts.length; i++) {
      if (i > 0) total += _d.as(LengthUnit.Meter, pts[i - 1], pts[i]);
      cum.add(total);
    }
    return cum;
  }

  /// Détecte les vrais virages (changement de direction net sur ~50 m).
  /// Les courbes douces ne comptent pas comme des virages.
  static List<Virage> detecterVirages(List<LatLng> pts, List<double> cum) {
    final n = pts.length;
    if (n < 3 || cum.length != n) return const [];
    const fenetre = 25.0;
    const seuil = 35.0;

    final delta = List<double>.filled(n, 0);
    for (int i = 1; i < n - 1; i++) {
      int a = i;
      while (a > 0 && cum[i] - cum[a] < fenetre) {
        a--;
      }
      int b = i;
      while (b < n - 1 && cum[b] - cum[i] < fenetre) {
        b++;
      }
      if (a == i || b == i) continue;
      final entree = _d.bearing(pts[a], pts[i]);
      final sortie = _d.bearing(pts[i], pts[b]);
      delta[i] = ((sortie - entree + 540) % 360) - 180; // + = droite, - = gauche
    }

    final res = <Virage>[];
    int i = 1;
    while (i < n - 1) {
      if (delta[i].abs() < seuil) {
        i++;
        continue;
      }
      // groupe de points consécutifs au-dessus du seuil : on garde le plus marqué
      int meilleur = i;
      int j = i;
      while (j < n - 1 && delta[j].abs() >= seuil) {
        if (delta[j].abs() > delta[meilleur].abs()) meilleur = j;
        j++;
      }
      final angle = delta[meilleur];
      final abs = angle.abs();
      final TypeVirage type;
      if (abs >= 150) {
        type = TypeVirage.demiTour;
      } else if (abs >= 65) {
        type = angle > 0 ? TypeVirage.droite : TypeVirage.gauche;
      } else {
        type = angle > 0 ? TypeVirage.legerDroite : TypeVirage.legerGauche;
      }
      if (res.isEmpty || cum[meilleur] - res.last.cumM > 30) {
        res.add(Virage(index: meilleur, cumM: cum[meilleur], type: type));
      }
      i = j;
    }
    return res;
  }

  static String formaterDistance(double m) {
    if (m < 1000) {
      final arrondi = m < 100 ? (m / 10).round() * 10 : (m / 50).round() * 50;
      return '${arrondi.toInt()} m';
    }
    return '${(m / 1000).toStringAsFixed(1).replaceAll('.', ',')} km';
  }

  /// Le parcours en texte : départ, chaque virage (avec le nom de la rue si on l'a), villes traversées, arrivée.
  /// [rues] : portions de rues le long du tracé (null si les noms n'ont pas pu être chargés).
  static List<LigneRoute> feuilleDeRoute(
    Parcours p,
    List<double> cum,
    List<Virage> virages,
    List<SegmentRue>? rues,
  ) {
    final totalM = cum.isNotEmpty ? cum.last : p.distanceKm * 1000;

    SegmentRue? rueA(double m) {
      if (rues == null || rues.isEmpty) return null;
      for (final s in rues) {
        if (m < s.finM) return s;
      }
      return rues.last;
    }

    // Lignes « d'action » (départ, virages, changements de rue) : on y calcule « pendant X ».
    final actions = <({double m, GenreLigne genre, TypeVirage? virage, String texte})>[];

    final rue0 = rueA(5);
    actions.add((
      m: 0.0,
      genre: GenreLigne.depart,
      virage: null,
      texte: (rue0 != null && rue0.phrase.isNotEmpty) ? 'Départ de ${p.ville}, sur ${rue0.phrase}' : 'Départ de ${p.ville}',
    ));

    // Virages
    for (final v in virages) {
      final avant = rueA(v.cumM - 12);
      final apres = rueA(v.cumM + 12);
      var texte = v.texte;
      if (apres != null && apres.phrase.isNotEmpty && (avant == null || avant.cle != apres.cle)) {
        texte += ' sur ${apres.phrase}';
      } else if (apres != null && apres.phrase.isNotEmpty) {
        texte += ' (vous restez sur ${apres.phrase})';
      }
      actions.add((m: v.cumM, genre: GenreLigne.virage, virage: v.type, texte: texte));
    }

    // Changements de rue sans virage (la rue change de nom, on sort d'un chemin…)
    if (rues != null) {
      for (int i = 1; i < rues.length; i++) {
        final s = rues[i];
        if (s.finM - s.debutM < 100 || s.phrase.isEmpty) continue;
        final prochePuVirage = virages.any((v) => (v.cumM - s.debutM).abs() < 60);
        if (prochePuVirage) continue;
        actions.add((
          m: s.debutM,
          genre: GenreLigne.toutDroit,
          virage: null,
          texte: 'Continuez sur ${s.phrase}',
        ));
      }
    }
    actions.sort((a, b) => a.m.compareTo(b.m));

    // Villes traversées
    final villes = <({double m, String nom})>[
      for (final e in p.etapes) (m: e.distanceKm * 1000, nom: e.nom),
    ];

    final lignes = <LigneRoute>[];
    for (int i = 0; i < actions.length; i++) {
      final a = actions[i];
      final fin = i + 1 < actions.length ? actions[i + 1].m : totalM;
      final longueur = fin - a.m;
      lignes.add(LigneRoute(
        genre: a.genre,
        virage: a.virage,
        texte: a.texte,
        km: a.m / 1000,
        detail: longueur >= 50 ? 'pendant ${formaterDistance(longueur)}' : null,
      ));
    }
    for (final v in villes) {
      lignes.add(LigneRoute(genre: GenreLigne.ville, texte: 'Passage à ${v.nom}', km: v.m / 1000));
    }
    lignes.sort((a, b) {
      final c = a.km.compareTo(b.km);
      if (c != 0) return c;
      // à distance égale, l'action avant la ville
      return (a.genre == GenreLigne.ville ? 1 : 0).compareTo(b.genre == GenreLigne.ville ? 1 : 0);
    });
    lignes.add(LigneRoute(genre: GenreLigne.arrivee, texte: 'Arrivée à ${p.ville}', km: totalM / 1000));
    return lignes;
  }

  static String formaterKm(double km) => '${km.toStringAsFixed(1).replaceAll('.', ',')} km';

  /// Version texte à copier / coller.
  static String texteFeuille(Parcours p, List<LigneRoute> lignes) {
    final b = StringBuffer()
      ..writeln(p.titre)
      ..writeln('${p.distance} · ${p.duree} · ${p.denivele}')
      ..writeln();
    for (final l in lignes) {
      b.writeln('${formaterKm(l.km).padLeft(8)}  ${l.texte}${l.detail != null ? ' – ${l.detail}' : ''}');
    }
    return b.toString();
  }
}
