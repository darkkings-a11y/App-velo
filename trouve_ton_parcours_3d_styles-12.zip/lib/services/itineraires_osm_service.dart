import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;
import 'package:http/http.dart' as http;
import 'package:latlong2/latlong.dart';
import '../models/parcours.dart';
import 'gpx_service.dart';

/// Itinéraires vélo / VTT balisés qui existent réellement (relations OpenStreetMap), autour d'une ville.
/// Données libres (ODbL), récupérées via l'API Overpass. OpenStreetMap ne contient AUCUNE donnée de popularité :
/// le classement se fait par importance du réseau (international > national > régional > local), puis par proximité
/// avec la distance demandée.
///
/// Pendant une session (appli ouverte), chaque nouvelle recherche au même endroit renvoie d'AUTRES itinéraires :
/// ceux déjà montrés sont mis de côté, et la liste de la zone est gardée en mémoire (la 2e recherche est bien plus rapide).
class ItinerairesOsmService {
  static final Distance _calc = Distance(roundResult: false);

  static const List<String> _serveurs = [
    'https://overpass-api.de/api/interpreter',
    'https://overpass.private.coffee/api/interpreter',
    'https://overpass.kumi.systems/api/interpreter',
    'https://overpass.openstreetmap.fr/api/interpreter',
    'https://maps.mail.ru/osm/tools/overpass/api/interpreter',
  ];

  /// Message à montrer si les itinéraires n'ont pas pu être chargés.
  static String? note;

  /// Mémoire de la session, par zone (ville + style + distance).
  static final Map<String, _Zone> _zones = {};

  /// Itinéraires traités par lot (un seul appel réseau par lot).
  static const int _lot = 18;

  static Future<List<Parcours>> pourVille({
    required LatLng centre,
    required String profil,
    required int distanceKm,
    required String villeNom,
    int max = 10,
    bool recommence = false,
  }) async {
    if (!recommence) note = null;
    try {
      final cle = '$profil|${centre.latitude.toStringAsFixed(2)},${centre.longitude.toStringAsFixed(2)}|$distanceKm';
      var zone = _zones[cle];

      // Étape 1 (une seule fois par zone) : liste légère des itinéraires, sans géométrie.
      if (zone == null) {
        zone = await _listerZone(centre, profil, distanceKm);
        if (zone == null) {
          note = "Itinéraires balisés indisponibles : OpenStreetMap n'a pas répondu.";
          return [];
        }
        _zones[cle] = zone;
      }

      // Étape 2 : géométrie des prochains itinéraires jamais vus (par lots), jusqu'à en avoir assez.
      int tours = 0;
      while (tours < 2 &&
          zone.pos < zone.rels.length &&
          (zone.reserve.length + _nbLache(zone, centre, distanceKm)) < max) {
        tours++;
        final lot = zone.rels.skip(zone.pos).take(_lot).toList();
        final ok = await _chargerLot(zone, lot, centre, distanceKm);
        if (!ok) {
          if (zone.reserve.isEmpty && zone.bruts.isEmpty) {
            note = "Itinéraires balisés indisponibles : OpenStreetMap n'a pas répondu.";
            return [];
          }
          break;
        }
        zone.pos += lot.length;
      }

      // Sélection : d'abord les itinéraires proches de la distance voulue (±15 %), puis les moins proches (±35 %).
      final choisis = <_Candidat>[...zone.reserve];
      choisis.sort((a, b) {
        final n = b.niveau.compareTo(a.niveau);
        return n != 0 ? n : (a.km - distanceKm).abs().compareTo((b.km - distanceKm).abs());
      });
      var retenus = choisis.take(max).toList();
      zone.reserve.removeWhere(retenus.contains);
      if (retenus.length < max) {
        final lache = _lacher(zone, centre, distanceKm);
        lache.sort((a, b) => (a.km - distanceKm).abs().compareTo((b.km - distanceKm).abs()));
        final ajout = lache.take(max - retenus.length).toList();
        retenus = [...retenus, ...ajout];
        zone.bruts.removeWhere((b) => ajout.any((c) => c.cleBrut == b.nom));
      }

      if (retenus.isEmpty) {
        if (zone.montres > 0 && !recommence) {
          // Tout a été montré : on repart de zéro.
          _zones.remove(cle);
          final r = await pourVille(
            centre: centre,
            profil: profil,
            distanceKm: distanceKm,
            villeNom: villeNom,
            max: max,
            recommence: true,
          );
          if (r.isNotEmpty) note = "Tous les itinéraires balisés de la zone ont été montrés : on recommence la liste.";
          return r;
        }
        note ??= "Aucun itinéraire balisé proche de $distanceKm km dans la région.";
        return [];
      }
      zone.montres += retenus.length;

      // Altitudes (OpenStreetMap n'en a pas) puis parcours complets, tous en parallèle.
      final parcours = await Future.wait(retenus.map((c) async {
        try {
          final alts = await _altitudes(c.trace);
          return await GpxService.depuisPoints(
            c.trace,
            alts,
            nom: c.nom,
            source: Parcours.sourceOpenData,
            verifie: false,
            detailSource: _libelle(c.niveau),
            avecVilles: false,
            villeParDefaut: villeNom,
          );
        } catch (_) {
          return null;
        }
      }));
      return parcours.whereType<Parcours>().toList();
    } catch (_) {
      note = "Itinéraires balisés indisponibles pour le moment.";
      return [];
    }
  }

  // ---------------------------------------------------------------------------

  static String _bbox(LatLng c, double rayonKm) {
    final dLat = rayonKm / 110.54;
    final dLon = rayonKm / (111.32 * math.max(0.2, math.cos(c.latitude * math.pi / 180)));
    return '${(c.latitude - dLat).toStringAsFixed(5)},${(c.longitude - dLon).toStringAsFixed(5)},'
        '${(c.latitude + dLat).toStringAsFixed(5)},${(c.longitude + dLon).toStringAsFixed(5)}';
  }

  /// Étape 1 : liste des relations de la zone, classées par importance du réseau (ordre mélangé à égalité).
  static Future<_Zone?> _listerZone(LatLng centre, String profil, int distanceKm) async {
    // Zone de recherche : 30 km autour de la ville (les itinéraires qui ne passent pas à moins de 30 km sont ignorés).
    const demiKm = 30.0;
    final type = profil == 'vtt' ? 'mtb' : 'bicycle';
    final liste = await overpass('[out:json][timeout:25];relation["route"="$type"](${_bbox(centre, demiKm)});out tags;');
    if (liste == null) return null;
    final tous = <_Rel>[];
    final vus = <String>{};
    for (final e in (liste['elements'] as List? ?? const [])) {
      if (e is! Map<String, dynamic> || e['id'] is! int) continue;
      final tags = (e['tags'] as Map?)?.cast<String, dynamic>() ?? const {};
      final nom = ((tags['name'] ?? tags['ref']) as String?)?.trim();
      if (nom == null || nom.isEmpty || !vus.add(nom.toLowerCase())) continue;
      tous.add(_Rel(e['id'] as int, _niveau(tags['network'] as String?)));
    }
    tous.shuffle(math.Random());
    tous.sort((a, b) => b.niveau.compareTo(a.niveau));
    return _Zone(tous);
  }

  /// Étape 2 : charge la géométrie d'un lot de relations et range les tracés (retenus ou « bruts »).
  static Future<bool> _chargerLot(_Zone zone, List<_Rel> lot, LatLng centre, int distanceKm) async {
    final rayon = math.min(70.0, math.max(25.0, distanceKm * 0.9));
    final data = await overpass(
        '[out:json][timeout:60];relation(id:${lot.map((r) => r.id).join(',')});out geom(${_bbox(centre, rayon)});');
    if (data == null) return false;
    for (final e in (data['elements'] as List? ?? const [])) {
      if (e is! Map<String, dynamic>) continue;
      final tags = (e['tags'] as Map?)?.cast<String, dynamic>() ?? const {};
      final nom = (tags['name'] as String?)?.trim().isNotEmpty == true
          ? (tags['name'] as String).trim()
          : (tags['ref'] as String?)?.trim();
      if (nom == null || nom.isEmpty) continue;
      final trace = _recoller(_segments(e['members']));
      if (trace.length < 2) continue;
      final niveau = _niveau(tags['network'] as String?);
      final aj = _ajuster(trace, centre, distanceKm.toDouble(), 0.15);
      if (aj != null) {
        if (!zone.reserve.any((c) => c.cleBrut == nom)) {
          zone.reserve.add(_Candidat(nom + aj.suffixe, aj.pts, aj.km, niveau, nom));
        }
      } else {
        zone.bruts.add(_Brut(nom, niveau, trace));
      }
    }
    return true;
  }

  /// Tracés moins proches de la distance voulue (±35 %), utilisés seulement pour compléter la liste.
  static List<_Candidat> _lacher(_Zone zone, LatLng centre, int distanceKm) {
    final res = <_Candidat>[];
    for (final b in zone.bruts) {
      final aj = _ajuster(b.trace, centre, distanceKm.toDouble(), 0.35);
      if (aj != null) res.add(_Candidat(b.nom + aj.suffixe, aj.pts, aj.km, b.niveau, b.nom));
    }
    return res;
  }

  static int _nbLache(_Zone zone, LatLng centre, int distanceKm) =>
      zone.bruts.isEmpty ? 0 : _lacher(zone, centre, distanceKm).length;

  /// Adapte un tracé à la distance demandée (tolérance [tol]) :
  /// trop long -> on découpe un tronçon de la bonne longueur à partir du point le plus proche de la ville ;
  /// environ moitié moins long -> aller-retour ; trop court -> écarté.
  static _Ajuste? _ajuster(List<LatLng> trace, LatLng centre, double cible, double tol) {
    final total = _longueurKm(trace);
    if (total < 3) return null;
    // L'itinéraire doit passer à moins de 30 km de la ville.
    double dMin = double.infinity;
    for (final q in trace) {
      final d = _calc.as(LengthUnit.Kilometer, centre, q);
      if (d < dMin) dMin = d;
    }
    if (dMin > 30) return null;
    final bas = cible * (1 - tol), haut = cible * (1 + tol);
    if (total >= bas && total <= haut) return _Ajuste(trace, total, '');
    if (total > haut) {
      // Distances cumulées (km) et point le plus proche de la ville.
      final cum = List<double>.filled(trace.length, 0);
      for (int i = 1; i < trace.length; i++) {
        cum[i] = cum[i - 1] + _calc.as(LengthUnit.Meter, trace[i - 1], trace[i]) / 1000;
      }
      int proche = 0;
      double dMin = double.infinity;
      for (int i = 0; i < trace.length; i++) {
        final d = _calc.as(LengthUnit.Meter, centre, trace[i]);
        if (d < dMin) {
          dMin = d;
          proche = i;
        }
      }
      double debut;
      if (total - cum[proche] >= cible) {
        debut = cum[proche];
      } else if (cum[proche] >= cible) {
        debut = cum[proche] - cible;
      } else {
        debut = math.max(0, math.min(total - cible, cum[proche] - cible / 2));
      }
      final fin = debut + cible;
      final pts = <LatLng>[
        for (int i = 0; i < trace.length; i++)
          if (cum[i] >= debut && cum[i] <= fin) trace[i]
      ];
      if (pts.length < 2) return null;
      final km = _longueurKm(pts);
      if (km < bas) return null;
      return _Ajuste(pts, km, ' (tronçon)');
    }
    // Trop court : aller-retour si cela tombe dans la tolérance.
    if (total * 2 >= bas && total * 2 <= haut) {
      return _Ajuste([...trace, ...trace.reversed.skip(1)], total * 2, ' (aller-retour)');
    }
    return null;
  }

  static int _niveau(String? network) {
    switch (network) {
      case 'icn':
        return 4;
      case 'ncn':
        return 3;
      case 'rcn':
        return 2;
      case 'lcn':
        return 1;
      default:
        return 0;
    }
  }

  static String _libelle(int niveau) {
    switch (niveau) {
      case 4:
        return 'itinéraire international';
      case 3:
        return 'itinéraire national';
      case 2:
        return 'itinéraire régional';
      case 1:
        return 'itinéraire local';
      default:
        return 'itinéraire balisé';
    }
  }

  /// Tronçons (suites de points) des voies d'une relation, limités à la zone demandée.
  static List<List<LatLng>> _segments(dynamic members) {
    final res = <List<LatLng>>[];
    if (members is! List) return res;
    for (final m in members) {
      if (m is! Map || m['type'] != 'way') continue;
      final geom = m['geometry'];
      if (geom is! List) continue;
      var courant = <LatLng>[];
      for (final g in geom) {
        if (g is Map && g['lat'] is num && g['lon'] is num) {
          courant.add(LatLng((g['lat'] as num).toDouble(), (g['lon'] as num).toDouble()));
        } else {
          if (courant.length >= 2) res.add(courant);
          courant = <LatLng>[];
        }
      }
      if (courant.length >= 2) res.add(courant);
    }
    return res;
  }

  /// Recolle les tronçons bout à bout ; garde la plus longue chaîne continue (rapide : longueurs calculées une fois).
  static List<LatLng> _recoller(List<List<LatLng>> segments) {
    final n = segments.length;
    if (n == 0) return [];
    final cosLat = math.max(0.2, math.cos(segments.first.first.latitude * math.pi / 180));
    const tolDeg = 25.0 / 111320.0;
    const tol2 = tolDeg * tolDeg;
    bool proches(LatLng a, LatLng b) {
      final dy = a.latitude - b.latitude;
      final dx = (a.longitude - b.longitude) * cosLat;
      return dy * dy + dx * dx < tol2;
    }

    final longs = [for (final sg in segments) _longueurKm(sg)];
    final ordre = List<int>.generate(n, (i) => i)..sort((a, b) => longs[b].compareTo(longs[a]));

    List<LatLng> meilleure = [];
    double meilleureKm = -1;
    for (final g in ordre.take(4)) {
      final utilise = List<bool>.filled(n, false);
      utilise[g] = true;
      final fin = <LatLng>[...segments[g]]; // suite vers l'avant
      final tete = <LatLng>[]; // ajouts avant le début, stockés à l'envers
      double km = longs[g];
      bool avance = true;
      while (avance) {
        avance = false;
        for (int i = 0; i < n; i++) {
          if (utilise[i]) continue;
          final sg = segments[i];
          final debut = tete.isEmpty ? fin.first : tete.last;
          if (proches(fin.last, sg.first)) {
            fin.addAll(sg);
          } else if (proches(fin.last, sg.last)) {
            fin.addAll(sg.reversed);
          } else if (proches(debut, sg.last)) {
            tete.addAll(sg.reversed);
          } else if (proches(debut, sg.first)) {
            tete.addAll(sg);
          } else {
            continue;
          }
          utilise[i] = true;
          km += longs[i];
          avance = true;
        }
      }
      if (km > meilleureKm) {
        meilleureKm = km;
        meilleure = [...tete.reversed, ...fin];
      }
    }
    return meilleure;
  }

  static double _longueurKm(List<LatLng> pts) {
    double m = 0;
    for (int i = 1; i < pts.length; i++) {
      m += _calc.as(LengthUnit.Meter, pts[i - 1], pts[i]);
    }
    return m / 1000;
  }

  /// Altitude de ~100 points répartis le long du tracé (Open-Meteo), interpolée sur tous les points.
  /// Liste de null si le service ne répond pas.
  static Future<List<double?>> _altitudes(List<LatLng> pts) async {
    final vide = List<double?>.filled(pts.length, null);
    try {
      final n = math.min(100, pts.length);
      final idx = [for (int k = 0; k < n; k++) (k * (pts.length - 1) / (n - 1)).round()];
      final uri = Uri.https('api.open-meteo.com', '/v1/elevation', {
        'latitude': idx.map((i) => pts[i].latitude.toStringAsFixed(5)).join(','),
        'longitude': idx.map((i) => pts[i].longitude.toStringAsFixed(5)).join(','),
      });
      final r = await http.get(uri).timeout(const Duration(seconds: 10));
      if (r.statusCode != 200) return vide;
      final el = (json.decode(r.body)['elevation'] as List).map((e) => (e as num).toDouble()).toList();
      if (el.length != n) return vide;
      final res = List<double?>.filled(pts.length, null);
      for (int k = 0; k < n - 1; k++) {
        final a = idx[k], b = idx[k + 1];
        for (int i = a; i <= b; i++) {
          final t = b > a ? (i - a) / (b - a) : 0.0;
          res[i] = el[k] + (el[k + 1] - el[k]) * t;
        }
      }
      return res;
    } catch (_) {
      return vide;
    }
  }

  /// Requête Overpass : un serveur de plus est ajouté toutes les 2,5 s (ou tout de suite si un serveur échoue),
  /// le premier qui répond correctement gagne. Utilisable aussi par les autres services.
  static Future<Map<String, dynamic>?> overpass(String requete) {
    final fini = Completer<Map<String, dynamic>?>();
    int lances = 0;
    int echecs = 0;
    Timer? minuteur;

    void terminer(Map<String, dynamic>? v) {
      if (fini.isCompleted) return;
      minuteur?.cancel();
      fini.complete(v);
    }

    late void Function() lancer;

    void echec() {
      echecs++;
      if (echecs >= _serveurs.length) {
        terminer(null);
      } else {
        lancer();
      }
    }

    lancer = () {
      if (fini.isCompleted || lances >= _serveurs.length) return;
      final serveur = _serveurs[lances++];
      http
          .post(
            Uri.parse(serveur),
            headers: {
              'User-Agent': 'TrouveTonParcours/1.0 (application Android de parcours velo)',
              'Accept': 'application/json',
              'Content-Type': 'application/x-www-form-urlencoded; charset=utf-8',
            },
            body: {'data': requete},
          )
          .timeout(const Duration(seconds: 40))
          .then((r) {
        if (fini.isCompleted) return;
        if (r.statusCode != 200) {
          echec();
          return;
        }
        try {
          final j = json.decode(utf8.decode(r.bodyBytes));
          if (j is Map<String, dynamic> && j['elements'] is List) {
            terminer(j);
          } else {
            echec();
          }
        } catch (_) {
          echec();
        }
      }).catchError((_) {
        echec();
      });
    };

    lancer();
    minuteur = Timer.periodic(const Duration(milliseconds: 2500), (_) => lancer());
    return fini.future.timeout(const Duration(seconds: 60), onTimeout: () {
      minuteur?.cancel();
      return null;
    });
  }
}

class _Rel {
  final int id;
  final int niveau;
  _Rel(this.id, this.niveau);
}

class _Brut {
  final String nom;
  final int niveau;
  final List<LatLng> trace;
  _Brut(this.nom, this.niveau, this.trace);
}

class _Zone {
  final List<_Rel> rels;
  int pos = 0; // prochain itinéraire à charger
  int montres = 0; // nombre d'itinéraires déjà montrés
  final List<_Candidat> reserve = []; // prêts à être montrés (proches de la distance voulue)
  final List<_Brut> bruts = []; // tracés trop courts / trop longs, en secours
  _Zone(this.rels);
}

class _Candidat {
  final String nom;
  final List<LatLng> trace;
  final double km;
  final int niveau;
  final String cleBrut;
  _Candidat(this.nom, this.trace, this.km, this.niveau, this.cleBrut);
}

class _Ajuste {
  final List<LatLng> pts;
  final double km;
  final String suffixe;
  _Ajuste(this.pts, this.km, this.suffixe);
}
