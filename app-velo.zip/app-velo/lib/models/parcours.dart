class Parcours {
  final String titre;
  final String distance;
  final String duree;
  final String difficulte;
  final String ville;

  const Parcours({
    required this.titre,
    required this.distance,
    required this.duree,
    required this.difficulte,
    required this.ville,
  });
}
