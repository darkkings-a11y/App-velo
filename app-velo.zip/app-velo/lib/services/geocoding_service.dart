import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:latlong2/latlong.dart';

class GeocodingService {
  /// Interroge l'API Adresse (data.gouv.fr) pour trouver les coordonnées GPS d'une ville ou d'un code postal.
  static Future<LatLng?> recupererCoordonnees(String query) async {
    if (query.trim().isEmpty) return null;

    // Construction de l'URL sécurisée pour l'API officielle française
    final url = Uri.parse(
      'https://api-adresse.data.gouv.fr/search/?q=${Uri.encodeComponent(query)}&limit=1',
    );

    try {
      final response = await http.get(url);

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        final features = data['features'] as List;

        if (features.isNotEmpty) {
          // L'API renvoie les coordonnées sous format [longitude, latitude]
          final coords = features[0]['geometry']['coordinates'] as List;
          double longitude = coords[0];
          double latitude = coords[1];

          return LatLng(latitude, longitude);
        }
      }
    } catch (e) {
      // En cas de problème de réseau ou autre
      print('Erreur lors du géocodage : $e');
    }

    return null; // Retourne null si rien n'a été trouvé
  }
}
