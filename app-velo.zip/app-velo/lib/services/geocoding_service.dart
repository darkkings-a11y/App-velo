import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:latlong2/latlong.dart';

class GeocodingService {
  /// Interroge l'API Adresse (data.gouv.fr) pour trouver les coordonnées GPS d'une ville ou d'un code postal.
  static Future<LatLng?> recupererCoordonnees(String query) async {
    if (query.trim().isEmpty) return null;

    final url = Uri.parse(
      'https://api-adresse.data.gouv.fr/search/?q=${Uri.encodeComponent(query)}&limit=1',
    );

    try {
      // Ajout d'un User-Agent et Accept pour les API publiques françaises
      final response = await http.get(
        url,
        headers: {
          'User-Agent': 'AppVeloMobile/1.0',
          'Accept': 'application/json',
        },
      );

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        final features = data['features'] as List;

        if (features.isNotEmpty) {
          final coords = features[0]['geometry']['coordinates'] as List;
          double longitude = coords[0];
          double latitude = coords[1];
          return LatLng(latitude, longitude);
        } else {
          throw 'Aucun résultat trouvé pour cette ville.';
        }
      } else {
        throw 'Erreur HTTP : ${response.statusCode}';
      }
    } catch (e) {
      // On propage l'erreur pour identifier la cause exacte
      throw 'Erreur réseau : $e';
    }
  }
}

