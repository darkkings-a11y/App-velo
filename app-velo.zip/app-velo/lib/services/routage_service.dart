import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:latlong2/latlong.dart';

class RoutageService {
  /// Interroge l'API BRouter pour générer un parcours vélo à partir d'un point GPS.
  static Future<Map<String, dynamic>?> genererParcours({
    required double latitude,
    required double longitude,
    required int distanceKm,
  }) async {
    // Utilisation de l'API publique BRouter avec le profil vélo sécurisé ('safety')
    // On passe les coordonnées de départ
    final url = Uri.parse(
      'https://brouter.de/brouter?lonlats=$longitude,$latitude|$longitude,$latitude&profile=safety&format=geojson',
    );

    try {
      final response = await http.get(url);

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        final features = data['features'] as List;

        if (features.isNotEmpty) {
          final geometry = features[0]['geometry'];
          final coordinates = geometry['coordinates'] as List;
          
          // Conversion des coordonnées GeoJSON [lon, lat] en List<LatLng> pour flutter_map
          List<LatLng> trace = coordinates.map((coord) {
            return LatLng(coord[1], coord[0]);
          }).toList();

          // Récupération des propriétés du parcours (distance et dénivelé)
          final properties = features[0]['properties'];
          double distanceTotale = (properties['track-length'] ?? 0) / 1000.0; // Converti en km
          double denivelePositif = (properties['filtered-ascent'] ?? 0).toDouble(); // D+ en mètres

          return {
            'trace': trace,
            'distance': '${distanceTotale.toStringAsFixed(1)} km',
            'denivele': '${denivelePositif.round()}m D+',
          };
        }
      }
    } catch (e) {
      print('Erreur lors du calcul de l\'itinéraire BRouter : $e');
    }

    return null; // Retourne null si le calcul a échoué
  }
}
