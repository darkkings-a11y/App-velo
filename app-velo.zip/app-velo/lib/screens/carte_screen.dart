import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';

class CarteScreen extends StatelessWidget {
  final List<LatLng> trace;
  final String titre;
  final String distance;
  final String denivele;

  const CarteScreen({
    super.key,
    required this.trace,
    required this.titre,
    required this.distance,
    required this.denivele,
  });

  @override
  Widget build(BuildContext context) {
    // Centre la carte sur le premier point du tracé (ou position par défaut si vide)
    LatLng centreCarte = trace.isNotEmpty ? trace.first : const LatLng(45.75, 4.85);

    return Scaffold(
      appBar: AppBar(
        title: Text(titre),
        backgroundColor: Colors.green,
        foregroundColor: Colors.white,
      ),
      body: FlutterMap(
        options: MapOptions(
          initialCenter: centreCarte,
          initialZoom: 13.0,
        ),
        children: [
          // 1. Fond de carte CyclOSM (spécialisé pour le vélo, pistes cyclables et reliefs)
          TileLayer(
            urlTemplate: 'https://{s}.tile-cyclosm.openstreetmap.fr/cyclosm/{z}/{x}/{y}.png',
            subdomains: const ['a', 'b', 'c'],
            userAgentPackageName: 'com.example.app_velo',
          ),
          
          // 2. Tracé GPS du parcours en surbrillance bleue
          if (trace.isNotEmpty)
            PolylineLayer(
              polylines: [
                Polyline(
                  points: trace,
                  color: Colors.blueAccent,
                  strokeWidth: 5.0,
                ),
              ],
            ),
        ],
      ),
      
      // Panneau inférieur récapitulatif (Distance & Dénivelé)
      bottomSheet: Container(
        padding: const EdgeInsets.all(16.0),
        color: Colors.white,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            Row(
              children: [
                const Icon(Icons.straighten, color: Colors.green),
                const SizedBox(width: 8),
                Text(
                  'Distance : $distance',
                  style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                ),
              ],
            ),
            Row(
              children: [
                const Icon(Icons.terrain, color: Colors.orange),
                const SizedBox(width: 8),
                Text(
                  'Dénivelé : $denivele',
                  style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
