import 'package:flutter/material.dart';
import 'models/parcours.dart';

void main() {
  runApp(const AppVelo());
}

class AppVelo extends StatelessWidget {
  const AppVelo({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'App-velo',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: Colors.blueGrey,
          brightness: Brightness.light,
        ),
        scaffoldBackgroundColor: const Color(0xFFF8F9FA),
      ),
      home: const AccueilPage(),
    );
  }
}

class AccueilPage extends StatefulWidget {
  const AccueilPage({super.key});

  @override
  State<AccueilPage> createState() => _AccueilPageState();
}

class _AccueilPageState extends State<AccueilPage> {
  final TextEditingController _searchController = TextEditingController();
  String _rechercheActuelle = '';

  final List<Parcours> _tousLesParcours = const [
    Parcours(titre: 'Boucle des Lacs', distance: '15 km', duree: '1h15', difficulte: 'Facile', ville: 'Paris'),
    Parcours(titre: 'Montée du Col', distance: '28 km', duree: '2h30', difficulte: 'Difficile', ville: 'Lyon'),
    Parcours(titre: 'Chemin de Halage', distance: '12 km', duree: '0h50', difficulte: 'Très facile', ville: 'Nantes'),
    Parcours(titre: 'Corniche Côtière', distance: '22 km', duree: '1h45', difficulte: 'Moyen', ville: 'Marseille'),
  ];

  @override
  Widget build(BuildContext context) {
    final parcoursFiltres = _tousLesParcours.where((p) {
      final query = _rechercheActuelle.toLowerCase().trim();
      if (query.isEmpty) return true;
      return p.ville.toLowerCase().contains(query) || p.titre.toLowerCase().contains(query);
    }).toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'App-velo',
          style: TextStyle(fontWeight: FontWeight.w600, fontSize: 18),
        ),
        backgroundColor: Colors.white,
        elevation: 0,
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextField(
              controller: _searchController,
              onChanged: (value) {
                setState(() {
                  _rechercheActuelle = value;
                });
              },
              decoration: InputDecoration(
                hintText: 'Entrez une ville ou un code postal...',
                hintStyle: TextStyle(color: Colors.grey[400], fontSize: 14),
                prefixIcon: Icon(Icons.search, color: Colors.grey[600]),
                filled: true,
                fillColor: Colors.white,
                contentPadding: const EdgeInsets.symmetric(vertical: 14),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide(color: Colors.grey[300]!),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide(color: Colors.grey[300]!),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: const BorderSide(color: Colors.blueGrey, width: 1.5),
                ),
              ),
            ),
            const SizedBox(height: 24),
            Text(
              _rechercheActuelle.isEmpty 
                  ? 'Parcours populaires' 
                  : 'Résultats pour "${_rechercheActuelle}"',
              style: const TextStyle(
                fontSize: 15,
                fontWeight: FontWeight.bold,
                color: Colors.black87,
              ),
            ),
            const SizedBox(height: 12),
            Expanded(
              child: parcoursFiltres.isEmpty
                  ? Center(
                      child: Text(
                        'Aucun parcours trouvé.',
                        style: TextStyle(color: Colors.grey[500], fontSize: 14),
                      ),
                    )
                  : ListView.builder(
                      itemCount: parcoursFiltres.length,
                      itemBuilder: (context, index) {
                        final parcours = parcoursFiltres[index];
                        return Container(
                          margin: const EdgeInsets.only(bottom: 10),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: Colors.grey[200]!),
                          ),
                          child: ListTile(
                            contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                            leading: Container(
                              padding: const EdgeInsets.all(10),
                              decoration: BoxDecoration(
                                color: Colors.blueGrey[50],
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: const Icon(Icons.directions_bike, color: Colors.blueGrey, size: 20),
                            ),
                            title: Text(
                              parcours.titre,
                              style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14),
                            ),
                            subtitle: Padding(
                              padding: const EdgeInsets.only(top: 4.0),
                              child: Text(
                                '${parcours.ville} • ${parcours.distance} (${parcours.duree})',
                                style: TextStyle(color: Colors.grey[600], fontSize: 13),
                              ),
                            ),
                            trailing: Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                              decoration: BoxDecoration(
                                color: Colors.grey[100],
                                borderRadius: BorderRadius.circular(6),
                              ),
                              child: Text(
                                parcours.difficulte,
                                style: TextStyle(fontSize: 11, color: Colors.grey[700], fontWeight: FontWeight.w500),
                              ),
                            ),
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}

