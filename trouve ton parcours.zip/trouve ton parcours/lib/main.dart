
import 'package:flutter/material.dart';
import 'parcours_map_screen.dart'; // Ajuste l'import selon le nom de ton écran de carte

class AccueilScreen extends StatefulWidget {
  const AccueilScreen({super.key});

  @override
  State<AccueilScreen> createState() => _AccueilScreenState();
}

class _AccueilScreenState extends State<AccueilScreen> {
  final TextEditingController _villeController = TextEditingController();

  // Profil sélectionné par défaut ('balade', 'route' ou 'vtt')
  String _profilSelectionne = 'balade';

  // Distance sélectionnée par défaut (30 km) et liste de 10 à 100 km
  int _distanceSelectionnee = 30;
  final List<int> _distancesDisponibles = List.generate(10, (i) => (i + 1) * 10); // [10, 20, 30, ..., 100]

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Trouve ton parcours'),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const SizedBox(height: 10),

            // 1. Champ pour la ville / code postal
            TextField(
              controller: _villeController,
              decoration: InputDecoration(
                prefixIcon: const Icon(Icons.location_city),
                hintText: 'Ville ou code postal',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
              ),
            ),

            const SizedBox(height: 20),

            // 2. Choix du profil (Vélo route, Vélo balade, VTT) sur la même ligne
            const Text(
              'Type de parcours :',
              style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: _buildProfilChip(
                    id: 'route',
                    label: 'Route',
                    icon: Icons.directions_bike,
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: _buildProfilChip(
                    id: 'balade',
                    label: 'Balade',
                    icon: Icons.park,
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: _buildProfilChip(
                    id: 'vtt',
                    label: 'VTT',
                    icon: Icons.terrain,
                  ),
                ),
              ],
            ),

            const SizedBox(height: 20),

            // 3. Choix de la distance (de 10 km à 100 km)
            const Text(
              'Distance souhaitée :',
              style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
              decoration: BoxDecoration(
                border: Border.all(color: Colors.grey.shade700),
                borderRadius: BorderRadius.circular(12),
              ),
              child: DropdownButtonHideUnderline(
                child: DropdownButton<int>(
                  value: _distanceSelectionnee,
                  isExpanded: true,
                  icon: const Icon(Icons.arrow_drop_down),
                  items: _distancesDisponibles.map((int value) {
                    return DropdownMenuItem<int>(
                      value: value,
                      child: Text('$value km'),
                    );
                  }).toList(),
                  onChanged: (int? newValue) {
                    if (newValue != null) {
                      setState(() {
                        _distanceSelectionnee = newValue;
                      });
                    }
                  },
                ),
              ),
            ),

            const SizedBox(height: 30),

            // 4. Bouton "Trouver un parcours"
            ElevatedButton.icon(
              onPressed: () {
                if (_villeController.text.trim().isEmpty) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Veuillez entrer une ville ou un code postal')),
                  );
                  return;
                }

                // Transmission de la ville, du profil et de la distance à l'écran de carte
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => ParcoursMapScreen(
                      ville: _villeController.text.trim(),
                      profil: _profilSelectionne,
                      distanceKm: _distanceSelectionnee,
                    ),
                  ),
                );
              },
              icon: const Icon(Icons.pedal_bike, size: 24),
              label: const Text(
                'Trouver un parcours',
                style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
              ),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.green.shade700,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Petit widget interne pour dessiner les boutons de profil (chips)
  Widget _buildProfilChip({
    required String id,
    required String label,
    required IconData icon,
  }) {
    final bool isSelected = _profilSelectionne == id;
    return ChoiceChip(
      showCheckmark: false,
      avatar: Icon(
        icon,
        size: 18,
        color: isSelected ? Colors.white : Colors.grey.shade400,
      ),
      label: Text(
        label,
        style: TextStyle(
          color: isSelected ? Colors.white : Colors.grey.shade300,
          fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
        ),
      ),
      selected: isSelected,
      selectedColor: Colors.green.shade700,
      backgroundColor: Colors.grey.shade900,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10),
        side: BorderSide(
          color: isSelected ? Colors.green.shade700 : Colors.grey.shade700,
        ),
      ),
      onSelected: (bool selected) {
        if (selected) {
          setState(() {
            _profilSelectionne = id;
          });
        }
      },
    );
  }
}
