import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:latlong2/latlong.dart';

class RoutageService {
  static Future<Map<String, dynamic>?> genererParcours({
    required double latitude,
    required double longitude,
    required int distanceKm,
  }) async {
    // Exemple d'appel BRouter ou calcul de boucle
    // Assure-toi d'avoir un timeout de sécurité ici aussi :
    try {
      final url = Uri.parse(
        'https://brouter.de/brouter?lonlats=$longitude,$latitude|$longitude,$latitude&profile=safety&format=geojson',
      );

      final response = await http.get(url).timeout(const Duration(seconds: 15));

      if (response.statusCode == 200) {
        // Traitement de la réponse BRouter
        final data = json.decode(response.body);
        // ... ton code existant de parsing ...
        return {
          'distance': '$distanceKm km',
          'denivele': '350 m D+', // Exemple
          'trace': <LatLng>[],
        };
      } else {
        throw 'Erreur BRouter : ${response.statusCode}';
      }
    } catch (e) {
      print('Erreur de routage : $e');
      throw 'Erreur routage ou délai dépassé : $e';
    }
  }
}

