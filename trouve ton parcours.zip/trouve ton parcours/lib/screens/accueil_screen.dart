import 'package:flutter/material.dart';
import 'package:latlong2/latlong.dart';
import 'package:http/http.dart' as http;
import 'package:geolocator/geolocator.dart';
import 'dart:convert';
import '../models/parcours.dart';
import '../services/geocoding_service.dart';
import '../services/routage_service.dart';
import '../widgets/carte_parcours.dart';
import 'carte_screen.dart';

class AccueilScreen extends StatefulWidget {
  const AccueilScreen({super.key});

  @override
  State<AccueilScreen> createState() => _AccueilScreenState();
}

class _AccueilScreenState extends State<AccueilScreen> {
  final TextEditingController _villeController = TextEditingController();
  
  String _profilSelectionne = 'balade';
  int _distanceChoisie = 30;
  final List<int> _distancesDisponibles = List.generate(10, (i) => (i + 1) * 10);

  bool _isLoading = false;
  
  List<Parcours>? _resultatParcoursList;

  String? _meteoTemp;
  String? _meteoVent;
  String? _meteoDescription;
  bool _isLoadingMeteo = false;

  Future<void> _lancerRecherche() async {
    final nomVille = _villeController.text.trim();
    if (nomVille.isEmpty) return;

    setState(() {
      _isLoading = true;
      _isLoadingMeteo = true;
      _resultatParcoursList = null;
      _meteoTemp = null;
      _meteoVent = null;
      _meteoDescription = null;
    });

    try {
      LatLng? coords = await GeocodingService.recupererCoordonnees(nomVille);

      if (coords != null) {
        await Future.wait([
          _recupererMeteo(coords.latitude, coords.longitude),
          _genererParcoursEtRoutage(coords.latitude, coords.longitude, nomVille),
        ]);
      } else {
        _afficherErreur("Ville introuvable. Vérifie l'orthographe !");
      }
    } catch (e) {
      _afficherErreur(e.toString());
    } finally {
      setState(() {
        _isLoading = false;
        _isLoadingMeteo = false;
      });
    }
  }

  Future<void> _utiliserMaPosition() async {
    setState(() {
      _isLoading = true;
      _isLoadingMeteo = true;
      _resultatParcoursList = null;
      _meteoTemp = null;
      _meteoVent = null;
      _meteoDescription = null;
    });

    try {
      bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        _afficherErreur("Le service de localisation est désactivé sur votre appareil.");
        return;
      }

      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied) {
          _afficherErreur("Les permissions de localisation ont été refusées.");
          return;
        }
      }

      if (permission == LocationPermission.deniedForever) {
        _afficherErreur("Les permissions sont définitivement refusées, activez-les dans les réglages.");
        return;
      }

      Position position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
      );

      LatLng coords = LatLng(position.latitude, position.longitude);
      _villeController.text = "Ma position actuelle";

      await Future.wait([
        _recupererMeteo(coords.latitude, coords.longitude),
        _genererParcoursEtRoutage(coords.latitude, coords.longitude, "Ma position"),
      ]);
    } catch (e) {
      _afficherErreur("Impossible de récupérer la position : $e");
    } finally {
      setState(() {
        _isLoading = false;
        _isLoadingMeteo = false;
      });
    }
  }

  Future<void> _genererParcoursEtRoutage(double lat, double lon, String villeNom) async {
    final parcoursList = await RoutageService.genererParcours(
      latitude: lat,
      longitude: lon,
      distanceKm: _distanceChoisie,
      villeNom: villeNom,
    );

    setState(() {
      _resultatParcoursList = parcoursList;
    });
  }

  Future<void> _recupererMeteo(double lat, double lon) async {
    try {
      final url = Uri.parse(
        'https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current_weather=true',
      );
      final response = await http.get(url);
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        final currentWeather = data['current_weather'];
        setState(() {
          _meteoTemp = "${currentWeather['temperature']}°C";
          _meteoVent = "${currentWeather['windspeed']} km/h";
          int code = currentWeather['weathercode'];
          _meteoDescription = _traduireCodeMeteo(code);
        });
      }
    } catch (_) {}
  }

  String _traduireCodeMeteo(int code) {
    if (code == 0) return 'Grand soleil ☀️';
    if (code >= 1 && code <= 3) return 'Ciel voilé / Partiellement nuageux ⛅';
    if (code >= 45 && code <= 48) return 'Brumeux / Brouillard 🌫️';
    if (code >= 51 && code <= 67) return 'Risque de pluie 🌧️';
    if (code >= 71 && code <= 77) return 'Neige ❄️';
    if (code >= 95) return 'Orages ⚡';
    return 'Temps variable 🌤️';
  }

  void _afficherErreur(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Trouve ton parcours'),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextField(
              controller: _villeController,
              decoration: const InputDecoration(
                labelText: 'Ville ou code postal',
                hintText: 'Ex: Oullins, Lyon, Paris...',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.location_city),
              ),
            ),
            const SizedBox(height: 8),

            OutlinedButton.icon(
              onPressed: _isLoading ? null : _utiliserMaPosition,
              icon: const Icon(Icons.my_location, size: 18),
              label: const Text('Utiliser ma position actuelle'),
              style: OutlinedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 12),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
            ),
            const SizedBox(height: 20),

            const Text(
              'Type de parcours :',
              style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: _buildProfilChip(
                    id: 'route',
                    label: 'Route',
                    icon: Icons.directions_bike,
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: _buildProfilChip(
                    id: 'balade',
                    label: 'Balade',
                    icon: Icons.park,
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: _buildProfilChip(
                    id: 'vtt',
                    label: 'VTT',
                    icon: Icons.terrain,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),

            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('Distance souhaitée :', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                DropdownButton<int>(
                  value: _distanceChoisie,
                  items: _distancesDisponibles.map((int value) {
                    return DropdownMenuItem<int>(
                      value: value,
                      child: Text('$value km'),
                    );
                  }).toList(),
                  onChanged: (newValue) {
                    if (newValue != null) {
                      setState(() {
                        _distanceChoisie = newValue;
                      });
                    }
                  },
                ),
              ],
            ),
            const SizedBox(height: 24),

            ElevatedButton.icon(
              onPressed: _isLoading ? null : _lancerRecherche,
              icon: _isLoading 
                ? const SizedBox(
                    width: 20, 
                    height: 20, 
                    child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)
                  )
                : const Icon(Icons.directions_bike),
              label: Text(_isLoading ? 'Génération en cours...' : 'Trouver un parcours'),
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 14),
                textStyle: const TextStyle(fontSize: 16),
              ),
            ),
            const SizedBox(height: 24),

            if (_isLoadingMeteo) ...[
              const Center(child: CircularProgressIndicator()),
            ] else if (_meteoTemp != null) ...[
              Card(
                elevation: 3,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Row(
                        children: [
                          Icon(Icons.wb_sunny, color: Colors.orange),
                          SizedBox(width: 8),
                          Text(
                            'Météo sur place 🌤️',
                            style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                          ),
                        ],
                      ),
                      const Divider(height: 16),
                      Text('🌡️ Température : $_meteoTemp'),
                      Text('💨 Vent : $_meteoVent'),
                      Text('☁️ Conditions : $_meteoDescription'),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 16),
            ],

            // Affichage de la liste verticale des 5 parcours avec ParcoursCard
            if (_resultatParcoursList != null && _resultatParcoursList!.isNotEmpty) ...[
              const Text(
                '5 parcours générés avec succès ! 🎉',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 12),
              ..._resultatParcoursList!.map((parcours) => Padding(
                padding: const EdgeInsets.only(bottom: 12.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(left: 4.0, bottom: 4.0),
                      child: Text(
                        parcours.titre,
                        style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.greenAccent),
                      ),
                    ),
                    ParcoursCard(
                      distance: parcours.distance,
                      denivele: parcours.denivele,
                      nbPoints: parcours.traceGPS.length,
                      onVoirCarte: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => CarteScreen(
                              trace: parcours.traceGPS,
                              titre: parcours.titre,
                              distance: parcours.distance,
                              denivele: parcours.denivele,
                            ),
                          ),
                        );
                      },
                    ),
                  ],
                ),
              )).toList(),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildProfilChip({
    required String id,
    required String label,
    required IconData icon,
  }) {
    final bool isSelected = _profilSelectionne == id;
    return ChoiceChip(
      showCheckmark: false,
      avatar: Icon(
        icon,
        size: 18,
        color: isSelected ? Colors.white : Colors.grey.shade400,
      ),
      label: Text(
        label,
        style: TextStyle(
          fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
        ),
      ),
      selected: isSelected,
      selectedColor: Colors.green.shade700,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10),
      ),
      onSelected: (bool selected) {
        if (selected) {
          setState(() {
            _profilSelectionne = id;
          });
        }
      },
    );
  }
}

