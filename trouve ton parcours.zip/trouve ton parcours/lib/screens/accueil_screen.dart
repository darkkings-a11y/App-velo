import 'package:flutter/material.dart';
import 'package:latlong2/latlong.dart';
import '../services/geocoding_service.dart';
import '../services/routage_service.dart';

class AccueilScreen extends StatefulWidget {
  const AccueilScreen({super.key});

  @override
  State<AccueilScreen> createState() => _AccueilScreenState();
}

class _AccueilScreenState extends State<AccueilScreen> {
  final TextEditingController _villeController = TextEditingController();
  
  // Nouveautés intégrées
  String _profilSelectionne = 'balade'; // 'route', 'balade', 'vtt'
  int _distanceChoisie = 30; // Distance par défaut en km
  final List<int> _distancesDisponibles = List.generate(10, (i) => (i + 1) * 10); // [10, 20, ..., 100]

  bool _isLoading = false;
  
  String? _resultatDistance;
  String? _resultatDenivele;
  List<LatLng>? _resultatTrace;

  /// Fonction principale qui orchestre le géocodage puis le routage
  Future<void> _lancerRecherche() async {
    final nomVille = _villeController.text.trim();
    if (nomVille.isEmpty) return;

    setState(() {
      _isLoading = true;
      _resultatDistance = null;
      _resultatDenivele = null;
      _resultatTrace = null;
    });

    try {
      // Étape 1 : Récupérer les coordonnées GPS de la ville via data.gouv.fr
      LatLng? coords = await GeocodingService.recupererCoordonnees(nomVille);

      if (coords != null) {
        // Étape 2 : Générer la boucle vélo via BRouter
        final parcoursData = await RoutageService.genererParcours(
          latitude: coords.latitude,
          longitude: coords.longitude,
          distanceKm: _distanceChoisie,
          // Si ton RoutageService gère aussi le profil, tu peux le passer ici :
          // profil: _profilSelectionne,
        );

        if (parcoursData != null) {
          setState(() {
            _resultatDistance = parcoursData['distance'];
            _resultatDenivele = parcoursData['denivele'];
            _resultatTrace = parcoursData['trace'];
          });
        } else {
          _afficherErreur("Impossible de générer le parcours pour cette zone.");
        }
      } else {
        _afficherErreur("Ville introuvable. Vérifie l'orthographe !");
      }
    } catch (e) {
      _afficherErreur(e.toString());
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  void _afficherErreur(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Trouve ton parcours'),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Champ de saisie de la ville
            TextField(
              controller: _villeController,
              decoration: const InputDecoration(
                labelText: 'Ville ou code postal',
                hintText: 'Ex: Oullins, Lyon, Paris...',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.location_city),
              ),
            ),
            const SizedBox(height: 20),

            // Choix du profil (Vélo route, Vélo balade, VTT) sur la même ligne
            const Text(
              'Type de parcours :',
              style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: _buildProfilChip(
                    id: 'route',
                    label: 'Route',
                    icon: Icons.directions_bike,
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: _buildProfilChip(
                    id: 'balade',
                    label: 'Balade',
                    icon: Icons.park,
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: _buildProfilChip(
                    id: 'vtt',
                    label: 'VTT',
                    icon: Icons.terrain,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),

            // Sélection de la distance (de 10 à 100 km)
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('Distance souhaitée :', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                DropdownButton<int>(
                  value: _distanceChoisie,
                  items: _distancesDisponibles.map((int value) {
                    return DropdownMenuItem<int>(
                      value: value,
                      child: Text('$value km'),
                    );
                  }).toList(),
                  onChanged: (newValue) {
                    if (newValue != null) {
                      setState(() {
                        _distanceChoisie = newValue;
                      });
                    }
                  },
                ),
              ],
            ),
            const SizedBox(height: 24),

            // Bouton de génération
            ElevatedButton.icon(
              onPressed: _isLoading ? null : _lancerRecherche,
              icon: _isLoading 
                ? const SizedBox(
                    width: 20, 
                    height: 20, 
                    child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)
                  )
                : const Icon(Icons.directions_bike),
              label: Text(_isLoading ? 'Génération en cours...' : 'Trouver un parcours'),
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 14),
                textStyle: const TextStyle(fontSize: 16),
              ),
            ),
            const SizedBox(height: 24),

            // Affichage des résultats temporaires
            if (_resultatDistance != null) ...[
              Card(
                elevation: 3,
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Parcours généré avec succès ! 🎉',
                        style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 8),
                      Text('📏 Distance : $_resultatDistance'),
                      Text('⛰️ Dénivelé : $_resultatDenivele'),
                      Text('📍 Points GPS calculés : ${_resultatTrace?.length ?? 0} points'),
                    ],
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  // Widget personnalisé pour les boutons de profil (chips)
  Widget _buildProfilChip({
    required String id,
    required String label,
    required IconData icon,
  }) {
    final bool isSelected = _profilSelectionne == id;
    return ChoiceChip(
      showCheckmark: false,
      avatar: Icon(
        icon,
        size: 18,
        color: isSelected ? Colors.white : Colors.grey.shade400,
      ),
      label: Text(
        label,
        style: TextStyle(
          fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
        ),
      ),
      selected: isSelected,
      selectedColor: Colors.green.shade700,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10),
      ),
      onSelected: (bool selected) {
        if (selected) {
          setState(() {
            _profilSelectionne = id;
          });
        }
      },
    );
  }
}

