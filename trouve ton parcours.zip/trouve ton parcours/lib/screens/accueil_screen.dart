import 'package:flutter/material.dart';
import 'package:latlong2/latlong.dart';
import 'package:http/http.dart' as http;
import 'package:geolocator/geolocator.dart';
import 'dart:convert';
import '../services/geocoding_service.dart';
import '../services/routage_service.dart';

class AccueilScreen extends StatefulWidget {
  const AccueilScreen({super.key});

  @override
  State<AccueilScreen> createState() => _AccueilScreenState();
}

class _AccueilScreenState extends State<AccueilScreen> {
  final TextEditingController _villeController = TextEditingController();
  
  // Nouveautés intégrées
  String _profilSelectionne = 'balade'; // 'route', 'balade', 'vtt'
  int _distanceChoisie = 30; // Distance par défaut en km
  final List<int> _distancesDisponibles = List.generate(10, (i) => (i + 1) * 10); // [10, 20, ..., 100]

  bool _isLoading = false;
  
  String? _resultatDistance;
  String? _resultatDenivele;
  List<LatLng>? _resultatTrace;

  // Variables pour la météo
  String? _meteoTemp;
  String? _meteoVent;
  String? _meteoDescription;
  bool _isLoadingMeteo = false;

  /// Fonction principale qui orchestre le géocodage, la météo et le routage via le texte
  Future<void> _lancerRecherche() async {
    final nomVille = _villeController.text.trim();
    if (nomVille.isEmpty) return;

    setState(() {
      _isLoading = true;
      _isLoadingMeteo = true;
      _resultatDistance = null;
      _resultatDenivele = null;
      _resultatTrace = null;
      _meteoTemp = null;
      _meteoVent = null;
      _meteoDescription = null;
    });

    try {
      // Étape 1 : Récupérer les coordonnées GPS de la ville via data.gouv.fr
      LatLng? coords = await GeocodingService.recupererCoordonnees(nomVille);

      if (coords != null) {
        // Lancer en parallèle la météo et la génération du parcours
        await Future.wait([
          _recupererMeteo(coords.latitude, coords.longitude),
          _genererParcoursEtRoutage(coords.latitude, coords.longitude),
        ]);
      } else {
        _afficherErreur("Ville introuvable. Vérifie l'orthographe !");
      }
    } catch (e) {
      _afficherErreur(e.toString());
    } finally {
      setState(() {
        _isLoading = false;
        _isLoadingMeteo = false;
      });
    }
  }

  /// Fonction pour utiliser la géolocalisation GPS du téléphone
  Future<void> _utiliserMaPosition() async {
    setState(() {
      _isLoading = true;
      _isLoadingMeteo = true;
      _resultatDistance = null;
      _resultatDenivele = null;
      _resultatTrace = null;
      _meteoTemp = null;
      _meteoVent = null;
      _meteoDescription = null;
    });

    try {
      // 1. Vérifier si le service de localisation est activé
      bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        _afficherErreur("Le service de localisation est désactivé sur votre appareil.");
        return;
      }

      // 2. Vérifier et demander les permissions
      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied) {
          _afficherErreur("Les permissions de localisation ont été refusées.");
          return;
        }
      }

      if (permission == LocationPermission.deniedForever) {
        _afficherErreur("Les permissions sont définitivement refusées, activez-les dans les réglages.");
        return;
      }

      // 3. Récupérer la position actuelle
      Position position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
      );

      LatLng coords = LatLng(position.latitude, position.longitude);
      _villeController.text = "Ma position actuelle";

      // 4. Lancer météo et routage en parallèle avec ces coordonnées GPS
      await Future.wait([
        _recupererMeteo(coords.latitude, coords.longitude),
        _genererParcoursEtRoutage(coords.latitude, coords.longitude),
      ]);
    } catch (e) {
      _afficherErreur("Impossible de récupérer la position : $e");
    } finally {
      setState(() {
        _isLoading = false;
        _isLoadingMeteo = false;
      });
    }
  }

  // Sous-fonction pour garder le routage d'origine intact
  Future<void> _genererParcoursEtRoutage(double lat, double lon) async {
    final parcoursData = await RoutageService.genererParcours(
      latitude: lat,
      longitude: lon,
      distanceKm: _distanceChoisie,
    );

    if (parcoursData != null) {
      setState(() {
        _resultatDistance = parcoursData['distance'];
        _resultatDenivele = parcoursData['denivele'];
        _resultatTrace = parcoursData['trace'];
      });
    } else {
      _afficherErreur("Impossible de générer le parcours pour cette zone.");
    }
  }

  // Récupération de la météo (Open-Meteo, 100% gratuit, sans clé)
  Future<void> _recupererMeteo(double lat, double lon) async {
    try {
      final url = Uri.parse(
        'https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current_weather=true',
      );
      final response = await http.get(url);
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        final currentWeather = data['current_weather'];
        setState(() {
          _meteoTemp = "${currentWeather['temperature']}°C";
          _meteoVent = "${currentWeather['windspeed']} km/h";
          int code = currentWeather['weathercode'];
          _meteoDescription = _traduireCodeMeteo(code);
        });
      }
    } catch (_) {
      // Échec silencieux pour ne pas bloquer l'application
    }
  }

  String _traduireCodeMeteo(int code) {
    if (code == 0) return 'Grand soleil ☀️';
    if (code >= 1 && code <= 3) return 'Ciel voilé / Partiellement nuageux ⛅';
    if (code >= 45 && code <= 48) return 'Brumeux / Brouillard 🌫️';
    if (code >= 51 && code <= 67) return 'Risque de pluie 🌧️';
    if (code >= 71 && code <= 77) return 'Neige ❄️';
    if (code >= 95) return 'Orages ⚡';
    return 'Temps variable 🌤️';
  }

  void _afficherErreur(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Trouve ton parcours'),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Champ de saisie de la ville
            TextField(
              controller: _villeController,
              decoration: const InputDecoration(
                labelText: 'Ville ou code postal',
                hintText: 'Ex: Oullins, Lyon, Paris...',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.location_city),
              ),
            ),
            const SizedBox(height: 8),

            // Bouton de géolocalisation placé juste en dessous
            OutlinedButton.icon(
              onPressed: _isLoading ? null : _utiliserMaPosition,
              icon: const Icon(Icons.my_location, size: 18),
              label: const Text('Utiliser ma position actuelle'),
              style: OutlinedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 12),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
            ),
            const SizedBox(height: 20),

            // Choix du profil (Vélo route, Vélo balade, VTT) sur la même ligne
            const Text(
              'Type de parcours :',
              style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: _buildProfilChip(
                    id: 'route',
                    label: 'Route',
                    icon: Icons.directions_bike,
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: _buildProfilChip(
                    id: 'balade',
                    label: 'Balade',
                    icon: Icons.park,
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: _buildProfilChip(
                    id: 'vtt',
                    label: 'VTT',
                    icon: Icons.terrain,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),

            // Sélection de la distance (de 10 à 100 km)
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('Distance souhaitée :', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                DropdownButton<int>(
                  value: _distanceChoisie,
                  items: _distancesDisponibles.map((int value) {
                    return DropdownMenuItem<int>(
                      value: value,
                      child: Text('$value km'),
                    );
                  }).toList(),
                  onChanged: (newValue) {
                    if (newValue != null) {
                      setState(() {
                        _distanceChoisie = newValue;
                      });
                    }
                  },
                ),
              ],
            ),
            const SizedBox(height: 24),

            // Bouton de génération
            ElevatedButton.icon(
              onPressed: _isLoading ? null : _lancerRecherche,
              icon: _isLoading 
                ? const SizedBox(
                    width: 20, 
                    height: 20, 
                    child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)
                  )
                : const Icon(Icons.directions_bike),
              label: Text(_isLoading ? 'Génération en cours...' : 'Trouver un parcours'),
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 14),
                textStyle: const TextStyle(fontSize: 16),
              ),
            ),
            const SizedBox(height: 24),

            // Affichage de la météo en bas
            if (_isLoadingMeteo) ...[
              const Center(child: CircularProgressIndicator()),
            ] else if (_meteoTemp != null) ...[
              Card(
                elevation: 3,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Row(
                        children: [
                          Icon(Icons.wb_sunny, color: Colors.orange),
                          SizedBox(width: 8),
                          Text(
                            'Météo sur place 🌤️',
                            style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                          ),
                        ],
                      ),
                      const Divider(height: 16),
                      Text('🌡️ Température : $_meteoTemp'),
                      Text('💨 Vent : $_meteoVent'),
                      Text('☁️ Conditions : $_meteoDescription'),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 16),
            ],

            // Affichage des résultats temporaires du parcours
            if (_resultatDistance != null) ...[
              Card(
                elevation: 3,
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Parcours généré avec succès ! 🎉',
                        style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 8),
                      Text('📏 Distance : $_resultatDistance'),
                      Text('⛰️ Dénivelé : $_resultatDenivele'),
                      Text('📍 Points GPS calculés : ${_resultatTrace?.length ?? 0} points'),
                    ],
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  // Widget personnalisé pour les boutons de profil (chips)
  Widget _buildProfilChip({
    required String id,
    required String label,
    required IconData icon,
  }) {
    final bool isSelected = _profilSelectionne == id;
    return ChoiceChip(
      showCheckmark: false,
      avatar: Icon(
        icon,
        size: 18,
        color: isSelected ? Colors.white : Colors.grey.shade400,
      ),
      label: Text(
        label,
        style: TextStyle(
          fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
        ),
      ),
      selected: isSelected,
      selectedColor: Colors.green.shade700,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10),
      ),
      onSelected: (bool selected) {
        if (selected) {
          setState(() {
            _profilSelectionne = id;
          });
        }
      },
    );
  }
}

