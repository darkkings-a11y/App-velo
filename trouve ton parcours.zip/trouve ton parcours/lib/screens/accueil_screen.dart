import 'package:flutter/material.dart';
import 'package:latlong2/latlong.dart';
import '../services/geocoding_service.dart';
import '../services/routage_service.dart';

class AccueilScreen extends StatefulWidget {
  const AccueilScreen({super.key});

  @override
  State<AccueilScreen> createState() => _AccueilScreenState();
}

class _AccueilScreenState extends State<AccueilScreen> {
  final TextEditingController _villeController = TextEditingController();
  int _distanceChoisie = 30; // Distance par défaut en km
  bool _isLoading = false;
  
  String? _resultatDistance;
  String? _resultatDenivele;
  List<LatLng>? _resultatTrace;

  /// Fonction principale qui orchestre le géocodage puis le routage
  Future<void> _lancerRecherche() async {
    final nomVille = _villeController.text.trim();
    if (nomVille.isEmpty) return;

    setState(() {
      _isLoading = true;
      _resultatDistance = null;
      _resultatDenivele = null;
      _resultatTrace = null;
    });

    try {
      // Étape 1 : Récupérer les coordonnées GPS de la ville via data.gouv.fr
      LatLng? coords = await GeocodingService.recupererCoordonnees(nomVille);

      if (coords != null) {
        // Étape 2 : Générer la boucle vélo via BRouter
        final parcoursData = await RoutageService.genererParcours(
          latitude: coords.latitude,
          longitude: coords.longitude,
          distanceKm: _distanceChoisie,
        );

        if (parcoursData != null) {
          setState(() {
            _resultatDistance = parcoursData['distance'];
            _resultatDenivele = parcoursData['denivele'];
            _resultatTrace = parcoursData['trace'];
          });
        } else {
          _afficherErreur("Impossible de générer le parcours pour cette zone.");
        }
      } else {
        _afficherErreur("Ville introuvable. Vérifie l'orthographe !");
      }
    } catch (e) {
      _afficherErreur(e.toString());
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  void _afficherErreur(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('App-velo'),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Champ de saisie de la ville
            TextField(
              controller: _villeController,
              decoration: const InputDecoration(
                labelText: 'Ville ou code postal',
                hintText: 'Ex: Oullins, Lyon, Paris...',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.location_city),
              ),
            ),
            const SizedBox(height: 16),

            // Sélection de la distance
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('Distance souhaitée :', style: TextStyle(fontSize: 16)),
                DropdownButton<int>(
                  value: _distanceChoisie,
                  items: [20, 30, 50, 80].map((int value) {
                    return DropdownMenuItem<int>(
                      value: value,
                      child: Text('$value km'),
                    );
                  }).toList(),
                  onChanged: (newValue) {
                    setState(() {
                      _distanceChoisie = newValue!;
                    });
                  },
                ),
              ],
            ),
            const SizedBox(height: 24),

            // Bouton de génération
            ElevatedButton.icon(
              onPressed: _isLoading ? null : _lancerRecherche,
              icon: _isLoading 
                ? const SizedBox(
                    width: 20, 
                    height: 20, 
                    child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)
                  )
                : const Icon(Icons.directions_bike),
              label: Text(_isLoading ? 'Génération en cours...' : 'Trouver un parcours'),
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 14),
                textStyle: const TextStyle(fontSize: 16),
              ),
            ),
            const SizedBox(height: 24),

            // Affichage des résultats temporaires
            if (_resultatDistance != null) ...[
              Card(
                elevation: 3,
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Parcours généré avec succès ! 🎉',
                        style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 8),
                      Text('📏 Distance : $_resultatDistance'),
                      Text('⛰️ Dénivelé : $_resultatDenivele'),
                      Text('📍 Points GPS calculés : ${_resultatTrace?.length ?? 0} points'),
                    ],
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

