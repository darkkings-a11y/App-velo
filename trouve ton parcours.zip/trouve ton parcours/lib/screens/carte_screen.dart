import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';

class CarteScreen extends StatelessWidget {
  final List<LatLng> trace;
  final String titre;
  final String distance;
  final String denivele;

  const CarteScreen({
    super.key,
    required this.trace,
    required this.titre,
    required this.distance,
    required this.denivele,
  });

  @override
  Widget build(BuildContext context) {
    // Centre la carte sur le premier point du tracé (ou position par défaut si vide)
    LatLng centreCarte = trace.isNotEmpty ? trace.first : const LatLng(45.75, 4.85);

    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: Text(
          titre,
          style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.black,
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: FlutterMap(
        options: MapOptions(
          initialCenter: centreCarte,
          initialZoom: 13.0,
        ),
        children: [
          // 1. Fond de carte CyclOSM (spécialisé pour le vélo, pistes cyclables et reliefs)
          TileLayer(
            urlTemplate: 'https://{s}.tile-cyclosm.openstreetmap.fr/cyclosm/{z}/{x}/{y}.png',
            subdomains: const ['a', 'b', 'c'],
            userAgentPackageName: 'com.example.app_velo',
          ),
          
          // 2. Tracé GPS du parcours en surbrillance bleue
          if (trace.isNotEmpty)
            PolylineLayer(
              polylines: [
                Polyline(
                  points: trace,
                  color: Colors.blueAccent,
                  strokeWidth: 5.0,
                ),
              ],
            ),
        ],
      ),
      
      // Panneau inférieur récapitulatif (Distance, Dénivelé & Bouton Enregistrer)
      bottomSheet: Container(
        padding: const EdgeInsets.all(20.0),
        decoration: const BoxDecoration(
          color: Color(0xFF121212),
          borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Statistiques (Distance & Dénivelé)
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Row(
                  children: [
                    const Icon(Icons.straighten, color: Colors.greenAccent),
                    const SizedBox(width: 8),
                    Text(
                      'Distance : $distance',
                      style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15),
                    ),
                  ],
                ),
                Row(
                  children: [
                    const Icon(Icons.terrain, color: Colors.orangeAccent),
                    const SizedBox(width: 8),
                    Text(
                      'Dénivelé : $denivele',
                      style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15),
                    ),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 16),

            // Bouton Enregistrer
            SizedBox(
              width: double.infinity,
              height: 48,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  elevation: 2,
                ),
                onPressed: () {
                  // Action d'enregistrement local (à lier avec la base de données par la suite)
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('Parcours enregistré dans vos favoris !'),
                      backgroundColor: Colors.green,
                    ),
                  );
                },
                child: const Text(
                  'Enregistrer',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

