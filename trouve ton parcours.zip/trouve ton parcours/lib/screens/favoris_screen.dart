import 'package:flutter/material.dart';
import 'carte_screen.dart';

class FavorisScreen extends StatelessWidget {
  const FavorisScreen({super.key});

  @override
  Widget build(BuildContext context) {
    // Pour l'instant, liste vide ou exemple (à relier à ton stockage local plus tard)
    final List<Map<String, dynamic>> favoris = [];

    return Scaffold(
      appBar: AppBar(
        title: const Text('Mes parcours favoris'),
        backgroundColor: Colors.green,
        foregroundColor: Colors.white,
      ),
      body: favoris.isEmpty
          ? Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: const [
                  Icon(Icons.bookmark_border, size: 64, color: Colors.grey),
                  SizedBox(height: 16),
                  Text(
                    'Aucun favori pour le moment.',
                    style: TextStyle(fontSize: 18, color: Colors.grey),
                  ),
                  SizedBox(height: 8),
                  Text(
                    'Enregistre tes boucles depuis l\'accueil !',
                    style: TextStyle(fontSize: 14, color: Colors.grey),
                  ),
                ],
              ),
            )
          : ListView.builder(
              itemCount: favoris.length,
              itemBuilder: (context, index) {
                final parcours = favoris[index];
                return Card(
                  margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  child: ListTile(
                    leading: const Icon(Icons.directions_bike, color: Colors.green),
                    title: Text(parcours['titre'] ?? 'Parcours vélo'),
                    subtitle: Text('Distance : ${parcours['distance']} | D+ : ${parcours['denivele']}'),
                    trailing: const Icon(Icons.arrow_forward_ios, size: 16),
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => CarteScreen(
                            trace: parcours['trace'],
                            titre: parcours['titre'],
                            distance: parcours['distance'],
                            denivele: parcours['denivele'],
                          ),
                        ),
                      );
                    },
                  ),
                );
              },
            ),
    );
  }
}
