import 'package:latlong2/latlong.dart';

class Parcours {
  final String titre;
  final String distance;
  final String duree;
  final String difficulte;
  final String ville;
  final String denivele; // Pour afficher le D+ (ex: 450m D+)
  final List<LatLng> traceGPS; // La liste des points de la boucle pour la carte

  const Parcours({
    required this.titre,
    required this.distance,
    required this.duree,
    required this.difficulte,
    required this.ville,
    required this.denivele,
    required this.traceGPS,
  });
}

