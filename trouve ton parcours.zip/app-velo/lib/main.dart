
import 'package:flutter/material.dart';
import 'screens/accueil_screen.dart';

void main() {
  runApp(const AppVelo());
}

class AppVelo extends StatelessWidget {
  const AppVelo({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'App-velo',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: Colors.green,
          brightness: Brightness.dark, // Passage en mode sombre
        ),
        useMaterial3: true,
      ),
      home: const AccueilScreen(),
    );
  }
}
