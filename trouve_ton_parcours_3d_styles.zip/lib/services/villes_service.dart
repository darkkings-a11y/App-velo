import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:latlong2/latlong.dart';

class VillesService {
  /// Retourne le nom de la commune qui contient ce point (API geo.api.gouv.fr).
  static Future<String?> nomCommune(LatLng p) async {
    try {
      final uri = Uri.https('geo.api.gouv.fr', '/communes', {
        'lat': p.latitude.toString(),
        'lon': p.longitude.toString(),
        'fields': 'nom',
        'format': 'json',
      });
      final r = await http.get(uri).timeout(const Duration(seconds: 8));
      if (r.statusCode != 200) return null;
      final liste = json.decode(r.body) as List;
      if (liste.isEmpty) return null;
      return liste.first['nom'] as String?;
    } catch (_) {
      return null;
    }
  }
}
