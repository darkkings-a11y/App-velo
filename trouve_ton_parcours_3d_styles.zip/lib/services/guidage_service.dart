import 'package:latlong2/latlong.dart';

enum TypeVirage { gauche, droite, legerGauche, legerDroite, demiTour }

/// Un virage détecté le long d'un tracé.
class Virage {
  final int index;
  final double cumM; // distance depuis le début du tracé, en mètres
  final TypeVirage type;

  const Virage({required this.index, required this.cumM, required this.type});

  String get texte {
    switch (type) {
      case TypeVirage.gauche:
        return 'Tournez à gauche';
      case TypeVirage.droite:
        return 'Tournez à droite';
      case TypeVirage.legerGauche:
        return 'Tournez légèrement à gauche';
      case TypeVirage.legerDroite:
        return 'Tournez légèrement à droite';
      case TypeVirage.demiTour:
        return 'Faites demi-tour';
    }
  }
}

class Guidage {
  static final Distance _d = Distance(roundResult: false);

  /// Distance cumulée (en mètres) pour chaque point du tracé.
  static List<double> cumulM(List<LatLng> pts) {
    final cum = <double>[];
    double total = 0;
    for (int i = 0; i < pts.length; i++) {
      if (i > 0) total += _d.as(LengthUnit.Meter, pts[i - 1], pts[i]);
      cum.add(total);
    }
    return cum;
  }

  /// Détecte les vrais virages (changement de direction net sur ~50 m).
  /// Les courbes douces ne comptent pas comme des virages.
  static List<Virage> detecterVirages(List<LatLng> pts, List<double> cum) {
    final n = pts.length;
    if (n < 3 || cum.length != n) return const [];
    const fenetre = 25.0;
    const seuil = 35.0;

    final delta = List<double>.filled(n, 0);
    for (int i = 1; i < n - 1; i++) {
      int a = i;
      while (a > 0 && cum[i] - cum[a] < fenetre) {
        a--;
      }
      int b = i;
      while (b < n - 1 && cum[b] - cum[i] < fenetre) {
        b++;
      }
      if (a == i || b == i) continue;
      final entree = _d.bearing(pts[a], pts[i]);
      final sortie = _d.bearing(pts[i], pts[b]);
      delta[i] = ((sortie - entree + 540) % 360) - 180; // + = droite, - = gauche
    }

    final res = <Virage>[];
    int i = 1;
    while (i < n - 1) {
      if (delta[i].abs() < seuil) {
        i++;
        continue;
      }
      // groupe de points consécutifs au-dessus du seuil : on garde le plus marqué
      int meilleur = i;
      int j = i;
      while (j < n - 1 && delta[j].abs() >= seuil) {
        if (delta[j].abs() > delta[meilleur].abs()) meilleur = j;
        j++;
      }
      final angle = delta[meilleur];
      final abs = angle.abs();
      final TypeVirage type;
      if (abs >= 150) {
        type = TypeVirage.demiTour;
      } else if (abs >= 65) {
        type = angle > 0 ? TypeVirage.droite : TypeVirage.gauche;
      } else {
        type = angle > 0 ? TypeVirage.legerDroite : TypeVirage.legerGauche;
      }
      if (res.isEmpty || cum[meilleur] - res.last.cumM > 30) {
        res.add(Virage(index: meilleur, cumM: cum[meilleur], type: type));
      }
      i = j;
    }
    return res;
  }

  static String formaterDistance(double m) {
    if (m < 1000) {
      final arrondi = m < 100 ? (m / 10).round() * 10 : (m / 50).round() * 50;
      return '${arrondi.toInt()} m';
    }
    return '${(m / 1000).toStringAsFixed(1).replaceAll('.', ',')} km';
  }
}
