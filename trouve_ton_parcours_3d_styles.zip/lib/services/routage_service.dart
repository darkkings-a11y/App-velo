import 'dart:convert';
import 'dart:math' as math;
import 'package:http/http.dart' as http;
import 'package:latlong2/latlong.dart';
import '../models/parcours.dart';
import 'villes_service.dart';

class _Trace {
  final List<LatLng> points;
  final List<double> altitudes;
  final List<double> distancesKm;
  final double partChemins; // 0..1 : part du trajet sur chemins / pistes non revêtus

  _Trace(this.points, this.altitudes, this.distancesKm, [this.partChemins = 0]);

  double get totalKm => distancesKm.isEmpty ? 0 : distancesKm.last;
}

class RoutageService {
  static final Distance _calc = Distance(roundResult: false);
  static final math.Random _rng = math.Random();
  static String? _derniereErreur;

  /// Message à montrer à l'utilisateur si un style n'a pas pu être appliqué entièrement.
  static String? note;

  // Part de chemins (0..1) de chaque parcours généré, pour classer les résultats.
  static final Expando<double> _partChemins = Expando<double>();

  // Profil VTT personnalisé envoyé au serveur BRouter (identifiant gardé en mémoire).
  static String? _idProfilVtt;

  /// Génère de vraies boucles routières (BRouter) autour du point de départ.
  static Future<List<Parcours>> genererParcours({
    required double latitude,
    required double longitude,
    required int distanceKm,
    required String villeNom,
    String profil = 'balade',
  }) async {
    _derniereErreur = null;
    note = null;
    final depart = LatLng(latitude, longitude);
    final nomDepart = (await VillesService.nomCommune(depart)) ?? villeNom;
    final base = _rng.nextInt(360);

    final resultats = await Future.wait(List.generate(5, (i) {
      return _construireParcours(
        depart: depart,
        nomDepart: nomDepart,
        distanceKm: distanceKm,
        profil: profil,
        cap: ((base + i * 72) % 360).toDouble(),
      );
    }));

    final liste = resultats.whereType<Parcours>().toList();
    if (liste.isEmpty) {
      throw 'Aucun parcours calculé. ${_derniereErreur ?? ''}';
    }

    // On met en premier ceux qui collent le mieux au style demandé.
    double score(Parcours p) {
      final pente = p.distanceKm > 0 ? p.denivelePos / p.distanceKm : 0.0;
      switch (profil) {
        case 'route': // sportif : ça grimpe
          return pente;
        case 'vtt': // chemins d'abord, puis du relief
          return (_partChemins[p] ?? 0) * 100 + pente * 0.5;
        default: // balade : le plus plat possible
          return -pente;
      }
    }

    liste.sort((a, b) => score(b).compareTo(score(a)));
    return liste;
  }

  static Future<Parcours?> _construireParcours({
    required LatLng depart,
    required String nomDepart,
    required int distanceKm,
    required String profil,
    required double cap,
  }) async {
    try {
      double facteur = 1.35;
      _Trace? meilleure;

      // On ajuste la taille de la boucle pour approcher la distance demandée.
      for (int essai = 0; essai < 3; essai++) {
        final waypoints = _pointsDeBoucle(depart, distanceKm.toDouble(), cap, facteur);
        final trace = await _calculerTrace(waypoints, _profilsBrouter(profil));
        if (meilleure == null ||
            (trace.totalKm - distanceKm).abs() < (meilleure.totalKm - distanceKm).abs()) {
          meilleure = trace;
        }
        final ratio = trace.totalKm / distanceKm;
        if ((ratio - 1).abs() < 0.08) break;
        facteur = facteur * ratio;
      }

      final trace = meilleure!;
      final n = trace.points.length;
      if (n < 2) return null;

      final altLisse = _lisser(trace.altitudes, 5);

      // Villes traversées : on échantillonne 6 points le long du tracé.
      final indices = <int>[];
      for (int k = 1; k <= 6; k++) {
        final cible = trace.totalKm * k / 7;
        final idx = trace.distancesKm.indexWhere((d) => d >= cible);
        if (idx > 0 && idx < n - 1) indices.add(idx);
      }
      final noms = await Future.wait(
        indices.map((i) => VillesService.nomCommune(trace.points[i])),
      );

      final etapes = <EtapeVille>[];
      final idxEtapes = <int>[];
      String precedent = nomDepart;
      for (int j = 0; j < indices.length; j++) {
        final nom = noms[j];
        if (nom == null || nom == nomDepart || nom == precedent) continue;
        etapes.add(EtapeVille(
          nom: nom,
          position: trace.points[indices[j]],
          distanceKm: trace.distancesKm[indices[j]],
        ));
        idxEtapes.add(indices[j]);
        precedent = nom;
      }

      // Tronçons entre chaque ville
      final bornes = <int>[0, ...idxEtapes, n - 1];
      final nomsBornes = <String>[nomDepart, ...etapes.map((e) => e.nom), nomDepart];
      final troncons = <TronconParcours>[];
      int totalPos = 0;
      int totalNeg = 0;
      for (int t = 0; t < bornes.length - 1; t++) {
        final dn = _denivele(altLisse, bornes[t], bornes[t + 1]);
        totalPos += dn[0];
        totalNeg += dn[1];
        troncons.add(TronconParcours(
          depart: nomsBornes[t],
          arrivee: nomsBornes[t + 1],
          distanceKm: trace.distancesKm[bornes[t + 1]] - trace.distancesKm[bornes[t]],
          denivelePos: dn[0],
          deniveleNeg: dn[1],
        ));
      }

      final km = trace.totalKm;

      // Titre : Lyon – Caluire – Neuville – Lyon
      final nomsEtapes = etapes.map((e) => e.nom).toList();
      final choisis = nomsEtapes.length <= 3
          ? nomsEtapes
          : [nomsEtapes.first, nomsEtapes[nomsEtapes.length ~/ 2], nomsEtapes.last];
      final titre = choisis.isEmpty
          ? 'Boucle de $nomDepart'
          : [nomDepart, ...choisis, nomDepart].join(' – ');

      final vitesse = profil == 'route' ? 22.0 : (profil == 'vtt' ? 13.0 : 16.0);
      final heures = km / vitesse + totalPos / 600.0;
      final h = heures.floor();
      final m = ((heures - h) * 60).round();
      final duree = '${h}h${m.toString().padLeft(2, '0')}';

      final ratioDenivele = km > 0 ? totalPos / km : 0;
      final difficulte = ratioDenivele < 8 ? 'Facile' : (ratioDenivele < 16 ? 'Modéré' : 'Sportif');

      final resultat = Parcours(
        titre: titre,
        distance: '${km.toStringAsFixed(1)} km',
        duree: duree,
        difficulte: difficulte,
        ville: nomDepart,
        denivele: '$totalPos m D+',
        traceGPS: trace.points,
        altitudes: altLisse,
        distancesKm: trace.distancesKm,
        distanceKm: km,
        denivelePos: totalPos,
        deniveleNeg: totalNeg,
        etapes: etapes,
        troncons: troncons,
      );
      _partChemins[resultat] = trace.partChemins;
      return resultat;
    } catch (e) {
      _derniereErreur = e.toString();
      return null;
    }
  }

  /// Itinéraire à vélo pour rejoindre un point (ex. le tracé du parcours). Null si échec.
  static Future<List<LatLng>?> itineraireVers(LatLng depuis, LatLng vers) async {
    try {
      final t = await _calculerTrace([depuis, vers], ['trekking']);
      return t.points.length >= 2 ? t.points : null;
    } catch (_) {
      return null;
    }
  }

  /// Départ + 4 points répartis sur un cercle passant par le départ + retour au départ.
  static List<LatLng> _pointsDeBoucle(LatLng depart, double distanceKm, double cap, double facteur) {
    final diametre = distanceKm * 1000 / (math.pi * facteur);
    final centre = _calc.offset(depart, diametre / 2, cap);
    final capDepuisCentre = (cap + 180) % 360;
    final pts = <LatLng>[depart];
    for (int k = 1; k <= 4; k++) {
      pts.add(_calc.offset(centre, diametre / 2, (capDepuisCentre + 72.0 * k) % 360));
    }
    pts.add(depart);
    return pts;
  }

  static List<String> _profilsBrouter(String profil) {
    switch (profil) {
      case 'route':
        // Sportif : routes rapides, bon revêtement, pas de chemins
        return ['fastbike', 'trekking'];
      case 'vtt':
        // VTT : profil personnalisé qui favorise pistes et sentiers (envoyé à BRouter)
        return ['custom:vtt', 'trekking'];
      default:
        // Balade en famille : routes calmes, pistes cyclables, on évite la circulation
        return ['safety', 'trekking'];
    }
  }

  static Future<_Trace> _calculerTrace(List<LatLng> pts, List<String> profils) async {
    Object? derniere;
    for (final nom in profils) {
      String p = nom;
      try {
        if (nom == 'custom:vtt') {
          final id = await _profilVtt();
          if (id == null) {
            note = 'Le profil VTT n\'a pas pu être chargé : parcours calculés sur routes tranquilles.';
            continue;
          }
          p = id;
        }
        final lonlats = pts
            .map((q) => '${q.longitude.toStringAsFixed(6)},${q.latitude.toStringAsFixed(6)}')
            .join('|');
        final uri = Uri.https('brouter.de', '/brouter', {
          'lonlats': lonlats,
          'profile': p,
          'alternativeidx': '0',
          'format': 'geojson',
        });
        final r = await http
            .get(uri, headers: {'User-Agent': 'AppVeloMobile/1.0'})
            .timeout(const Duration(seconds: 40));
        if (r.statusCode != 200) {
          final corps = r.body.length > 120 ? r.body.substring(0, 120) : r.body;
          throw 'BRouter (${r.statusCode}) : $corps';
        }
        return _lireGeoJson(r.body);
      } catch (e) {
        derniere = e;
        if (nom == 'custom:vtt') {
          _idProfilVtt = null; // le serveur l'a peut-être oublié : on le renverra
          note = 'Le profil VTT n\'a pas pu être appliqué : parcours calculés sur routes tranquilles.';
        }
      }
    }
    throw derniere ?? 'Erreur de routage';
  }

  /// Envoie notre profil VTT au serveur BRouter et garde son identifiant.
  static Future<String?>? _envoiEnCours;

  static Future<String?> _profilVtt() async {
    if (_idProfilVtt != null) return _idProfilVtt;
    // Les 5 boucles sont calculées en parallèle : un seul envoi pour toutes.
    final f = _envoiEnCours ??= _envoyerProfilVtt();
    try {
      return await f;
    } finally {
      _envoiEnCours = null;
    }
  }

  static Future<String?> _envoyerProfilVtt() async {
    try {
      final r = await http
          .post(
            Uri.https('brouter.de', '/brouter/profile'),
            headers: {'User-Agent': 'AppVeloMobile/1.0', 'Content-Type': 'text/plain'},
            body: _texteProfilVtt,
          )
          .timeout(const Duration(seconds: 20));
      if (r.statusCode != 200) return null;
      final data = json.decode(r.body);
      final id = data is Map ? data['profileid'] : null;
      if (id is String && id.isNotEmpty) {
        _idProfilVtt = id;
        return id;
      }
    } catch (_) {}
    return null;
  }

  // Profil BRouter « VTT » : pistes et sentiers au meilleur prix, routes à circulation très pénalisées.
  static const String _texteProfilVtt = '''
---context:global

assign validForBikes = 1
assign downhillcost = 0
assign downhillcutoff = 1.5
assign uphillcost = 0
assign uphillcutoff = 1.5

---context:way

assign turncost = 60
assign initialclassifier = 0

assign costfactor =
  switch or access=private|no bicycle=no|private|dismount|use_sidepath 10000
  switch highway=motorway|motorway_link|trunk|trunk_link 10000
  switch highway=primary|primary_link 6
  switch highway=secondary|secondary_link 4
  switch highway=tertiary|tertiary_link 2.5
  switch and highway=track|path|bridleway surface=asphalt|paved|concrete|paving_stones 2
  switch highway=track|bridleway 1
  switch highway=path 1.1
  switch highway=cycleway 1.6
  switch highway=residential|unclassified|living_street|service 2
  switch highway=footway|pedestrian 4
  switch highway=steps 20
  3

---context:node

assign initialcost = 0
''';

  /// Part (0..1) du trajet sur chemins non revêtus, d'après les étiquettes OSM renvoyées par BRouter.
  static double _calculerPartChemins(dynamic messages) {
    try {
      if (messages is! List || messages.length < 2) return 0;
      final entete = (messages.first as List).map((e) => e.toString()).toList();
      final iDist = entete.indexOf('Distance');
      final iTags = entete.indexOf('WayTags');
      if (iDist < 0 || iTags < 0) return 0;
      double total = 0;
      double chemins = 0;
      for (int i = 1; i < messages.length; i++) {
        final l = messages[i] as List;
        final d = double.tryParse(l[iDist].toString()) ?? 0;
        final t = l[iTags].toString();
        final revetu = RegExp(r'surface=(asphalt|paved|concrete|paving_stones)').hasMatch(t);
        final piste = RegExp(r'highway=(track|path|bridleway)').hasMatch(t) ||
            RegExp(r'surface=(unpaved|gravel|fine_gravel|dirt|ground|compacted|grass|earth|mud|sand|pebblestone)').hasMatch(t);
        total += d;
        if (piste && !revetu) chemins += d;
      }
      return total > 0 ? chemins / total : 0;
    } catch (_) {
      return 0;
    }
  }

  static _Trace _lireGeoJson(String corps) {
    final data = json.decode(corps) as Map<String, dynamic>;
    final features = data['features'] as List;
    if (features.isEmpty) throw 'Réponse BRouter vide';
    final coords = features.first['geometry']['coordinates'] as List;

    final points = <LatLng>[];
    final alt = <double>[];
    for (final c in coords) {
      final l = c as List;
      points.add(LatLng((l[1] as num).toDouble(), (l[0] as num).toDouble()));
      alt.add(l.length > 2 ? (l[2] as num).toDouble() : 0.0);
    }

    final cum = <double>[0.0];
    for (int i = 1; i < points.length; i++) {
      cum.add(cum.last + _calc.as(LengthUnit.Meter, points[i - 1], points[i]) / 1000);
    }
    final props = features.first['properties'];
    final part = _calculerPartChemins(props is Map ? props['messages'] : null);
    return _Trace(points, alt, cum, part);
  }

  /// Moyenne mobile pour enlever le bruit de l'altitude.
  static List<double> _lisser(List<double> v, int fenetre) {
    final moitie = fenetre ~/ 2;
    final res = <double>[];
    for (int i = 0; i < v.length; i++) {
      final debut = math.max(0, i - moitie);
      final fin = math.min(v.length - 1, i + moitie);
      double somme = 0;
      for (int j = debut; j <= fin; j++) {
        somme += v[j];
      }
      res.add(somme / (fin - debut + 1));
    }
    return res;
  }

  /// Retourne [D+, D-] entre deux indices (variations < 3 m ignorées).
  static List<int> _denivele(List<double> alt, int debut, int fin) {
    double ref = alt[debut];
    double pos = 0;
    double neg = 0;
    for (int i = debut + 1; i <= fin; i++) {
      final diff = alt[i] - ref;
      if (diff >= 3) {
        pos += diff;
        ref = alt[i];
      } else if (diff <= -3) {
        neg += -diff;
        ref = alt[i];
      }
    }
    return [pos.round(), neg.round()];
  }
}
