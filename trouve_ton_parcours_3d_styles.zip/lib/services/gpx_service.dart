import 'dart:convert';
import 'dart:math' as math;
import 'package:latlong2/latlong.dart';
import 'package:xml/xml.dart';
import '../models/parcours.dart';
import 'villes_service.dart';

/// Lit un fichier GPX et en fait un parcours utilisable par l'appli (carte, GPS, feuille de route, favoris).
class GpxService {
  static final Distance _calc = Distance(roundResult: false);

  /// Nombre maximum de points gardés (le parcours est sauvegardé dans les favoris).
  static const int _pointsMax = 3000;

  /// Lève une String lisible si le fichier n'est pas un GPX exploitable.
  static Future<Parcours> lire(List<int> octets, {String? nomFichier}) async {
    final XmlDocument doc;
    try {
      doc = XmlDocument.parse(utf8.decode(octets, allowMalformed: true));
    } catch (_) {
      throw "Ce fichier n'est pas un GPX valide.";
    }

    // Trace (trk), sinon itinéraire (rte).
    var elements = doc.findAllElements('trkpt').toList();
    if (elements.length < 2) elements = doc.findAllElements('rtept').toList();

    final brut = <LatLng>[];
    final altBrut = <double?>[];
    for (final e in elements) {
      final lat = double.tryParse(e.getAttribute('lat') ?? '');
      final lon = double.tryParse(e.getAttribute('lon') ?? '');
      if (lat == null || lon == null || lat.abs() > 90 || lon.abs() > 180) continue;
      brut.add(LatLng(lat, lon));
      altBrut.add(double.tryParse(e.getElement('ele')?.innerText.trim() ?? ''));
    }
    if (brut.length < 2) throw "Aucun tracé trouvé dans ce fichier (il faut une trace ou un itinéraire).";

    // Points trop rapprochés (< 3 m) retirés, puis plafond du nombre de points.
    var points = <LatLng>[brut.first];
    var alts = <double?>[altBrut.first];
    for (int i = 1; i < brut.length; i++) {
      if (_calc.as(LengthUnit.Meter, points.last, brut[i]) >= 3 || i == brut.length - 1) {
        points.add(brut[i]);
        alts.add(altBrut[i]);
      }
    }
    if (points.length > _pointsMax) {
      final pas = points.length / _pointsMax;
      final p2 = <LatLng>[];
      final a2 = <double?>[];
      for (int k = 0; k < _pointsMax; k++) {
        final idx = math.min(points.length - 1, (k * pas).floor());
        p2.add(points[idx]);
        a2.add(alts[idx]);
      }
      p2[p2.length - 1] = points.last;
      a2[a2.length - 1] = alts.last;
      points = p2;
      alts = a2;
    }
    if (points.length < 2) throw 'Le tracé est trop court.';

    // Altitudes : on comble les trous avec la dernière valeur connue.
    final altitudes = <double>[];
    double derniere = alts.firstWhere((a) => a != null, orElse: () => 0.0) ?? 0.0;
    for (final a in alts) {
      if (a != null) derniere = a;
      altitudes.add(derniere);
    }
    final altLisse = _lisser(altitudes, 5);

    final cumKm = <double>[0.0];
    for (int i = 1; i < points.length; i++) {
      cumKm.add(cumKm.last + _calc.as(LengthUnit.Meter, points[i - 1], points[i]) / 1000);
    }
    final km = cumKm.last;
    if (km < 0.1) throw 'Le tracé est trop court.';

    // Nom du parcours
    String titre = '';
    final trk = doc.findAllElements('trk').firstOrNull ?? doc.findAllElements('rte').firstOrNull;
    titre = trk?.getElement('name')?.innerText.trim() ?? '';
    if (titre.isEmpty) {
      titre = doc.findAllElements('metadata').firstOrNull?.getElement('name')?.innerText.trim() ?? '';
    }
    if (titre.isEmpty && nomFichier != null) {
      titre = nomFichier.replaceAll(RegExp(r'\.gpx$', caseSensitive: false), '').replaceAll('_', ' ').trim();
    }
    if (titre.isEmpty) titre = 'Parcours importé';

    // Villes traversées (comme pour les parcours générés) : 6 points le long du tracé.
    final n = points.length;
    final indices = <int>[];
    for (int k = 1; k <= 6; k++) {
      final cible = km * k / 7;
      final idx = cumKm.indexWhere((d) => d >= cible);
      if (idx > 0 && idx < n - 1) indices.add(idx);
    }
    final noms = await Future.wait([
      VillesService.nomCommune(points.first),
      VillesService.nomCommune(points.last),
      ...indices.map((i) => VillesService.nomCommune(points[i])),
    ]);
    final nomDepart = noms[0] ?? 'Départ';
    final nomArrivee = noms[1] ?? 'Arrivée';
    final etapes = <EtapeVille>[];
    final idxEtapes = <int>[];
    String precedent = nomDepart;
    for (int j = 0; j < indices.length; j++) {
      final nom = noms[j + 2];
      if (nom == null || nom == precedent || nom == nomArrivee && j == indices.length - 1) continue;
      etapes.add(EtapeVille(nom: nom, position: points[indices[j]], distanceKm: cumKm[indices[j]]));
      idxEtapes.add(indices[j]);
      precedent = nom;
    }

    // Tronçons entre chaque ville
    final bornes = <int>[0, ...idxEtapes, n - 1];
    final nomsBornes = <String>[nomDepart, ...etapes.map((e) => e.nom), nomArrivee];
    final troncons = <TronconParcours>[];
    int totalPos = 0;
    int totalNeg = 0;
    for (int t = 0; t < bornes.length - 1; t++) {
      final dn = _denivele(altLisse, bornes[t], bornes[t + 1]);
      totalPos += dn[0];
      totalNeg += dn[1];
      troncons.add(TronconParcours(
        depart: nomsBornes[t],
        arrivee: nomsBornes[t + 1],
        distanceKm: cumKm[bornes[t + 1]] - cumKm[bornes[t]],
        denivelePos: dn[0],
        deniveleNeg: dn[1],
      ));
    }

    final heures = km / 16.0 + totalPos / 600.0;
    final h = heures.floor();
    final m = ((heures - h) * 60).round();
    final ratio = totalPos / km;

    return Parcours(
      titre: titre,
      distance: '${km.toStringAsFixed(1)} km',
      duree: '${h}h${m.toString().padLeft(2, '0')}',
      difficulte: ratio < 8 ? 'Facile' : (ratio < 16 ? 'Modéré' : 'Sportif'),
      ville: nomDepart,
      denivele: '$totalPos m D+',
      traceGPS: points,
      altitudes: altLisse,
      distancesKm: cumKm,
      distanceKm: km,
      denivelePos: totalPos,
      deniveleNeg: totalNeg,
      etapes: etapes,
      troncons: troncons,
    );
  }

  static List<double> _lisser(List<double> v, int fenetre) {
    final moitie = fenetre ~/ 2;
    final res = <double>[];
    for (int i = 0; i < v.length; i++) {
      final debut = math.max(0, i - moitie);
      final fin = math.min(v.length - 1, i + moitie);
      double somme = 0;
      for (int j = debut; j <= fin; j++) {
        somme += v[j];
      }
      res.add(somme / (fin - debut + 1));
    }
    return res;
  }

  /// [D+, D-] entre deux indices (variations < 3 m ignorées).
  static List<int> _denivele(List<double> alt, int debut, int fin) {
    double ref = alt[debut];
    double pos = 0;
    double neg = 0;
    for (int i = debut + 1; i <= fin; i++) {
      final diff = alt[i] - ref;
      if (diff >= 3) {
        pos += diff;
        ref = alt[i];
      } else if (diff <= -3) {
        neg += -diff;
        ref = alt[i];
      }
    }
    return [pos.round(), neg.round()];
  }
}
