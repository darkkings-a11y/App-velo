import 'dart:async';
import 'package:flutter/material.dart';
import 'accueil_screen.dart';

/// Première page : affichée quelques secondes au lancement, avant l'accueil.
class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  // Durée d'affichage (en secondes) : change cette valeur si tu la veux plus longue ou plus courte.
  static const int _dureeSecondes = 3;

  // Même couleur que les bords de l'image, pour qu'on ne voie pas de bordure.
  static const Color _fond = Color(0xFF0C1719);

  Timer? _minuteur;
  bool _visible = false;

  @override
  void initState() {
    super.initState();
    // Fondu d'apparition
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) setState(() => _visible = true);
    });
    _minuteur = Timer(const Duration(seconds: _dureeSecondes), _ouvrirAccueil);
  }

  void _ouvrirAccueil() {
    if (!mounted) return;
    Navigator.of(context).pushReplacement(
      PageRouteBuilder(
        transitionDuration: const Duration(milliseconds: 500),
        pageBuilder: (_, __, ___) => const AccueilScreen(),
        transitionsBuilder: (_, animation, __, child) =>
            FadeTransition(opacity: animation, child: child),
      ),
    );
  }

  @override
  void dispose() {
    _minuteur?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _fond,
      body: GestureDetector(
        // Un appui permet de passer directement à l'accueil.
        behavior: HitTestBehavior.opaque,
        onTap: () {
          _minuteur?.cancel();
          _ouvrirAccueil();
        },
        child: SizedBox.expand(
          child: AnimatedOpacity(
            opacity: _visible ? 1 : 0,
            duration: const Duration(milliseconds: 700),
            child: Image.asset('assets/splash.jpg', fit: BoxFit.contain),
          ),
        ),
      ),
    );
  }
}
