import 'package:flutter/material.dart';

/// Courbe d'altitude du parcours (profil vert comme sur la maquette).
class ProfilAltitude extends StatelessWidget {
  final List<double> distancesKm;
  final List<double> altitudes;
  final List<double> repereKm; // positions des villes (traits verticaux)

  const ProfilAltitude({
    super.key,
    required this.distancesKm,
    required this.altitudes,
    this.repereKm = const [],
  });

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      painter: _ProfilPainter(distancesKm, altitudes, repereKm),
      size: Size.infinite,
    );
  }
}

class _ProfilPainter extends CustomPainter {
  final List<double> dist;
  final List<double> alt;
  final List<double> reperes;

  _ProfilPainter(this.dist, this.alt, this.reperes);

  static const Color _vert = Color(0xFF00E676);

  void _texte(Canvas canvas, String s, Offset pos, {bool droite = false}) {
    final tp = TextPainter(
      text: TextSpan(
        text: s,
        style: const TextStyle(color: Color(0xFF9E9E9E), fontSize: 10),
      ),
      textDirection: TextDirection.ltr,
    )..layout();
    canvas.drawText(tp, droite ? Offset(pos.dx - tp.width, pos.dy) : pos);
  }

  @override
  void paint(Canvas canvas, Size size) {
    if (alt.length < 2 || dist.length != alt.length) return;

    const gauche = 40.0;
    const bas = 16.0;
    const haut = 6.0;
    final w = size.width - gauche;
    final h = size.height - bas - haut;

    double minA = alt.reduce((a, b) => a < b ? a : b);
    double maxA = alt.reduce((a, b) => a > b ? a : b);
    if (maxA - minA < 20) {
      final m = (maxA + minA) / 2;
      minA = m - 10;
      maxA = m + 10;
    }
    final total = dist.last <= 0 ? 1.0 : dist.last;

    Offset pt(int i) => Offset(
          gauche + dist[i] / total * w,
          haut + h - (alt[i] - minA) / (maxA - minA) * h,
        );

    // Grille horizontale
    final grille = Paint()
      ..color = const Color(0x22FFFFFF)
      ..strokeWidth = 1;
    for (int k = 0; k <= 2; k++) {
      final y = haut + h * k / 2;
      canvas.drawLine(Offset(gauche, y), Offset(size.width, y), grille);
      final valeur = maxA - (maxA - minA) * k / 2;
      _texte(canvas, '${valeur.round()} m', Offset(gauche - 4, y - 6), droite: true);
    }

    // Traits verticaux aux villes
    final repere = Paint()
      ..color = const Color(0x44FFFFFF)
      ..strokeWidth = 1;
    for (final km in reperes) {
      final x = gauche + km / total * w;
      canvas.drawLine(Offset(x, haut), Offset(x, haut + h), repere);
    }

    // Aire sous la courbe
    final ligne = Path()..moveTo(pt(0).dx, pt(0).dy);
    for (int i = 1; i < alt.length; i++) {
      final p = pt(i);
      ligne.lineTo(p.dx, p.dy);
    }
    final aire = Path.from(ligne)
      ..lineTo(pt(alt.length - 1).dx, haut + h)
      ..lineTo(gauche, haut + h)
      ..close();
    final degrade = const LinearGradient(
      begin: Alignment.topCenter,
      end: Alignment.bottomCenter,
      colors: [Color(0x8800E676), Color(0x0500E676)],
    ).createShader(Rect.fromLTWH(gauche, haut, w, h));
    canvas.drawPath(aire, Paint()..shader = degrade);

    // Courbe
    canvas.drawPath(
      ligne,
      Paint()
        ..color = _vert
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2
        ..strokeJoin = StrokeJoin.round,
    );

    // Axe des distances
    _texte(canvas, '0 km', Offset(gauche, size.height - 12));
    _texte(canvas, '${total.toStringAsFixed(0)} km', Offset(size.width, size.height - 12), droite: true);
  }

  @override
  bool shouldRepaint(covariant _ProfilPainter old) =>
      old.alt != alt || old.dist != dist || old.reperes != reperes;
}

extension on Canvas {
  void drawText(TextPainter tp, Offset o) => tp.paint(this, o);
}
