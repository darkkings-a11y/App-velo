# Carte 3D (MapLibre) – à faire après `flutter pub get`

Ce qui a changé : `flutter_map` est remplacé par `maplibre_gl` (carte vectorielle inclinable).
Seuls `pubspec.yaml` et `lib/screens/carte_screen.dart` ont été modifiés.

## Android (`android/`)
- `android/settings.gradle` : Kotlin >= 2.1.0
  `id "org.jetbrains.kotlin.android" version "2.1.0" apply false`
- `android/app/build.gradle` : `minSdk` >= 21
- `AndroidManifest.xml` : permissions INTERNET, ACCESS_FINE_LOCATION, ACCESS_COARSE_LOCATION

## iOS (`ios/Runner/Info.plist`)
- `NSLocationWhenInUseUsageDescription` avec une phrase d'explication

## Réglages de l'effet TomTom (en haut de `carte_screen.dart`)
- `_inclinaisonGuidage` : 0 (vue du dessus) à 60 (vue de derrière)
- `_zoomGuidage`, `_zoomSuivi`
- `_styleUrl` : style de la carte (OpenFreeMap « liberty », sans clé API)

## Si les noms de villes n'apparaissent pas sur la carte
La police `Noto Sans Bold` (dans `fontNames`) doit exister dans le style choisi.

## Vue GPS façon TomTom (réglages en haut de `carte_screen.dart`)
- `_decalageAvantM` : plus la valeur est grande, plus ta position descend dans l'écran (90 par défaut)
- `_zoomGuidage` : 17.5 par défaut ; `_inclinaisonGuidage` : 60 (maximum)
- Bandeau en haut : icône du virage + distance + consigne (calculés depuis le tracé)
- Pastille : rouge « Vous n'êtes pas sur le parcours » / verte « Vous êtes sur le parcours »
- Hors parcours : itinéraire bleu (BRouter) pour rejoindre le tracé, avec ses propres virages

## Page de démarrage (splash)
- Image : `assets/splash.jpg` (remplace le fichier pour changer l'image)
- Durée : `_dureeSecondes` dans `lib/screens/splash_screen.dart` (3 s par défaut)

## Styles de parcours (dans `lib/services/routage_service.dart`)
Chaque style a son propre profil BRouter, envoyé au serveur au premier calcul (`_texteProfilRoute`, `_texteProfilBalade`, `_texteProfilVtt`).
Si un profil est refusé, l'appli retombe sur un profil standard (fastbike / safety / mtb, puis trekking) et l'indique par un message.

- **Route** : routes goudronnées (départementales, secondaires, tertiaires). Primaires évitées, chemins, sentiers et pavés très pénalisés.
- **Balade** : pistes cyclables, voies vertes, chemins de parc, bords de l'eau et zones vertes favorisés. Routes à circulation très pénalisées, côtes évitées.
- **VTT** : chemins, pistes et sentiers, de préférence en forêt. Bitume quasi interdit, villes évitées, sentiers trop techniques évités.

Après calcul, chaque boucle est analysée (part de chemins, de pistes cyclables, de routes à circulation…) :
les boucles conformes au style passent en premier (`_conforme`, `_score`). Les seuils sont réglables dans ces deux fonctions.

### VTT : « au plus près »
Si la zone demandée n'a pas assez de chemins (ex. Lyon centre), l'appli interroge OpenStreetMap (Overpass) pour trouver
les chemins les plus proches (rayon 4, 10, 20, 35 puis 55 km) et fait partir les boucles de là.
Un message indique alors d'où partent les parcours et à quelle distance. Si Overpass ne répond pas, le départ reste le point demandé.
Réglages : `_zonesVtt` (rayons), `_regrouperZones` (`voisins.length < 40` = densité de chemins minimale).
