import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;
import 'package:http/http.dart' as http;
import 'package:latlong2/latlong.dart';
import '../models/parcours.dart';
import 'gpx_service.dart';

/// Itinéraires vélo / VTT balisés qui existent réellement (relations OpenStreetMap), autour d'une ville.
/// Données libres (ODbL), récupérées via l'API Overpass. OpenStreetMap ne contient AUCUNE donnée de popularité :
/// le classement se fait par importance du réseau (international > national > régional > local), puis par longueur.
class ItinerairesOsmService {
  static final Distance _calc = Distance(roundResult: false);

  static const List<String> _serveurs = [
    'https://overpass-api.de/api/interpreter',
    'https://overpass.private.coffee/api/interpreter',
    'https://overpass.kumi.systems/api/interpreter',
    'https://overpass.openstreetmap.fr/api/interpreter',
    'https://maps.mail.ru/osm/tools/overpass/api/interpreter',
  ];

  /// Message à montrer si les itinéraires n'ont pas pu être chargés.
  static String? note;

  static Future<List<Parcours>> pourVille({
    required LatLng centre,
    required String profil,
    required int distanceKm,
    required String villeNom,
    int max = 10,
  }) async {
    note = null;
    try {
      // Zone de recherche : un carré autour de la ville, de la taille de la sortie demandée.
      // Zone de recherche : un carré autour de la ville (plafonné pour ne pas surcharger Overpass).
      final demiKm = math.min(25.0, math.max(12.0, distanceKm * 0.4));
      final dLat = demiKm / 110.54;
      final dLon = demiKm / (111.32 * math.max(0.2, math.cos(centre.latitude * math.pi / 180)));
      final bbox = '${(centre.latitude - dLat).toStringAsFixed(5)},${(centre.longitude - dLon).toStringAsFixed(5)},'
          '${(centre.latitude + dLat).toStringAsFixed(5)},${(centre.longitude + dLon).toStringAsFixed(5)}';
      final type = profil == 'vtt' ? 'mtb' : 'bicycle';

      // Étape 1 : requête légère (sans géométrie) pour lister les itinéraires de la zone.
      final liste = await _overpass('[out:json][timeout:25];relation["route"="$type"]($bbox);out tags;');
      if (liste == null) {
        note = "Itinéraires balisés indisponibles : OpenStreetMap n'a pas répondu.";
        return [];
      }
      final ids = <int, int>{}; // id -> niveau
      final vus = <String>{};
      final tous = <Map<String, dynamic>>[];
      for (final e in (liste['elements'] as List? ?? const [])) {
        if (e is Map<String, dynamic> && e['id'] is int) tous.add(e);
      }
      tous.sort((a, b) {
        final na = _niveau(((a['tags'] as Map?)?['network']) as String?);
        final nb = _niveau(((b['tags'] as Map?)?['network']) as String?);
        return nb.compareTo(na);
      });
      for (final e in tous) {
        final tags = (e['tags'] as Map?)?.cast<String, dynamic>() ?? const {};
        final nom = ((tags['name'] ?? tags['ref']) as String?)?.trim().toLowerCase();
        if (nom == null || nom.isEmpty || !vus.add(nom)) continue;
        ids[e['id'] as int] = _niveau(tags['network'] as String?);
        if (ids.length >= max + 6) break;
      }
      if (ids.isEmpty) return [];

      // Étape 2 : géométrie des seules relations retenues.
      final data = await _overpass('[out:json][timeout:60];relation(id:${ids.keys.join(',')});out geom($bbox);');
      if (data == null) {
        note = "Itinéraires balisés indisponibles : OpenStreetMap n'a pas répondu.";
        return [];
      }

      // Un tracé par relation (on recolle les tronçons bout à bout).
      final candidats = <_Candidat>[];
      for (final e in (data['elements'] as List? ?? const [])) {
        if (e is! Map<String, dynamic>) continue;
        final tags = (e['tags'] as Map?)?.cast<String, dynamic>() ?? const {};
        final nom = (tags['name'] as String?)?.trim().isNotEmpty == true
            ? (tags['name'] as String).trim()
            : (tags['ref'] as String?)?.trim();
        if (nom == null || nom.isEmpty) continue;
        final trace = _recoller(_segments(e['members']));
        if (trace.length < 2) continue;
        final km = _longueurKm(trace);
        if (km < 3) continue;
        final reseau = _niveau(tags['network'] as String?);
        candidats.add(_Candidat(nom, trace, km, reseau));
      }
      if (candidats.isEmpty) return [];

      // Un seul tracé par nom (le plus long), classés par importance du réseau puis longueur.
      final parNom = <String, _Candidat>{};
      for (final c in candidats) {
        final deja = parNom[c.nom.toLowerCase()];
        if (deja == null || c.km > deja.km) parNom[c.nom.toLowerCase()] = c;
      }
      final tries = parNom.values.toList()
        ..sort((a, b) {
          final n = b.niveau.compareTo(a.niveau);
          return n != 0 ? n : b.km.compareTo(a.km);
        });
      final retenus = tries.take(max).toList();

      // Altitudes (OpenStreetMap n'en a pas) puis parcours complets.
      final parcours = await Future.wait(retenus.map((c) async {
        try {
          final alts = await _altitudes(c.trace);
          return await GpxService.depuisPoints(
            c.trace,
            alts,
            nom: c.nom,
            source: Parcours.sourceOpenData,
            verifie: false,
            detailSource: _libelle(c.niveau),
            avecVilles: false,
            villeParDefaut: villeNom,
          );
        } catch (_) {
          return null;
        }
      }));
      return parcours.whereType<Parcours>().toList();
    } catch (_) {
      note = "Itinéraires balisés indisponibles pour le moment.";
      return [];
    }
  }

  // ---------------------------------------------------------------------------

  static int _niveau(String? network) {
    switch (network) {
      case 'icn':
        return 4;
      case 'ncn':
        return 3;
      case 'rcn':
        return 2;
      case 'lcn':
        return 1;
      default:
        return 0;
    }
  }

  static String _libelle(int niveau) {
    switch (niveau) {
      case 4:
        return 'itinéraire international';
      case 3:
        return 'itinéraire national';
      case 2:
        return 'itinéraire régional';
      case 1:
        return 'itinéraire local';
      default:
        return 'itinéraire balisé';
    }
  }

  /// Tronçons (suites de points) des voies d'une relation, limités à la zone demandée.
  static List<List<LatLng>> _segments(dynamic members) {
    final res = <List<LatLng>>[];
    if (members is! List) return res;
    for (final m in members) {
      if (m is! Map || m['type'] != 'way') continue;
      final geom = m['geometry'];
      if (geom is! List) continue;
      var courant = <LatLng>[];
      for (final g in geom) {
        if (g is Map && g['lat'] is num && g['lon'] is num) {
          courant.add(LatLng((g['lat'] as num).toDouble(), (g['lon'] as num).toDouble()));
        } else {
          if (courant.length >= 2) res.add(courant);
          courant = <LatLng>[];
        }
      }
      if (courant.length >= 2) res.add(courant);
    }
    return res;
  }

  /// Recolle les tronçons bout à bout ; garde la plus longue chaîne continue.
  static List<LatLng> _recoller(List<List<LatLng>> segments) {
    const tolM = 25.0;
    final restants = [...segments];
    List<LatLng> meilleure = [];
    double meilleureKm = 0;
    while (restants.isNotEmpty) {
      restants.sort((a, b) => _longueurKm(b).compareTo(_longueurKm(a)));
      var cur = [...restants.removeAt(0)];
      bool avance = true;
      while (avance) {
        avance = false;
        for (int i = 0; i < restants.length; i++) {
          final s = restants[i];
          if (_calc.as(LengthUnit.Meter, cur.last, s.first) < tolM) {
            cur = [...cur, ...s];
          } else if (_calc.as(LengthUnit.Meter, cur.last, s.last) < tolM) {
            cur = [...cur, ...s.reversed];
          } else if (_calc.as(LengthUnit.Meter, cur.first, s.last) < tolM) {
            cur = [...s, ...cur];
          } else if (_calc.as(LengthUnit.Meter, cur.first, s.first) < tolM) {
            cur = [...s.reversed, ...cur];
          } else {
            continue;
          }
          restants.removeAt(i);
          avance = true;
          break;
        }
      }
      final km = _longueurKm(cur);
      if (km > meilleureKm) {
        meilleureKm = km;
        meilleure = cur;
      }
    }
    return meilleure;
  }

  static double _longueurKm(List<LatLng> pts) {
    double m = 0;
    for (int i = 1; i < pts.length; i++) {
      m += _calc.as(LengthUnit.Meter, pts[i - 1], pts[i]);
    }
    return m / 1000;
  }

  /// Altitude de ~100 points répartis le long du tracé (Open-Meteo), interpolée sur tous les points.
  /// Liste de null si le service ne répond pas.
  static Future<List<double?>> _altitudes(List<LatLng> pts) async {
    final vide = List<double?>.filled(pts.length, null);
    try {
      final n = math.min(100, pts.length);
      final idx = [for (int k = 0; k < n; k++) (k * (pts.length - 1) / (n - 1)).round()];
      final uri = Uri.https('api.open-meteo.com', '/v1/elevation', {
        'latitude': idx.map((i) => pts[i].latitude.toStringAsFixed(5)).join(','),
        'longitude': idx.map((i) => pts[i].longitude.toStringAsFixed(5)).join(','),
      });
      final r = await http.get(uri).timeout(const Duration(seconds: 10));
      if (r.statusCode != 200) return vide;
      final el = (json.decode(r.body)['elevation'] as List).map((e) => (e as num).toDouble()).toList();
      if (el.length != n) return vide;
      final res = List<double?>.filled(pts.length, null);
      for (int k = 0; k < n - 1; k++) {
        final a = idx[k], b = idx[k + 1];
        for (int i = a; i <= b; i++) {
          final t = b > a ? (i - a) / (b - a) : 0.0;
          res[i] = el[k] + (el[k + 1] - el[k]) * t;
        }
      }
      return res;
    } catch (_) {
      return vide;
    }
  }

  /// Requête Overpass : les serveurs sont interrogés en décalé, le premier qui répond correctement gagne.
  static Future<Map<String, dynamic>?> _overpass(String requete) {
    final fini = Completer<Map<String, dynamic>?>();
    int echecs = 0;

    void echec() {
      echecs++;
      if (echecs >= _serveurs.length && !fini.isCompleted) fini.complete(null);
    }

    void tenter(String serveur) {
      http
          .post(
            Uri.parse(serveur),
            headers: {
              'User-Agent': 'TrouveTonParcours/1.0 (application Android de parcours velo)',
              'Accept': 'application/json',
              'Content-Type': 'application/x-www-form-urlencoded; charset=utf-8',
            },
            body: {'data': requete},
          )
          .timeout(const Duration(seconds: 45))
          .then((r) {
        if (fini.isCompleted) return;
        if (r.statusCode != 200) {
          echec();
          return;
        }
        try {
          final j = json.decode(utf8.decode(r.bodyBytes));
          if (j is Map<String, dynamic> && j['elements'] is List) {
            fini.complete(j);
          } else {
            echec();
          }
        } catch (_) {
          echec();
        }
      }).catchError((_) {
        echec();
      });
    }

    for (int i = 0; i < _serveurs.length; i++) {
      Future.delayed(Duration(seconds: 3 * i), () {
        if (!fini.isCompleted) tenter(_serveurs[i]);
      });
    }
    return fini.future.timeout(const Duration(seconds: 75), onTimeout: () => null);
  }
}

class _Candidat {
  final String nom;
  final List<LatLng> trace;
  final double km;
  final int niveau;
  _Candidat(this.nom, this.trace, this.km, this.niveau);
}
