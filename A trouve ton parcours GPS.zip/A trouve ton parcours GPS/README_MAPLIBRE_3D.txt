VERSION MAPLIBRE - GPS EN PERSPECTIVE

Cette version remplace l'affichage FlutterMap à tuiles raster par MapLibre GL et le style vectoriel OpenFreeMap Liberty. La caméra est inclinée à 60 degrés et orientée selon le cap cible pendant le mode Parcours GPS. Le style peut afficher les bâtiments en volume lorsque les données et le style les fournissent.

Dépendance : maplibre_gl ^0.20.0
Style : https://tiles.openfreemap.org/styles/liberty

Le dépôt fourni ne contenait pas de dossier Android/Gradle. Le workflow .github/workflows/build-apk.yml génère les fichiers Android avec `flutter create`, ajoute les permissions de localisation et compile l'APK via GitHub Actions.

IMPORTANT : cette archive n'a pas pu être compilée dans l'environnement de préparation, car Flutter/Android SDK n'y est pas installé. Il faut lancer le workflow GitHub et vérifier le résultat. Si le build échoue, consulter les logs de l'étape Construire l'APK.
