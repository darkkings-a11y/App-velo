import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:geolocator/geolocator.dart';
import 'package:latlong2/latlong.dart';
import 'package:wakelock_plus/wakelock_plus.dart';
import '../models/parcours.dart';
import '../services/favoris_service.dart';
import '../widgets/profil_altitude.dart';

class CarteScreen extends StatefulWidget {
  final Parcours parcours;

  const CarteScreen({super.key, required this.parcours});

  @override
  State<CarteScreen> createState() => _CarteScreenState();
}

class _CarteScreenState extends State<CarteScreen> {
  static const Color _vert = Color(0xFF16C763);
  static const Color _orange = Color(0xFFFF9100);
  static const Color _bleuRoute = Color(0xFF245BFF);
  static const Color _rougeHorsTrace = Color(0xFFE53935);
  static final Distance _dist = Distance(roundResult: false);

  final MapController _map = MapController();
  StreamSubscription<Position>? _sub;

  // Favori
  bool _favori = false;

  // GPS
  LatLng? _position;
  double _cap = 0;
  double _vitesse = 0;
  bool _gpsActif = false;
  bool _suivre = false;
  double? _ecartM;

  // Mode « Parcours GPS » (guidage)
  bool _modeGps = false;
  bool _termine = false;
  int _idxProgres = 0;
  double _bearingCible = 0;

  @override
  void initState() {
    super.initState();
    _chargerFavori();
  }

  @override
  void dispose() {
    _sub?.cancel();
    WakelockPlus.disable();
    super.dispose();
  }

  void _message(String texte) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(texte)));
  }

  // ---------------- Favoris ----------------

  Future<void> _chargerFavori() async {
    final f = await FavorisService.estFavori(widget.parcours);
    if (mounted) setState(() => _favori = f);
  }

  Future<void> _basculerFavori() async {
    if (_favori) {
      await FavorisService.retirer(widget.parcours);
      _message('Retiré des favoris');
    } else {
      await FavorisService.ajouter(widget.parcours);
      _message('Parcours ajouté aux favoris ❤️');
    }
    if (mounted) setState(() => _favori = !_favori);
  }

  // ---------------- GPS en direct ----------------

  Future<void> _boutonGps() async {
    if (_modeGps) {
      setState(() => _suivre = true);
      if (_position != null) _map.move(_position!, math.max(_map.camera.zoom, 16));
      return;
    }
    if (!_gpsActif) {
      await _demarrerGps();
      return;
    }
    if (!_suivre) {
      setState(() => _suivre = true);
      if (_position != null) {
        _map.move(_position!, math.max(_map.camera.zoom, 15));
      }
      return;
    }
    _arreterGps();
  }

  Future<void> _demarrerGps() async {
    final actif = await Geolocator.isLocationServiceEnabled();
    if (!actif) {
      _message('Active la localisation de ton téléphone.');
      return;
    }
    var perm = await Geolocator.checkPermission();
    if (perm == LocationPermission.denied) {
      perm = await Geolocator.requestPermission();
    }
    if (perm == LocationPermission.denied || perm == LocationPermission.deniedForever) {
      _message('Autorisation de localisation refusée.');
      return;
    }

    setState(() {
      _gpsActif = true;
      _suivre = true;
    });

    _sub = Geolocator.getPositionStream(
      locationSettings: const LocationSettings(
        accuracy: LocationAccuracy.high,
        distanceFilter: 5,
      ),
    ).listen(_surPosition, onError: (_) => _message('Signal GPS perdu.'));
  }

  void _arreterGps() {
    _sub?.cancel();
    _sub = null;
    setState(() {
      _gpsActif = false;
      _suivre = false;
      _position = null;
      _ecartM = null;
    });
  }

  double _normaliser(double b) => ((b % 360) + 360) % 360;

  void _surPosition(Position p) {
    final pos = LatLng(p.latitude, p.longitude);
    final trace = widget.parcours.traceGPS;
    final dists = widget.parcours.distancesKm;
    final n = trace.length;

    int meilleur = _idxProgres;
    double ecart = double.infinity;

    if (n > 0) {
      // On cherche d'abord juste devant la progression (évite de sauter d'un bout à l'autre de la boucle)
      final debut = math.max(0, _idxProgres - 10);
      final fin = math.min(n - 1, _idxProgres + 400);
      for (int i = debut; i <= fin; i++) {
        final d = _dist.as(LengthUnit.Meter, pos, trace[i]);
        if (d < ecart) {
          ecart = d;
          meilleur = i;
        }
      }
      // Si on est très loin, recherche sur tout le tracé
      if (ecart > 400) {
        for (int i = 0; i < n; i++) {
          final d = _dist.as(LengthUnit.Meter, pos, trace[i]);
          if (d < ecart) {
            ecart = d;
            meilleur = i;
          }
        }
      }
    }

    // Point à viser : le tracé le plus proche si on est hors parcours, sinon ~200 m devant
    double bearing = _bearingCible;
    if (n > 0) {
      LatLng cible = trace[meilleur];
      if (ecart <= 60) {
        int j = meilleur;
        if (dists.length == n) {
          final limite = dists[meilleur] + 0.2;
          while (j < n - 1 && dists[j] < limite) {
            j++;
          }
        } else {
          j = math.min(n - 1, meilleur + 20);
        }
        cible = trace[j];
      }
      bearing = _normaliser(_dist.bearing(pos, cible));
    }

    bool fini = _termine;
    if (_modeGps && !fini && n > 10 && meilleur >= n - 8 && ecart < 60) {
      final total = dists.isNotEmpty ? dists.last : 0.0;
      final parcouru = dists.length == n ? dists[meilleur] : 0.0;
      if (total > 0 && parcouru > total * 0.5) {
        fini = true;
        _message('Parcours terminé, bravo ! 🎉');
      }
    }

    setState(() {
      _position = pos;
      _cap = p.heading >= 0 ? p.heading : 0;
      _vitesse = p.speed >= 0 ? p.speed : 0;
      _ecartM = ecart.isFinite ? ecart : null;
      _idxProgres = meilleur;
      _bearingCible = bearing;
      _termine = fini;
    });

    if (_suivre) {
      _map.move(pos, math.max(_map.camera.zoom, _modeGps ? 17 : 15));
    }
  }

  // ---------------- Mode « Parcours GPS » ----------------

  Future<void> _demarrerModeGps() async {
    if (!_gpsActif) {
      await _demarrerGps();
    }
    if (!_gpsActif) return; // autorisation refusée ou GPS désactivé

    await WakelockPlus.enable(); // garde l'écran allumé pendant le guidage
    setState(() {
      _modeGps = true;
      _suivre = true;
      _termine = false;
      _idxProgres = 0;
    });
    if (_position != null) _map.move(_position!, 16);
  }

  Future<void> _terminerModeGps() async {
    await WakelockPlus.disable();
    _arreterGps();
    if (!mounted) return;
    setState(() {
      _modeGps = false;
      _termine = false;
    });
    _voirToutLeParcours(MediaQuery.of(context).size.height);
  }

  String _boussole(double b) {
    const noms = ['Nord', 'Nord-Est', 'Est', 'Sud-Est', 'Sud', 'Sud-Ouest', 'Ouest', 'Nord-Ouest'];
    return noms[((b + 22.5) / 45).floor() % 8];
  }

  // ---------------- Carte ----------------

  MapOptions _optionsCarte(double hauteurEcran) {
    final trace = widget.parcours.traceGPS;
    void surMouvement(MapPosition pos, bool aGeste) {
      if (aGeste && _suivre) setState(() => _suivre = false);
    }

    if (trace.length > 1) {
      return MapOptions(
        initialCameraFit: CameraFit.bounds(
          bounds: LatLngBounds.fromPoints(trace),
          padding: EdgeInsets.fromLTRB(40, 140, 40, hauteurEcran * 0.45),
        ),
        onPositionChanged: surMouvement,
      );
    }
    return MapOptions(
      initialCenter: trace.isNotEmpty ? trace.first : const LatLng(45.75, 4.85),
      initialZoom: 12,
      onPositionChanged: surMouvement,
    );
  }

  void _voirToutLeParcours(double hauteurEcran) {
    final trace = widget.parcours.traceGPS;
    if (trace.length < 2) return;
    _map.fitCamera(CameraFit.bounds(
      bounds: LatLngBounds.fromPoints(trace),
      padding: EdgeInsets.fromLTRB(40, 140, 40, hauteurEcran * (_modeGps ? 0.40 : 0.45)),
    ));
    if (_suivre) setState(() => _suivre = false);
  }

  List<Marker> _marqueurs() {
    final p = widget.parcours;
    final marqueurs = <Marker>[];

    // Centre de la boucle : les étiquettes pointent vers l'intérieur (zone vide)
    double centreLat = 0;
    double centreLon = 0;
    if (p.traceGPS.isNotEmpty) {
      final b = LatLngBounds.fromPoints(p.traceGPS);
      centreLat = (b.north + b.south) / 2;
      centreLon = (b.east + b.west) / 2;
    }
    for (final e in p.etapes) {
      marqueurs.add(Marker(
        point: e.position,
        width: 220,
        height: 70,
        child: _EtapeMarker(
          nom: e.nom,
          adroite: e.position.longitude < centreLon,
          enbas: e.position.latitude > centreLat,
        ),
      ));
    }

    if (p.traceGPS.isNotEmpty) {
      marqueurs.add(Marker(
        point: p.traceGPS.first,
        width: 34,
        height: 34,
        child: Container(
          decoration: BoxDecoration(
            color: _vert,
            shape: BoxShape.circle,
            border: Border.all(color: Colors.white, width: 3),
          ),
          child: const Icon(Icons.flag, color: Colors.black, size: 16),
        ),
      ));
    }

    if (_position != null) {
      marqueurs.add(Marker(
        point: _position!,
        width: 44,
        height: 44,
        child: Transform.rotate(
          angle: (_vitesse > 1.0 ? _cap : _bearingCible) * math.pi / 180,
          child: Container(
            decoration: BoxDecoration(
              color: _bleuRoute,
              shape: BoxShape.circle,
              border: Border.all(color: Colors.white, width: 3),
              boxShadow: const [
                BoxShadow(color: Color(0x66000000), blurRadius: 8, offset: Offset(0, 3)),
              ],
            ),
            child: const Icon(Icons.navigation, color: Colors.white, size: 25),
          ),
        ),
      ));
    }
    return marqueurs;
  }

  @override
  Widget build(BuildContext context) {
    final p = widget.parcours;
    final trace = p.traceGPS;
    final hauteur = MediaQuery.of(context).size.height;
    final haut = MediaQuery.of(context).padding.top;

    IconData iconeGps = Icons.my_location;
    Color couleurGps = Colors.white;
    if (_gpsActif && _suivre) {
      couleurGps = _vert;
    } else if (_gpsActif) {
      iconeGps = Icons.location_searching;
      couleurGps = const Color(0xFF2979FF);
    }

    return Scaffold(
      backgroundColor: const Color(0xFF0B0F0D),
      body: Stack(
        children: [
          FlutterMap(
            mapController: _map,
            options: _optionsCarte(hauteur),
            children: [
              // Fond cartographique Voyager : rues, carrefours et zones mieux différenciés.
              // Tuiles publiques sans clé API ; une connexion Internet reste nécessaire.
              TileLayer(
                urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                userAgentPackageName: 'com.example.trouve_ton_parcours',
                maxZoom: 20,
              ),
              if (trace.isNotEmpty)
                PolylineLayer(
                  polylines: [
                    // Liseré sombre sous la route pour un contraste de GPS automobile.
                    Polyline(points: trace, color: const Color(0xCCFFFFFF), strokeWidth: 11),
                    Polyline(points: trace, color: const Color(0xFF1737A8), strokeWidth: 8),
                    Polyline(points: trace, color: _bleuRoute, strokeWidth: 5),
                  ],
                ),
              MarkerLayer(markers: _marqueurs()),
            ],
          ),

          // Titre + cœur favori
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            child: Container(
              padding: EdgeInsets.fromLTRB(8, haut + 6, 8, 24),
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Color(0xDD000000), Color(0x00000000)],
                ),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  IconButton(
                    icon: const Icon(Icons.arrow_back, color: Colors.white),
                    onPressed: () => Navigator.pop(context),
                  ),
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.only(top: 8),
                      child: Text(
                        p.titre,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                  IconButton(
                    tooltip: _favori ? 'Retirer des favoris' : 'Ajouter aux favoris',
                    icon: Icon(
                      _favori ? Icons.favorite : Icons.favorite_border,
                      color: _favori ? Colors.redAccent : Colors.white,
                      size: 28,
                    ),
                    onPressed: _basculerFavori,
                  ),
                ],
              ),
            ),
          ),

          // État du parcours : indicateur rouge/vert en haut, en permanence pendant le guidage.
          if (_modeGps && !_termine)
            Positioned(
              top: haut + 76,
              left: 16,
              right: 16,
              child: _BandeauEtatParcours(
                surParcours: _position != null && (_ecartM ?? double.infinity) <= 60,
                enAttenteGps: _position == null,
                distanceM: _ecartM,
              ),
            )
          else if (!_modeGps && _ecartM != null && _ecartM! > 120)
            Positioned(
              top: haut + 84,
              left: 16,
              right: 16,
              child: _BandeauEtatParcours(
                surParcours: false,
                distanceM: _ecartM,
              ),
            ),

          // Boutons ronds à droite
          Positioned(
            right: 14,
            bottom: _modeGps ? 290 : hauteur * 0.40 + 14,
            child: Column(
              children: [
                _BoutonRond(
                  icone: iconeGps,
                  couleur: couleurGps,
                  onTap: _boutonGps,
                ),
                const SizedBox(height: 12),
                _BoutonRond(
                  icone: Icons.zoom_out_map,
                  couleur: Colors.white,
                  onTap: () => _voirToutLeParcours(hauteur),
                ),
              ],
            ),
          ),

          // Panneau du bas : guidage GPS ou résumé du parcours
          if (_modeGps)
            Positioned(left: 0, right: 0, bottom: 0, child: _panneauGps())
          else
            DraggableScrollableSheet(
              initialChildSize: 0.40,
              minChildSize: 0.40,
              maxChildSize: 0.90,
              builder: (context, scroll) {
                return Container(
                  decoration: const BoxDecoration(
                    color: Color(0xFF111614),
                    borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
                    boxShadow: [BoxShadow(color: Colors.black54, blurRadius: 12)],
                  ),
                  child: ListView(
                    controller: scroll,
                    padding: const EdgeInsets.fromLTRB(16, 10, 16, 24),
                    children: [
                      Center(
                        child: Container(
                          width: 40,
                          height: 4,
                          decoration: BoxDecoration(
                            color: Colors.white24,
                            borderRadius: BorderRadius.circular(2),
                          ),
                        ),
                      ),
                      const SizedBox(height: 14),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          _stat('Distance totale', '${p.distanceKm.toStringAsFixed(1)} km', Colors.white),
                          _stat('Dénivelé positif', '+${p.denivelePos} m', _vert),
                          _stat('Dénivelé négatif', '-${p.deniveleNeg} m', const Color(0xFFFF8A65)),
                        ],
                      ),
                      const SizedBox(height: 14),
                      SizedBox(
                        height: 130,
                        child: ProfilAltitude(
                          distancesKm: p.distancesKm,
                          altitudes: p.altitudes,
                          repereKm: p.etapes.map((e) => e.distanceKm).toList(),
                        ),
                      ),
                      const SizedBox(height: 14),
                      SizedBox(
                        height: 50,
                        child: ElevatedButton.icon(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFF2E9E4F),
                            foregroundColor: Colors.white,
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(25)),
                          ),
                          onPressed: _demarrerModeGps,
                          icon: const Icon(Icons.navigation),
                          label: const Text(
                            'Parcours GPS',
                            style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
                          ),
                        ),
                      ),
                      if (p.troncons.isNotEmpty) ...[
                        const SizedBox(height: 70),
                        const Text(
                          'Détail par tronçon',
                          style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold),
                        ),
                        const SizedBox(height: 6),
                        ...p.troncons.map(_ligneTroncon),
                      ],
                      const SizedBox(height: 16),
                      const Text(
                        '© OpenStreetMap contributors',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Colors.white30, fontSize: 10),
                      ),
                    ],
                  ),
                );
              },
            ),
        ],
      ),
    );
  }

  /// Panneau affiché pendant le guidage « Parcours GPS ».
  Widget _panneauGps() {
    final p = widget.parcours;
    final n = p.traceGPS.length;
    final aDonnees = n > 0 && p.distancesKm.length == n;

    final idx = math.max(0, math.min(_idxProgres, n - 1));
    final parcouru = aDonnees ? p.distancesKm[idx] : 0.0;
    final restant = math.max(0.0, p.distanceKm - parcouru);

    EtapeVille? prochaine;
    for (final e in p.etapes) {
      if (e.distanceKm > parcouru + 0.05) {
        prochaine = e;
        break;
      }
    }

    final horsTrace = (_ecartM ?? 0) > 60;
    String consigne;
    Color couleur;
    if (_termine) {
      consigne = 'Parcours terminé, bravo !';
      couleur = _vert;
    } else if (_position == null) {
      consigne = 'Recherche du signal GPS…';
      couleur = Colors.white70;
    } else if (horsTrace) {
      consigne = 'Rejoins le tracé (${_ecartM!.round()} m) vers le ${_boussole(_bearingCible)}';
      couleur = _rougeHorsTrace;
    } else {
      consigne = 'Suis le tracé vers le ${_boussole(_bearingCible)}';
      couleur = _vert;
    }

    // En mouvement : la flèche est relative à ta direction. À l'arrêt : relative au nord (carte).
    final angleFleche = (_vitesse > 1.0 ? _bearingCible - _cap : _bearingCible) * math.pi / 180;

    return Container(
      padding: EdgeInsets.fromLTRB(16, 14, 16, 16 + MediaQuery.of(context).padding.bottom),
      decoration: const BoxDecoration(
        color: Color(0xFF111614),
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        boxShadow: [BoxShadow(color: Colors.black54, blurRadius: 12)],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            children: [
              if (_position != null && !_termine)
                Transform.rotate(
                  angle: angleFleche,
                  child: Icon(Icons.navigation, color: couleur, size: 48),
                )
              else
                Icon(_termine ? Icons.emoji_events : Icons.gps_not_fixed, color: couleur, size: 44),
              const SizedBox(width: 14),
              Expanded(
                child: Text(
                  consigne,
                  style: TextStyle(color: couleur, fontSize: 17, fontWeight: FontWeight.bold),
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _stat('Parcouru', '${parcouru.toStringAsFixed(1)} km', Colors.white),
              _stat('Restant', '${restant.toStringAsFixed(1)} km', Colors.white),
              _stat(
                prochaine != null ? 'Prochaine : ${prochaine.nom}' : 'Arrivée',
                prochaine != null
                    ? 'dans ${math.max(0.0, prochaine.distanceKm - parcouru).toStringAsFixed(1)} km'
                    : '${restant.toStringAsFixed(1)} km',
                _vert,
              ),
            ],
          ),
          const SizedBox(height: 14),
          SizedBox(
            width: double.infinity,
            height: 46,
            child: OutlinedButton.icon(
              style: OutlinedButton.styleFrom(
                foregroundColor: const Color(0xFFFF8A65),
                side: const BorderSide(color: Color(0xFFFF8A65)),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(23)),
              ),
              onPressed: _terminerModeGps,
              icon: const Icon(Icons.stop_circle_outlined),
              label: const Text('Arrêter le GPS', style: TextStyle(fontWeight: FontWeight.bold)),
            ),
          ),
        ],
      ),
    );
  }

  Widget _stat(String label, String valeur, Color couleur) {
    return Column(
      children: [
        ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 120),
          child: Text(
            label,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(color: Colors.white60, fontSize: 11),
          ),
        ),
        const SizedBox(height: 4),
        Text(valeur, style: TextStyle(color: couleur, fontSize: 18, fontWeight: FontWeight.bold)),
      ],
    );
  }

  Widget _ligneTroncon(TronconParcours t) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 10),
      decoration: const BoxDecoration(
        border: Border(bottom: BorderSide(color: Colors.white12)),
      ),
      child: Row(
        children: [
          Expanded(
            child: Text(
              '${t.depart} → ${t.arrivee}',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(color: Colors.white, fontSize: 14),
            ),
          ),
          Text('${t.distanceKm.toStringAsFixed(1)} km',
              style: const TextStyle(color: Colors.white70, fontSize: 13)),
          const SizedBox(width: 12),
          Text('+${t.denivelePos} m', style: const TextStyle(color: _vert, fontSize: 13)),
          const SizedBox(width: 8),
          Text('-${t.deniveleNeg} m', style: const TextStyle(color: Color(0xFFFF8A65), fontSize: 13)),
        ],
      ),
    );
  }
}

class _BandeauEtatParcours extends StatelessWidget {
  final bool surParcours;
  final bool enAttenteGps;
  final double? distanceM;

  const _BandeauEtatParcours({
    required this.surParcours,
    this.enAttenteGps = false,
    this.distanceM,
  });

  @override
  Widget build(BuildContext context) {
    final couleur = enAttenteGps
        ? const Color(0xFF455A64)
        : surParcours
            ? const Color(0xFF168344)
            : const Color(0xFFD62828);
    final texte = enAttenteGps
        ? 'Recherche du signal GPS…'
        : surParcours
            ? 'Vous êtes sur le parcours'
            : 'Vous n’êtes pas sur le parcours';

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 12),
      decoration: BoxDecoration(
        color: couleur.withOpacity(0.96),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Colors.white, width: 1.5),
        boxShadow: const [BoxShadow(color: Color(0x55000000), blurRadius: 8, offset: Offset(0, 3))],
      ),
      child: Row(
        children: [
          Container(
            width: 12,
            height: 12,
            decoration: const BoxDecoration(color: Colors.white, shape: BoxShape.circle),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              texte,
              style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w800),
            ),
          ),
          if (!enAttenteGps && !surParcours && distanceM != null) ...[
            const SizedBox(width: 6),
            Text('${distanceM!.round()} m', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
          ],
        ],
      ),
    );
  }
}

class _BoutonRond extends StatelessWidget {
  final IconData icone;
  final Color couleur;
  final VoidCallback onTap;

  const _BoutonRond({required this.icone, required this.couleur, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: const Color(0xEE1B211E),
      shape: const CircleBorder(side: BorderSide(color: Colors.white24)),
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Icon(icone, color: couleur, size: 24),
        ),
      ),
    );
  }
}

/// Point sur la ville + trait + étiquette avec le nom.
class _EtapeMarker extends StatelessWidget {
  final String nom;
  final bool adroite;
  final bool enbas;

  const _EtapeMarker({required this.nom, required this.adroite, required this.enbas});

  @override
  Widget build(BuildContext context) {
    final etiquette = Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
      decoration: BoxDecoration(
        color: const Color(0xDD000000),
        borderRadius: BorderRadius.circular(6),
        border: Border.all(color: const Color(0x6600E676)),
      ),
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 95),
        child: Text(
          nom,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w600),
        ),
      ),
    );

    return Stack(
      clipBehavior: Clip.none,
      children: [
        Positioned.fill(
          child: CustomPaint(painter: _TraitPainter(adroite, enbas)),
        ),
        Positioned(
          left: 105,
          top: 30,
          child: Container(
            width: 10,
            height: 10,
            decoration: BoxDecoration(
              color: Colors.white,
              shape: BoxShape.circle,
              border: Border.all(color: const Color(0xFF00E676), width: 2),
            ),
          ),
        ),
        Positioned(
          left: adroite ? 125 : null,
          right: adroite ? null : 125,
          top: enbas ? 48 : 0,
          child: etiquette,
        ),
      ],
    );
  }
}

class _TraitPainter extends CustomPainter {
  final bool adroite;
  final bool enbas;
  _TraitPainter(this.adroite, this.enbas);

  @override
  void paint(Canvas canvas, Size size) {
    final centre = Offset(size.width / 2, size.height / 2);
    final bout = Offset(adroite ? 125 : 95, enbas ? 59 : 11);
    canvas.drawLine(
      centre,
      bout,
      Paint()
        ..color = Colors.white70
        ..strokeWidth = 1.2,
    );
  }

  @override
  bool shouldRepaint(covariant _TraitPainter old) => old.adroite != adroite || old.enbas != enbas;
}
