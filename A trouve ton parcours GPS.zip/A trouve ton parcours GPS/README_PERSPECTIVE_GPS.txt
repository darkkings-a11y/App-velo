MODIFICATION GPS - VUE TYPE TOMTOM

Fichier modifie : lib/screens/carte_screen.dart

Pendant le mode « Parcours GPS » :
- la carte est inclinee avec un effet de perspective ;
- la carte pivote selon la direction du parcours pour placer l'avant vers le haut ;
- les panneaux de guidage restent droits et lisibles ;
- hors du mode GPS, la carte reprend sa vue normale.

Important : il s'agit d'un effet de perspective applique a la carte OpenStreetMap 2D, pas d'une vraie carte 3D avec batiments/relief 3D. Une vraie vue 3D exige un moteur cartographique qui prend en charge la 3D.

Pour integrer : remplacer le fichier lib/screens/carte_screen.dart du projet par celui fourni ici.
