import 'package:flutter_test/flutter_test.dart';
import 'package:trouve_ton_parcours/main.dart';

void main() {
  testWidgets('AppVelo est le widget racine de l’application', (tester) async {
    await tester.pumpWidget(const AppVelo());
    expect(find.byType(AppVelo), findsOneWidget);
  });
}
