import 'package:flutter/material.dart';
import 'screens/splash_screen.dart';

void main() {
  runApp(const AppVelo());
}

class AppVelo extends StatelessWidget {
  const AppVelo({super.key});

  @override
  Widget build(BuildContext context) {
    const vert = Color(0xFF2ED573);
    const fond = Color(0xFF0B0F0D);
    return MaterialApp(
      title: 'TotoPa',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        colorScheme: ColorScheme.fromSeed(
          seedColor: vert,
          brightness: Brightness.dark,
        ).copyWith(
          primary: vert,
          onPrimary: const Color(0xFF06210F),
          surface: fond,
        ),
        scaffoldBackgroundColor: fond,
        navigationBarTheme: NavigationBarThemeData(
          backgroundColor: const Color(0xFF111614),
          indicatorColor: const Color(0xFF1F3A2A),
          labelTextStyle: const WidgetStatePropertyAll(
            TextStyle(fontSize: 12, fontWeight: FontWeight.w600),
          ),
        ),
        snackBarTheme: const SnackBarThemeData(
          backgroundColor: Color(0xFF263029),
          contentTextStyle: TextStyle(color: Colors.white),
          behavior: SnackBarBehavior.floating,
        ),
      ),
      home: const SplashScreen(),
    );
  }
}
