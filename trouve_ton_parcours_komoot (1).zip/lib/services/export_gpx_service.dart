import 'dart:convert';
import 'dart:typed_data';
import 'package:file_picker/file_picker.dart';
import '../models/parcours.dart';

/// Export d'un parcours en fichier GPX (lisible par Komoot, Garmin, Strava, Wahoo, OsmAnd, etc.).
class ExportGpxService {
  static String _echapper(String s) => s
      .replaceAll('&', '&amp;')
      .replaceAll('<', '&lt;')
      .replaceAll('>', '&gt;')
      .replaceAll('"', '&quot;')
      .replaceAll("'", '&apos;');

  /// Contenu GPX du parcours : une trace (avec altitudes si on les a) et les villes traversées en points de passage.
  static String genererGpx(Parcours p) {
    final b = StringBuffer()
      ..writeln('<?xml version="1.0" encoding="UTF-8"?>')
      ..writeln('<gpx version="1.1" creator="TotoPa" xmlns="http://www.topografix.com/GPX/1/1">')
      ..writeln('  <metadata><name>${_echapper(p.titre)}</name></metadata>');

    for (final e in p.etapes) {
      b.writeln('  <wpt lat="${e.position.latitude.toStringAsFixed(6)}" lon="${e.position.longitude.toStringAsFixed(6)}">'
          '<name>${_echapper(e.nom)}</name></wpt>');
    }

    b
      ..writeln('  <trk>')
      ..writeln('    <name>${_echapper(p.titre)}</name>')
      ..writeln('    <trkseg>');
    final avecAltitudes = p.altitudes.length == p.traceGPS.length;
    for (var i = 0; i < p.traceGPS.length; i++) {
      final pt = p.traceGPS[i];
      final lat = pt.latitude.toStringAsFixed(6);
      final lon = pt.longitude.toStringAsFixed(6);
      if (avecAltitudes) {
        b.writeln('      <trkpt lat="$lat" lon="$lon"><ele>${p.altitudes[i].toStringAsFixed(1)}</ele></trkpt>');
      } else {
        b.writeln('      <trkpt lat="$lat" lon="$lon"/>');
      }
    }
    b
      ..writeln('    </trkseg>')
      ..writeln('  </trk>')
      ..writeln('</gpx>');
    return b.toString();
  }

  /// Nom de fichier sûr (sans accents ni caractères interdits), sans l'extension.
  static String nomFichier(Parcours p) {
    const accents = {
      'à': 'a', 'â': 'a', 'ä': 'a', 'é': 'e', 'è': 'e', 'ê': 'e', 'ë': 'e', 'î': 'i', 'ï': 'i',
      'ô': 'o', 'ö': 'o', 'ù': 'u', 'û': 'u', 'ü': 'u', 'ç': 'c', 'œ': 'oe', 'ÿ': 'y',
    };
    final bas = p.titre.toLowerCase();
    final sb = StringBuffer();
    for (final c in bas.split('')) {
      sb.write(accents[c] ?? c);
    }
    var nom = sb.toString().replaceAll(RegExp(r'[^a-z0-9]+'), '_').replaceAll(RegExp(r'^_+|_+$'), '');
    if (nom.length > 60) nom = nom.substring(0, 60);
    return nom.isEmpty ? 'parcours' : nom;
  }

  /// Ouvre la fenêtre d'enregistrement du téléphone (choix du dossier, par exemple Téléchargements)
  /// et y écrit le GPX. Retourne le chemin choisi, ou null si la personne a annulé.
  static Future<String?> exporter(Parcours p) async {
    final octets = Uint8List.fromList(utf8.encode(genererGpx(p)));
    return FilePicker.platform.saveFile(
      dialogTitle: 'Enregistrer le parcours (GPX)',
      fileName: '${nomFichier(p)}.gpx',
      bytes: octets,
      type: FileType.any,
    );
  }
}
