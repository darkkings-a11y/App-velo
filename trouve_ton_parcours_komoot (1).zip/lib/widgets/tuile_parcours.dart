import 'package:flutter/material.dart';
import '../models/parcours.dart';

/// Carte de parcours façon Komoot : pastille numérotée, titre, distance / durée / dénivelé,
/// petit profil d'altitude. Quand elle est sélectionnée, un bouton « Ouvrir » apparaît.
class TuileParcours extends StatelessWidget {
  static const Color vert = Color(0xFF2ED573);

  final Parcours parcours;
  final int? numero; // numéro affiché dans la pastille (même numéro que sur la carte)
  final bool selectionne;
  final bool afficherBouton;
  final VoidCallback onTap;
  final VoidCallback? onOuvrir;
  final Widget? fin; // ex. le cœur des favoris

  const TuileParcours({
    super.key,
    required this.parcours,
    required this.onTap,
    this.numero,
    this.selectionne = false,
    this.afficherBouton = false,
    this.onOuvrir,
    this.fin,
  });

  @override
  Widget build(BuildContext context) {
    final p = parcours;
    final Color accent = selectionne ? vert : const Color(0xFF9AA8A1);

    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Material(
        color: selectionne ? const Color(0xFF14261B) : const Color(0xFF151A17),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: BorderSide(
            color: selectionne ? vert : const Color(0xFF2A322E),
            width: selectionne ? 2 : 1,
          ),
        ),
        child: InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    _pastille(accent),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            p.titre,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w700,
                              color: Color(0xFFF1F5F2),
                            ),
                          ),
                          const SizedBox(height: 4),
                          _etiquettes(),
                        ],
                      ),
                    ),
                    if (fin != null) fin!,
                  ],
                ),
                const SizedBox(height: 12),
                Wrap(
                  spacing: 18,
                  runSpacing: 6,
                  children: [
                    _stat(Icons.straighten, p.distance),
                    _stat(Icons.schedule, p.duree),
                    _stat(Icons.trending_up, p.denivele),
                  ],
                ),
                if (p.altitudes.length >= 2) ...[
                  const SizedBox(height: 10),
                  SizedBox(
                    height: 34,
                    width: double.infinity,
                    child: CustomPaint(painter: _ProfilPainter(p.altitudes, accent)),
                  ),
                ],
                if (selectionne && afficherBouton && onOuvrir != null) ...[
                  const SizedBox(height: 12),
                  SizedBox(
                    width: double.infinity,
                    height: 46,
                    child: FilledButton.icon(
                      style: FilledButton.styleFrom(
                        backgroundColor: vert,
                        foregroundColor: const Color(0xFF06210F),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(23)),
                      ),
                      onPressed: onOuvrir,
                      icon: const Icon(Icons.navigation),
                      label: const Text(
                        'Ouvrir le parcours',
                        style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _pastille(Color accent) {
    return Container(
      width: 34,
      height: 34,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: selectionne ? vert : const Color(0xFF151A17),
        shape: BoxShape.circle,
        border: Border.all(color: accent, width: 2),
      ),
      child: numero != null
          ? Text(
              '$numero',
              style: TextStyle(
                color: selectionne ? const Color(0xFF06210F) : accent,
                fontWeight: FontWeight.bold,
                fontSize: 15,
              ),
            )
          : Icon(Icons.directions_bike, size: 18, color: accent),
    );
  }

  Widget _etiquettes() {
    final p = parcours;
    final IconData icone;
    final Color couleur;
    final String texte;
    if (p.estRecommande) {
      icone = Icons.verified;
      couleur = const Color(0xFFFFC043);
      texte = p.popularite > 0 ? 'Recommandé · ${p.popularite} vues' : 'Recommandé';
    } else if (p.estOpenData) {
      icone = Icons.alt_route;
      couleur = const Color(0xFF5AA9FF);
      texte = p.detailSource.isNotEmpty ? 'Balisé · ${p.detailSource}' : 'Itinéraire balisé';
    } else {
      icone = Icons.auto_awesome;
      couleur = const Color(0xFF9AA8A1);
      texte = 'Généré pour toi';
    }
    return Wrap(
      spacing: 10,
      runSpacing: 2,
      crossAxisAlignment: WrapCrossAlignment.center,
      children: [
        Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icone, size: 15, color: couleur),
            const SizedBox(width: 4),
            Text(texte, style: TextStyle(fontSize: 12.5, color: couleur, fontWeight: FontWeight.w600)),
          ],
        ),
        if (p.difficulte.isNotEmpty)
          Text(p.difficulte, style: const TextStyle(fontSize: 12.5, color: Color(0xFF9AA8A1))),
      ],
    );
  }

  Widget _stat(IconData icone, String valeur) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icone, size: 18, color: const Color(0xFF9AA8A1)),
        const SizedBox(width: 5),
        Text(
          valeur,
          style: const TextStyle(fontSize: 14.5, fontWeight: FontWeight.w700, color: Color(0xFFF1F5F2)),
        ),
      ],
    );
  }
}

/// Mini profil d'altitude (courbe + aire légère), sans axes.
class _ProfilPainter extends CustomPainter {
  final List<double> altitudes;
  final Color couleur;

  _ProfilPainter(this.altitudes, this.couleur);

  @override
  void paint(Canvas canvas, Size size) {
    final n = altitudes.length;
    if (n < 2) return;
    final pas = n > 120 ? n / 120 : 1.0;
    final pts = <double>[];
    for (double i = 0; i < n; i += pas) {
      pts.add(altitudes[i.floor()]);
    }
    pts.add(altitudes.last);

    double mn = pts.first, mx = pts.first;
    for (final a in pts) {
      if (a < mn) mn = a;
      if (a > mx) mx = a;
    }
    final plage = (mx - mn) < 10 ? 10.0 : (mx - mn);
    final dx = size.width / (pts.length - 1);

    final ligne = Path();
    final aire = Path();
    for (int i = 0; i < pts.length; i++) {
      final x = i * dx;
      final y = size.height - 3 - ((pts[i] - mn) / plage) * (size.height - 6);
      if (i == 0) {
        ligne.moveTo(x, y);
        aire.moveTo(x, size.height);
        aire.lineTo(x, y);
      } else {
        ligne.lineTo(x, y);
        aire.lineTo(x, y);
      }
    }
    aire.lineTo(size.width, size.height);
    aire.close();

    canvas.drawPath(aire, Paint()..color = couleur.withValues(alpha: 0.15));
    canvas.drawPath(
      ligne,
      Paint()
        ..color = couleur
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2
        ..strokeJoin = StrokeJoin.round,
    );
  }

  @override
  bool shouldRepaint(covariant _ProfilPainter old) =>
      old.altitudes != altitudes || old.couleur != couleur;
}
