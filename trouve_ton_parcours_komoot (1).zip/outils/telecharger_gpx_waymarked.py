#!/usr/bin/env python3
"""
Remplit la base de parcours de l'appli (assets/gpx/) avec des itinéraires vélo / VTT d'OpenStreetMap,
téléchargés depuis Waymarked Trails (https://waymarkedtrails.org, données © OpenStreetMap contributors, licence ODbL).

À lancer sur TON ordinateur (il faut internet), pas dans l'appli :

    python3 outils/telecharger_gpx_waymarked.py --liste-france --type cycling --max 150
    python3 outils/telecharger_gpx_waymarked.py --ids mes_ids.txt --type mtb

Ensuite, remets le dossier assets/gpx/ (fichiers .gpx + index.json mis à jour) dans le zip du projet.

Options utiles :
  --liste-france          cherche les itinéraires nationaux / régionaux de France (réseau icn, ncn, rcn) via Overpass
  --reseaux icn,ncn,rcn   réseaux à garder (ajoute lcn pour les itinéraires locaux, beaucoup plus nombreux)
  --bbox S,O,N,E          limite la recherche à un rectangle (ex. 45.4,4.6,46.1,5.3 pour le Rhône)
  --ids fichier.txt       au lieu d'Overpass : un numéro de relation OSM par ligne
  --max N                 nombre maximum d'itinéraires à télécharger (défaut 100)
  --points N              points gardés par tracé (défaut 1500) : plus petit = appli plus légère
  --pause S               secondes entre deux téléchargements (défaut 2, sois gentil avec le serveur)

Les fichiers déjà présents ne sont pas retéléchargés. L'index.json existant est conservé.
Pense à citer « © OpenStreetMap contributors » dans l'appli (c'est déjà écrit en bas de la liste des parcours).
"""
import argparse
import json
import math
import os
import re
import sys
import time
import unicodedata
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET

OVERPASS = 'https://overpass-api.de/api/interpreter'
AGENT = 'TotoPa-import-GPX/1.0 (projet personnel ; itineraires OpenStreetMap)'
NS = {'g': 'http://www.topografix.com/GPX/1/1', 'g0': 'http://www.topografix.com/GPX/1/0'}


def http_get(url, donnees=None, delai=120):
    req = urllib.request.Request(url, data=donnees, headers={'User-Agent': AGENT})
    with urllib.request.urlopen(req, timeout=delai) as r:
        return r.read()


def lister_relations(type_osm, reseaux, bbox):
    """Numéros + noms des relations OSM route=bicycle (ou mtb) des réseaux demandés."""
    filtre_reseau = '["network"~"^(%s)$"]' % '|'.join(reseaux)
    if bbox:
        zone = '(%s)' % bbox
        pre = ''
    else:
        pre = 'area["ISO3166-1"="FR"][admin_level=2]->.fr;'
        zone = '(area.fr)'
    requete = '[out:json][timeout:180];%srelation["route"="%s"]%s%s;out tags;' % (pre, type_osm, filtre_reseau, zone)
    brut = http_get(OVERPASS, urllib.parse.urlencode({'data': requete}).encode())
    elements = json.loads(brut).get('elements', [])
    res = []
    for e in elements:
        t = e.get('tags', {})
        nom = t.get('name') or t.get('ref') or ''
        res.append((e['id'], nom))
    return res


def telecharger_gpx(flavour, rel_id):
    url = 'https://%s.waymarkedtrails.org/api/v1/details/relation/%s/geometry/gpx' % (flavour, rel_id)
    return http_get(url)


def lire_gpx(octets):
    """Retourne (nom, [(lat, lon, ele|None), ...])."""
    racine = ET.fromstring(octets)

    def tous(nom):
        out = []
        for ns in ('http://www.topografix.com/GPX/1/1', 'http://www.topografix.com/GPX/1/0', ''):
            out = racine.findall('.//{%s}%s' % (ns, nom)) if ns else racine.findall('.//%s' % nom)
            if out:
                return out
        return []

    pts = []
    for e in tous('trkpt') or tous('rtept'):
        try:
            lat, lon = float(e.get('lat')), float(e.get('lon'))
        except (TypeError, ValueError):
            continue
        ele = None
        for enfant in e:
            if enfant.tag.endswith('ele'):
                try:
                    ele = float(enfant.text)
                except (TypeError, ValueError):
                    pass
        pts.append((lat, lon, ele))
    nom = ''
    for e in tous('name'):
        if e.text and e.text.strip():
            nom = e.text.strip()
            break
    return nom, pts


def distance_km(a, b):
    r = 6371.0088
    p1, p2 = math.radians(a[0]), math.radians(b[0])
    dphi, dl = p2 - p1, math.radians(b[1] - a[1])
    h = math.sin(dphi / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * r * math.asin(math.sqrt(h))


def longueur_km(pts):
    return sum(distance_km(pts[i], pts[i + 1]) for i in range(len(pts) - 1))


def alleger(pts, maxi):
    if len(pts) <= maxi:
        return pts
    pas = (len(pts) - 1) / (maxi - 1)
    return [pts[round(i * pas)] for i in range(maxi)]


def echapper(s):
    return (s.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
             .replace('"', '&quot;'))


def ecrire_gpx(chemin, nom, pts):
    lignes = ['<?xml version="1.0" encoding="UTF-8"?>',
              '<gpx version="1.1" creator="TotoPa" xmlns="http://www.topografix.com/GPX/1/1">',
              '  <metadata><name>%s</name><copyright author="OpenStreetMap contributors">'
              '<license>https://opendatacommons.org/licenses/odbl/</license></copyright></metadata>' % echapper(nom),
              '  <trk><name>%s</name><trkseg>' % echapper(nom)]
    for lat, lon, ele in pts:
        if ele is None:
            lignes.append('    <trkpt lat="%.6f" lon="%.6f"/>' % (lat, lon))
        else:
            lignes.append('    <trkpt lat="%.6f" lon="%.6f"><ele>%.1f</ele></trkpt>' % (lat, lon, ele))
    lignes += ['  </trkseg></trk>', '</gpx>', '']
    with open(chemin, 'w', encoding='utf-8') as f:
        f.write('\n'.join(lignes))


def nom_fichier(rel_id, nom):
    sans_accents = unicodedata.normalize('NFKD', nom).encode('ascii', 'ignore').decode()
    mots = re.sub(r'[^a-z0-9]+', '_', sans_accents.lower()).strip('_')[:40]
    return 'osm_%s%s.gpx' % (rel_id, ('_' + mots) if mots else '')


def traiter(octets, rel_id, nom_osm, style, dossier, max_points):
    """GPX brut -> fichier allégé + entrée d'index. Retourne None si le tracé est inutilisable."""
    nom, pts = lire_gpx(octets)
    if len(pts) < 2:
        return None
    nom = nom or nom_osm or 'Itinéraire OSM %s' % rel_id
    km = longueur_km(pts)
    if km < 3:
        return None
    pts = alleger(pts, max_points)
    fichier = nom_fichier(rel_id, nom)
    ecrire_gpx(os.path.join(dossier, fichier), nom, pts)
    entree = {
        'fichier': fichier,
        'titre': nom,
        'popularite': 0,
        'verifie': False,
        'source': 'OpenStreetMap',
        'lat': round(pts[0][0], 5),
        'lon': round(pts[0][1], 5),
        'km': round(km, 1),
    }
    if style:
        entree['style'] = style
    return entree


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--type', choices=['cycling', 'mtb'], default='cycling')
    ap.add_argument('--liste-france', action='store_true')
    ap.add_argument('--ids')
    ap.add_argument('--reseaux', default='icn,ncn,rcn')
    ap.add_argument('--bbox')
    ap.add_argument('--max', type=int, default=100)
    ap.add_argument('--points', type=int, default=1500)
    ap.add_argument('--pause', type=float, default=2.0)
    ap.add_argument('--sortie', default=os.path.join('assets', 'gpx'))
    a = ap.parse_args()

    if not a.liste_france and not a.ids and not a.bbox:
        ap.error('choisis --liste-france, --bbox ou --ids')

    os.makedirs(a.sortie, exist_ok=True)
    index_chemin = os.path.join(a.sortie, 'index.json')
    index = []
    if os.path.exists(index_chemin):
        with open(index_chemin, encoding='utf-8') as f:
            index = json.load(f)
    deja = {e.get('fichier') for e in index}

    if a.ids:
        with open(a.ids, encoding='utf-8') as f:
            relations = [(int(l.split()[0]), '') for l in f if l.strip() and l.strip()[0].isdigit()]
    else:
        osm = 'mtb' if a.type == 'mtb' else 'bicycle'
        print('Recherche des itinéraires %s (%s)…' % (osm, a.reseaux))
        relations = lister_relations(osm, a.reseaux.split(','), a.bbox)
        print('%d itinéraires trouvés.' % len(relations))

    style = 'vtt' if a.type == 'mtb' else None
    ajoutes = 0
    for rel_id, nom_osm in relations:
        if ajoutes >= a.max:
            break
        if any(f.startswith('osm_%s' % rel_id) for f in deja):
            continue
        try:
            octets = telecharger_gpx(a.type, rel_id)
            entree = traiter(octets, rel_id, nom_osm, style, a.sortie, a.points)
        except Exception as e:  # réseau, XML cassé…
            print('  - %s ignoré (%s)' % (rel_id, e))
            time.sleep(a.pause)
            continue
        if entree:
            index.append(entree)
            deja.add(entree['fichier'])
            ajoutes += 1
            print('  + %s (%.0f km)' % (entree['titre'], entree['km']))
            with open(index_chemin, 'w', encoding='utf-8') as f:
                json.dump(index, f, ensure_ascii=False, indent=2)
        time.sleep(a.pause)

    print('Terminé : %d nouveaux parcours, %d au total dans %s' % (ajoutes, len(index), index_chemin))


if __name__ == '__main__':
    sys.exit(main())
