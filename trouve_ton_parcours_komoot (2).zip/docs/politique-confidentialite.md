# Politique de confidentialité — TotoPa

*Dernière mise à jour : novembre 2026. Texte à relire et adapter par l'éditeur de l'application avant publication (nom, contact).*

## Ce que fait l'application
TotoPa permet de trouver, planifier et suivre des parcours à vélo (boucles, allers-retours, points à point).

## Données collectées
Aucune. L'application n'a pas de compte, pas de publicité, pas de statistiques d'usage et pas de serveur propre.

## Données gardées sur ton téléphone
- tes parcours favoris (y compris ceux que tu planifies ou importes) ;
- le nombre de fois où tu as ouvert chaque parcours.

Elles restent sur l'appareil et disparaissent si tu les supprimes ou désinstalles l'application.

## Position
La position n'est utilisée que si tu appuies sur « Autour de moi » ou sur un bouton de position, et pendant le guidage d'un parcours. Elle n'est pas enregistrée.

## Services en ligne contactés
Pour fonctionner, l'application interroge des services publics. Chacun reçoit ce qui est nécessaire à sa tâche, ainsi que l'adresse IP de l'appareil :

| Service | Données envoyées |
|---|---|
| OpenFreeMap | zone de carte affichée |
| Géoplateforme (IGN), geo.api.gouv.fr | texte tapé (ville, rue) ou coordonnées d'un point |
| OpenStreetMap (serveurs Overpass) | zone autour de la ville cherchée |
| BRouter | points de départ, de passage et d'arrivée |
| Open-Meteo | coordonnées (météo, altitudes) |
| Wikipédia | noms des villes traversées (photos) |

## Export et partage
Quand tu exportes ou partages un parcours (fichier GPX), il va là où tu le décides.

## Sources et licences
Données cartographiques et itinéraires : © OpenStreetMap contributors (licence ODbL). Fond de carte : © OpenFreeMap. Photos : Wikipédia / Wikimedia Commons (licences libres).

## Contact
*(à compléter : adresse e-mail de l'éditeur)*
