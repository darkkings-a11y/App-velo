import 'dart:math' as math;
import 'package:latlong2/latlong.dart';

/// Une ville traversée par le parcours.
class EtapeVille {
  final String nom;
  final LatLng position;
  final double distanceKm; // distance depuis le départ

  const EtapeVille({
    required this.nom,
    required this.position,
    required this.distanceKm,
  });
}

/// Une portion du parcours entre deux villes.
class TronconParcours {
  final String depart;
  final String arrivee;
  final double distanceKm;
  final int denivelePos;
  final int deniveleNeg;

  const TronconParcours({
    required this.depart,
    required this.arrivee,
    required this.distanceKm,
    required this.denivelePos,
    required this.deniveleNeg,
  });
}

class Parcours {
  static const String sourceOfficielle = 'GPX Officiel';
  static const String sourceAuto = 'Généré auto';
  static const String sourceImport = 'Importé';
  static const String sourceOpenData = 'OpenStreetMap';
  static const String sourcePlanifie = 'Planifié';

  // Formes possibles d'un tracé
  static const String formeBoucle = 'boucle';
  static const String formeAllerRetour = 'aller_retour';
  static const String formeLineaire = 'lineaire';

  static String libelleForme(String forme) {
    switch (forme) {
      case formeBoucle:
        return 'Boucle';
      case formeAllerRetour:
        return 'Aller-retour';
      default:
        return 'Point à point';
    }
  }

  final String titre;
  final String distance;
  final String duree;
  final String difficulte;
  final String ville;
  final String denivele; // ex: "450 m D+"
  final List<LatLng> traceGPS;

  // Données détaillées (optionnelles pour rester compatible)
  final List<double> altitudes; // une altitude par point de traceGPS
  final List<double> distancesKm; // distance cumulée (km) par point
  final double distanceKm;
  final int denivelePos;
  final int deniveleNeg;
  final List<EtapeVille> etapes;
  final List<TronconParcours> troncons;

  // Provenance et popularité
  final String source; // sourceOfficielle, sourceAuto ou sourceImport
  final bool verifie; // parcours vérifié / recommandé
  final int popularite; // nombre de consultations (sert au tri)
  final String detailSource; // ex. « itinéraire régional » pour un tracé OpenStreetMap

  bool get estRecommande => verifie && source == sourceOfficielle;
  bool get estOpenData => source == sourceOpenData;
  bool get estPlanifie => source == sourcePlanifie;

  /// Forme du tracé, déduite des points : boucle (on revient au départ par un autre chemin),
  /// aller-retour (on revient par le même chemin) ou point à point (l'arrivée est ailleurs).
  String get forme {
    final t = traceGPS;
    if (t.length < 4) return formeLineaire;
    final calc = Distance(roundResult: false);
    final longueurM = (distanceKm > 0 ? distanceKm : 1) * 1000;
    final ecartM = calc.as(LengthUnit.Meter, t.first, t.last);
    if (ecartM > math.max(400.0, longueurM * 0.08)) return formeLineaire;

    // Revient-on par le même chemin ? On compare des points de la 1re moitié à ceux de la 2e.
    final moitie = t.length ~/ 2;
    final pasSeconde = math.max(1, (t.length - moitie) ~/ 400);
    int proches = 0;
    const echantillons = 10;
    for (int k = 1; k <= echantillons; k++) {
      final p = t[(moitie * k) ~/ (echantillons + 1)];
      double mini = double.infinity;
      for (int i = moitie; i < t.length; i += pasSeconde) {
        final d = calc.as(LengthUnit.Meter, p, t[i]);
        if (d < mini) mini = d;
      }
      if (mini < 60) proches++;
    }
    return proches >= 8 ? formeAllerRetour : formeBoucle;
  }

  const Parcours({
    required this.titre,
    required this.distance,
    required this.duree,
    required this.difficulte,
    required this.ville,
    required this.denivele,
    required this.traceGPS,
    this.altitudes = const [],
    this.distancesKm = const [],
    this.distanceKm = 0,
    this.denivelePos = 0,
    this.deniveleNeg = 0,
    this.etapes = const [],
    this.troncons = const [],
    this.source = sourceAuto,
    this.verifie = false,
    this.popularite = 0,
    this.detailSource = '',
  });

  /// Identifiant stable pour retrouver un parcours dans les favoris.
  String get id =>
      '${titre}_${distanceKm.toStringAsFixed(2)}_${traceGPS.isNotEmpty ? traceGPS.first.latitude.toStringAsFixed(4) : ''}';

  Map<String, dynamic> toJson() => {
        'titre': titre,
        'distance': distance,
        'duree': duree,
        'difficulte': difficulte,
        'ville': ville,
        'denivele': denivele,
        'trace': traceGPS
            .map((p) => [
                  double.parse(p.latitude.toStringAsFixed(5)),
                  double.parse(p.longitude.toStringAsFixed(5)),
                ])
            .toList(),
        'altitudes': altitudes.map((a) => double.parse(a.toStringAsFixed(1))).toList(),
        'distancesKm': distancesKm.map((d) => double.parse(d.toStringAsFixed(3))).toList(),
        'distanceKm': distanceKm,
        'denivelePos': denivelePos,
        'deniveleNeg': deniveleNeg,
        'etapes': etapes
            .map((e) => {
                  'nom': e.nom,
                  'lat': e.position.latitude,
                  'lon': e.position.longitude,
                  'km': e.distanceKm,
                })
            .toList(),
        'source': source,
        'verifie': verifie,
        'popularite': popularite,
        'detailSource': detailSource,
        'troncons': troncons
            .map((t) => {
                  'depart': t.depart,
                  'arrivee': t.arrivee,
                  'km': t.distanceKm,
                  'dp': t.denivelePos,
                  'dn': t.deniveleNeg,
                })
            .toList(),
      };

  factory Parcours.fromJson(Map<String, dynamic> j) {
    return Parcours(
      source: (j['source'] as String?) ?? sourceAuto,
      verifie: (j['verifie'] as bool?) ?? false,
      popularite: (j['popularite'] as num?)?.toInt() ?? 0,
      detailSource: (j['detailSource'] as String?) ?? '',
      titre: j['titre'] as String,
      distance: j['distance'] as String,
      duree: j['duree'] as String,
      difficulte: j['difficulte'] as String,
      ville: j['ville'] as String,
      denivele: j['denivele'] as String,
      traceGPS: (j['trace'] as List)
          .map((p) => LatLng((p[0] as num).toDouble(), (p[1] as num).toDouble()))
          .toList(),
      altitudes: (j['altitudes'] as List).map((a) => (a as num).toDouble()).toList(),
      distancesKm: (j['distancesKm'] as List).map((d) => (d as num).toDouble()).toList(),
      distanceKm: (j['distanceKm'] as num).toDouble(),
      denivelePos: (j['denivelePos'] as num).toInt(),
      deniveleNeg: (j['deniveleNeg'] as num).toInt(),
      etapes: (j['etapes'] as List)
          .map((e) => EtapeVille(
                nom: e['nom'] as String,
                position: LatLng((e['lat'] as num).toDouble(), (e['lon'] as num).toDouble()),
                distanceKm: (e['km'] as num).toDouble(),
              ))
          .toList(),
      troncons: (j['troncons'] as List)
          .map((t) => TronconParcours(
                depart: t['depart'] as String,
                arrivee: t['arrivee'] as String,
                distanceKm: (t['km'] as num).toDouble(),
                denivelePos: (t['dp'] as num).toInt(),
                deniveleNeg: (t['dn'] as num).toInt(),
              ))
          .toList(),
    );
  }
}
