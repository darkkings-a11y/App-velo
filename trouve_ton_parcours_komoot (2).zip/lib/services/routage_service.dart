import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;
import 'package:http/http.dart' as http;
import 'package:latlong2/latlong.dart';
import '../models/parcours.dart';
import 'gpx_service.dart';
import 'villes_service.dart';
import 'itineraires_osm_service.dart';

/// Répartition du trajet par type de voie (parts de 0 à 1 de la distance).
class _Stats {
  double chemins = 0; // pistes, sentiers, chemins non revêtus
  double sentiers = 0; // highway=path non revêtu
  double paves = 0; // pavés / sett (inconfortable en vélo de route)
  double grands = 0; // primary / secondary / trunk : routes à circulation
  double moyens = 0; // tertiary
  double secondaires = 0; // secondary + tertiary + unclassified revêtus (vraies routes de route)
  double douces = 0; // pistes cyclables, voies vertes, rues piétonnes, chemins revêtus
  double residentiel = 0; // rues résidentielles, services
  double bitume = 0; // tout ce qui est revêtu ou route (hors chemins)
  double eau = 0; // bords de l'eau (rivière, lac, canal)
  double vert = 0; // forêts et parcs
}

class _Trace {
  final List<LatLng> points;
  final List<double> altitudes;
  final List<double> distancesKm;
  final _Stats stats;

  _Trace(this.points, this.altitudes, this.distancesKm, this.stats);

  double get totalKm => distancesKm.isEmpty ? 0 : distancesKm.last;
}

/// Un point de départ possible pour les boucles.
class _Depart {
  final LatLng point;
  final String? nom;
  final double distKm; // distance depuis la position demandée
  const _Depart(this.point, this.nom, this.distKm);
}

class _Classement {
  final List<Parcours> conformes;
  final List<Parcours> tous; // triés du plus au moins conforme au style
  const _Classement(this.conformes, this.tous);
}

class RoutageService {
  static final Distance _calc = Distance(roundResult: false);
  static final math.Random _rng = math.Random();
  static String? _derniereErreur;

  /// Message à montrer à l'utilisateur si un style n'a pas pu être appliqué entièrement.
  static String? note;
  static final Set<String> _notes = <String>{};

  // Répartition des voies de chaque parcours généré, pour classer les résultats.
  static final Expando<_Stats> _statsParcours = Expando<_Stats>();

  // Profils personnalisés envoyés au serveur BRouter (identifiants gardés en mémoire).
  static final Map<String, String> _idsProfils = <String, String>{};
  static final Map<String, Future<String?>> _envois = <String, Future<String?>>{};

  static const int _nbBoucles = 4; // 3 sont affichées : la 4e sert de secours
  static const int _nbMax = 5;

  /// Génère de vraies boucles (BRouter) autour du point de départ, adaptées au style choisi :
  /// route = routes goudronnées, balade = pistes cyclables / voies calmes, vtt = chemins et sentiers.
  /// En VTT, si la zone n'a pas de chemins, le départ est déplacé vers les chemins les plus proches.
  static Future<List<Parcours>> genererParcours({
    required double latitude,
    required double longitude,
    required int distanceKm,
    required String villeNom,
    String profil = 'balade',
  }) async {
    _derniereErreur = null;
    note = null;
    _notes.clear();

    final origine = LatLng(latitude, longitude);

    // En parallèle : nom de la commune, zones de chemins VTT, envoi du profil de routage.
    final fNom = VillesService.nomCommune(origine);
    final fZones = profil == 'vtt' ? _zonesVtt(origine) : Future<List<_Depart>?>.value(null);
    final premier = _profilsBrouter(profil).first;
    if (premier.startsWith('custom:')) {
      _profilPerso(premier); // préchauffage, sans attendre
    }
    final nomOrigine = (await fNom) ?? villeNom;

    // Points de départ à essayer, dans l'ordre.
    List<_Depart> departs = [_Depart(origine, nomOrigine, 0)];
    if (profil == 'vtt') {
      final zones = await fZones;
      if (zones != null && zones.isNotEmpty) {
        departs = zones.first.distKm <= 3.0
            ? [_Depart(origine, nomOrigine, 0), ...zones.skip(1)]
            : zones;
      }
    }

    List<Parcours> retenus = [];
    _Depart? departRetenu;
    _Classement? meilleur;
    for (final d in departs.take(3)) {
      final nomDepart = d.nom ?? (await VillesService.nomCommune(d.point)) ?? nomOrigine;
      final liste = await _genererDepuis(
        depart: d.point,
        nomDepart: nomDepart,
        distanceKm: distanceKm,
        profil: profil,
      );
      if (liste.isEmpty) continue;
      final cl = _classer(profil, liste);
      if (meilleur == null || _meilleurQue(profil, cl, meilleur)) {
        meilleur = cl;
        departRetenu = _Depart(d.point, nomDepart, d.distKm);
      }
      // Assez de parcours conformes : on s'arrête là.
      if (cl.conformes.length >= (profil == 'vtt' ? 2 : 3)) break;
    }

    if (meilleur == null) {
      throw 'Aucun parcours calculé. ${_derniereErreur ?? ''}';
    }

    // Les parcours conformes au style d'abord, puis les autres.
    retenus = [
      ...meilleur.conformes,
      ...meilleur.tous.where((p) => !meilleur!.conformes.contains(p)),
    ].take(_nbMax).toList();

    if (profil == 'vtt' && departRetenu != null) {
      if (departRetenu.distKm > 3.0) {
        _notes.add(
            'Peu de chemins VTT autour de $nomOrigine : les parcours partent de ${departRetenu.nom}, '
            'à ${departRetenu.distKm.round()} km, là où il y a des sentiers.');
      }
      if (meilleur.conformes.isEmpty) {
        _notes.add('Peu de chemins trouvés dans la région : parcours VTT sur les pistes les plus proches.');
      }
    }
    note = _notes.isEmpty ? null : _notes.join('\n');
    return retenus;
  }

  static Future<List<Parcours>> _genererDepuis({
    required LatLng depart,
    required String nomDepart,
    required int distanceKm,
    required String profil,
  }) async {
    final base = _rng.nextInt(360);
    final pas = 360 / _nbBoucles;

    // On n'attend pas les plus lentes : dès que 3 boucles sont prêtes, on continue.
    final fini = Completer<void>();
    final res = <Parcours>[];
    int restants = _nbBoucles;
    void termine(Parcours? p) {
      if (p != null) res.add(p);
      restants--;
      if ((res.length >= 3 || restants == 0) && !fini.isCompleted) fini.complete();
    }

    for (int i = 0; i < _nbBoucles; i++) {
      _construireParcours(
        depart: depart,
        nomDepart: nomDepart,
        distanceKm: distanceKm,
        profil: profil,
        cap: ((base + i * pas) % 360).toDouble(),
      ).then(termine).catchError((_) {
        termine(null);
      });
    }
    await fini.future.timeout(const Duration(seconds: 40), onTimeout: () {});
    return List<Parcours>.of(res);
  }

  // ---------------------------------------------------------------------------
  // Classement selon le style
  // ---------------------------------------------------------------------------

  static double _pente(Parcours p) => p.distanceKm > 0 ? p.denivelePos / p.distanceKm : 0.0;

  /// Note de conformité au style (plus c'est haut, mieux c'est).
  static double _score(String profil, Parcours p) {
    final s = _statsParcours[p] ?? _Stats();
    final pente = _pente(p);
    switch (profil) {
      case 'route':
        // Vraie route : routes départementales revêtues, pas de chemins ni de pavés.
        return 100 * s.secondaires + 20 * s.grands - 300 * s.chemins - 200 * s.paves - 40 * s.douces + 0.5 * pente;
      case 'vtt':
        // Chemins et sentiers en forêt, aucun bitume, du dénivelé (montées et descentes).
        return 100 * s.chemins + 40 * s.sentiers + 30 * s.vert - 200 * s.bitume - 300 * (s.grands + s.moyens) + 1.5 * math.min(pente, 30.0);
      default:
        // Balade : pistes cyclables, parcs, bords de l'eau, petites rues ; pas de circulation ; plat.
        return 100 * s.douces + 60 * s.eau + 40 * s.vert + 20 * s.residentiel - 250 * s.grands - 120 * s.moyens - 80 * s.chemins - 1.0 * pente;
    }
  }

  static bool _conforme(String profil, Parcours p) {
    final s = _statsParcours[p];
    if (s == null) return true; // pas de détail : on ne peut pas juger
    switch (profil) {
      case 'route':
        return s.chemins <= 0.08 && s.paves <= 0.08;
      case 'vtt':
        // Un vrai parcours VTT : surtout des chemins, très peu de bitume.
        return s.chemins >= 0.6 && s.bitume <= 0.3 && s.grands + s.moyens <= 0.05;
      default:
        // Une vraie balade : pas de route, surtout des pistes cyclables / voies vertes / parcs.
        return s.grands + s.moyens <= 0.08 && s.chemins <= 0.25 && s.douces >= 0.3;
    }
  }

  static _Classement _classer(String profil, List<Parcours> liste) {
    final tous = [...liste]..sort((a, b) => _score(profil, b).compareTo(_score(profil, a)));
    final conformes = tous.where((p) => _conforme(profil, p)).toList();
    return _Classement(conformes, tous);
  }

  static bool _meilleurQue(String profil, _Classement a, _Classement b) {
    if (a.conformes.length != b.conformes.length) return a.conformes.length > b.conformes.length;
    return _score(profil, a.tous.first) > _score(profil, b.tous.first);
  }

  // ---------------------------------------------------------------------------
  // VTT : trouver les chemins les plus proches (OpenStreetMap via Overpass)
  // ---------------------------------------------------------------------------

  /// Zones de chemins VTT autour de [o], de la plus proche à la plus lointaine.
  /// Null si le service OpenStreetMap n'a pas répondu (on reste alors sur le point demandé).
  static Future<List<_Depart>?> _zonesVtt(LatLng o) async {
    const rayonsKm = [8, 22, 50];
    List<_Depart> trouvees = <_Depart>[];
    for (int k = 0; k < rayonsKm.length; k++) {
      final r = rayonsKm[k] * 1000;
      // Chemins et forêts demandés en même temps.
      final res = await Future.wait([_cheminsAutour(o, r), _forets(o, r)]);
      final pts = res[0];
      if (pts == null) return trouvees.isEmpty ? null : trouvees;
      final zones = _regrouperZones(o, pts, res[1] ?? const []);
      if (zones.isNotEmpty) {
        trouvees = zones;
        if (zones.length >= 2 || k == rayonsKm.length - 1) return trouvees;
      } else if (trouvees.isNotEmpty) {
        return trouvees;
      }
    }
    return trouvees;
  }

  /// Centres des forêts et bois dans le rayon donné (sert à préférer les zones boisées).
  static Future<List<LatLng>?> _forets(LatLng o, int rayonM) async {
    final requete = '[out:json][timeout:25];('
        'way(around:$rayonM,${o.latitude.toStringAsFixed(5)},${o.longitude.toStringAsFixed(5)})["landuse"="forest"];'
        'way(around:$rayonM,${o.latitude.toStringAsFixed(5)},${o.longitude.toStringAsFixed(5)})["natural"="wood"];'
        ');out center 1500;';
    return _requeteCentres(requete);
  }

  /// Centres des chemins non revêtus autorisés aux vélos dans le rayon donné.
  static Future<List<LatLng>?> _cheminsAutour(LatLng o, int rayonM) async {
    final requete = '[out:json][timeout:25];'
        'way(around:$rayonM,${o.latitude.toStringAsFixed(5)},${o.longitude.toStringAsFixed(5)})'
        '["highway"~"^(track|path|bridleway)\$"]'
        '["access"!~"^(private|no)\$"]'
        '["bicycle"!~"^(no|dismount|private)\$"]'
        '["surface"!~"^(asphalt|paved|concrete|paving_stones|sett|cobblestone)\$"];'
        'out center 2000;';
    return _requeteCentres(requete);
  }

  static Future<List<LatLng>?> _requeteCentres(String requete) async {
    // Serveurs interrogés en course (le plus rapide gagne), comme pour les itinéraires balisés.
    final data = await ItinerairesOsmService.overpass(requete);
    if (data == null) return null;
    final pts = <LatLng>[];
    for (final e in (data['elements'] as List? ?? const [])) {
      final c = e is Map ? e['center'] : null;
      if (c is Map && c['lat'] is num && c['lon'] is num) {
        pts.add(LatLng((c['lat'] as num).toDouble(), (c['lon'] as num).toDouble()));
      }
    }
    return pts;
  }

  /// Regroupe les chemins en cellules d'environ 2 km et garde les zones assez riches,
  /// de la plus proche à la plus lointaine (3 zones espacées d'au moins 5 km).
  static List<_Depart> _regrouperZones(LatLng o, List<LatLng> pts, List<LatLng> forets) {
    const pasDeg = 0.02;
    final pasLon = pasDeg / math.max(0.2, math.cos(o.latitude * math.pi / 180));
    final cellules = <String, List<LatLng>>{};
    String cle(int i, int j) => '$i/$j';
    for (final p in pts) {
      final i = (p.latitude / pasDeg).floor();
      final j = (p.longitude / pasLon).floor();
      cellules.putIfAbsent(cle(i, j), () => []).add(p);
    }

    final cellulesForet = <String, int>{};
    for (final p in forets) {
      final k = cle((p.latitude / pasDeg).floor(), (p.longitude / pasLon).floor());
      cellulesForet[k] = (cellulesForet[k] ?? 0) + 1;
    }

    final zones = <_Depart>[];
    final bonusForet = <_Depart, bool>{};
    for (final entree in cellules.entries) {
      final parts = entree.key.split('/');
      final i = int.parse(parts[0]);
      final j = int.parse(parts[1]);
      // Voisinage 3x3 : il faut un vrai réseau de chemins, pas deux sentiers isolés.
      final voisins = <LatLng>[];
      for (int di = -1; di <= 1; di++) {
        for (int dj = -1; dj <= 1; dj++) {
          voisins.addAll(cellules[cle(i + di, j + dj)] ?? const []);
        }
      }
      if (voisins.length < 40) continue;
      // Départ : le chemin le plus central du réseau (pour pouvoir partir dans toutes les directions).
      final lat = voisins.map((p) => p.latitude).reduce((a, b) => a + b) / voisins.length;
      final lon = voisins.map((p) => p.longitude).reduce((a, b) => a + b) / voisins.length;
      final centre = LatLng(lat, lon);
      LatLng? meilleur;
      double dMin = double.infinity;
      for (final p in voisins) {
        final d = _calc.as(LengthUnit.Kilometer, centre, p);
        if (d < dMin) {
          dMin = d;
          meilleur = p;
        }
      }
      if (meilleur == null) continue;
      int foret = 0;
      for (int di = -1; di <= 1; di++) {
        for (int dj = -1; dj <= 1; dj++) {
          foret += cellulesForet[cle(i + di, j + dj)] ?? 0;
        }
      }
      final z = _Depart(meilleur, null, _calc.as(LengthUnit.Kilometer, o, meilleur));
      zones.add(z);
      bonusForet[z] = foret >= 3;
    }

    // Les zones boisées passent devant : on les rapproche de 5 km pour le classement.
    double rang(_Depart z) => z.distKm - (bonusForet[z] == true ? 5 : 0);
    zones.sort((a, b) => rang(a).compareTo(rang(b)));
    final retenues = <_Depart>[];
    for (final z in zones) {
      final tropProche = retenues.any((r) => _calc.as(LengthUnit.Kilometer, r.point, z.point) < 5);
      if (!tropProche) retenues.add(z);
      if (retenues.length >= 3) break;
    }
    return retenues;
  }

  // ---------------------------------------------------------------------------
  // Construction d'un parcours
  // ---------------------------------------------------------------------------

  static Future<Parcours?> _construireParcours({
    required LatLng depart,
    required String nomDepart,
    required int distanceKm,
    required String profil,
    required double cap,
  }) async {
    try {
      double facteur = 1.35;
      _Trace? meilleure;

      // On ajuste la taille de la boucle pour approcher la distance demandée.
      for (int essai = 0; essai < 2; essai++) {
        final waypoints = _pointsDeBoucle(depart, distanceKm.toDouble(), cap, facteur);
        final trace = await _calculerTrace(waypoints, _profilsBrouter(profil));
        if (meilleure == null ||
            (trace.totalKm - distanceKm).abs() < (meilleure.totalKm - distanceKm).abs()) {
          meilleure = trace;
        }
        final ratio = trace.totalKm / distanceKm;
        if ((ratio - 1).abs() < 0.12) break;
        facteur = facteur * ratio;
      }

      final trace = meilleure!;
      final n = trace.points.length;
      if (n < 2) return null;

      final altLisse = _lisser(trace.altitudes, 5);

      // Villes traversées : on échantillonne 6 points le long du tracé.
      final indices = <int>[];
      for (int k = 1; k <= 4; k++) {
        final cible = trace.totalKm * k / 5;
        final idx = trace.distancesKm.indexWhere((d) => d >= cible);
        if (idx > 0 && idx < n - 1) indices.add(idx);
      }
      final noms = await Future.wait(
        indices.map((i) => VillesService.nomCommune(trace.points[i]).timeout(const Duration(seconds: 4), onTimeout: () => null)),
      );

      final etapes = <EtapeVille>[];
      final idxEtapes = <int>[];
      String precedent = nomDepart;
      for (int j = 0; j < indices.length; j++) {
        final nom = noms[j];
        if (nom == null || nom == nomDepart || nom == precedent) continue;
        etapes.add(EtapeVille(
          nom: nom,
          position: trace.points[indices[j]],
          distanceKm: trace.distancesKm[indices[j]],
        ));
        idxEtapes.add(indices[j]);
        precedent = nom;
      }

      // Tronçons entre chaque ville
      final bornes = <int>[0, ...idxEtapes, n - 1];
      final nomsBornes = <String>[nomDepart, ...etapes.map((e) => e.nom), nomDepart];
      final troncons = <TronconParcours>[];
      int totalPos = 0;
      int totalNeg = 0;
      for (int t = 0; t < bornes.length - 1; t++) {
        final dn = _denivele(altLisse, bornes[t], bornes[t + 1]);
        totalPos += dn[0];
        totalNeg += dn[1];
        troncons.add(TronconParcours(
          depart: nomsBornes[t],
          arrivee: nomsBornes[t + 1],
          distanceKm: trace.distancesKm[bornes[t + 1]] - trace.distancesKm[bornes[t]],
          denivelePos: dn[0],
          deniveleNeg: dn[1],
        ));
      }

      final km = trace.totalKm;

      // Titre : Lyon – Caluire – Neuville – Lyon
      final nomsEtapes = etapes.map((e) => e.nom).toList();
      final choisis = nomsEtapes.length <= 3
          ? nomsEtapes
          : [nomsEtapes.first, nomsEtapes[nomsEtapes.length ~/ 2], nomsEtapes.last];
      final titre = choisis.isEmpty
          ? 'Boucle de $nomDepart'
          : [nomDepart, ...choisis, nomDepart].join(' – ');

      final vitesse = profil == 'route' ? 22.0 : (profil == 'vtt' ? 13.0 : 16.0);
      final heures = km / vitesse + totalPos / 600.0;
      final h = heures.floor();
      final m = ((heures - h) * 60).round();
      final duree = '${h}h${m.toString().padLeft(2, '0')}';

      final ratioDenivele = km > 0 ? totalPos / km : 0;
      final difficulte = ratioDenivele < 8 ? 'Facile' : (ratioDenivele < 16 ? 'Modéré' : 'Sportif');

      final resultat = Parcours(
        titre: titre,
        distance: '${km.toStringAsFixed(1)} km',
        duree: duree,
        difficulte: difficulte,
        ville: nomDepart,
        denivele: '$totalPos m D+',
        traceGPS: trace.points,
        altitudes: altLisse,
        distancesKm: trace.distancesKm,
        distanceKm: km,
        denivelePos: totalPos,
        deniveleNeg: totalNeg,
        etapes: etapes,
        troncons: troncons,
      );
      _statsParcours[resultat] = trace.stats;
      return resultat;
    } catch (e) {
      _derniereErreur = e.toString();
      return null;
    }
  }

  /// Itinéraire à vélo qui passe par tous les points donnés (pour le planificateur). Null si échec.
  static Future<({List<LatLng> points, List<double> altitudes})?> itineraireEntre(
    List<LatLng> pts,
    String profil,
  ) async {
    if (pts.length < 2) return null;
    try {
      final t = await _calculerTrace(pts, _profilsBrouter(profil));
      if (t.points.length < 2) return null;
      return (points: t.points, altitudes: t.altitudes);
    } catch (_) {
      return null;
    }
  }

  /// Parcours « aller-retour » (on repart par le même chemin) ou « point à point » (l'arrivée est ailleurs),
  /// autour du départ, dans 4 directions différentes. [forme] : Parcours.formeAllerRetour ou Parcours.formeLineaire.
  static Future<List<Parcours>> genererOuverts({
    required double latitude,
    required double longitude,
    required int distanceKm,
    required String villeNom,
    required String forme,
    String profil = 'balade',
  }) async {
    _derniereErreur = null;
    _notes.clear();
    final depart = LatLng(latitude, longitude);
    final nomDepart = (await VillesService.nomCommune(depart)) ?? villeNom;
    final aller = forme == Parcours.formeAllerRetour;
    final base = _rng.nextInt(360);

    final res = <Parcours>[];
    final futurs = <Future<void>>[];
    for (int i = 0; i < 4; i++) {
      final cap = ((base + i * 90) % 360).toDouble();
      futurs.add(() async {
        try {
          // Longueur à vol d'oiseau : la route fait environ 1,3 fois plus.
          double vol = distanceKm * 1000 / (aller ? 2 : 1) / 1.3;
          _Trace? meilleure;
          LatLng arrivee = _calc.offset(depart, vol, cap);
          for (int essai = 0; essai < 2; essai++) {
            arrivee = _calc.offset(depart, vol, cap);
            final t = await _calculerTrace([depart, arrivee], _profilsBrouter(profil));
            final km = aller ? t.totalKm * 2 : t.totalKm;
            if (meilleure == null || (km - distanceKm).abs() < ((aller ? meilleure.totalKm * 2 : meilleure.totalKm) - distanceKm).abs()) {
              meilleure = t;
            }
            final ratio = km / distanceKm;
            if ((ratio - 1).abs() < 0.12) break;
            vol = vol / ratio;
          }
          final t = meilleure!;
          var points = List<LatLng>.of(t.points);
          var alts = List<double?>.of(t.altitudes);
          if (aller) {
            points = [...points, ...t.points.reversed.skip(1)];
            alts = [...alts, ...t.altitudes.reversed.skip(1)];
          }
          final nomArrivee = (await VillesService.nomCommune(t.points.last)) ?? 'arrivée';
          final titre = aller
              ? 'Aller-retour $nomDepart – $nomArrivee'
              : 'De $nomDepart à $nomArrivee';
          final p = await GpxService.depuisPoints(
            points,
            alts,
            nom: titre,
            source: Parcours.sourceAuto,
            avecVilles: true,
            villeParDefaut: nomDepart,
          );
          res.add(p);
        } catch (e) {
          _derniereErreur = e.toString();
        }
      }());
    }
    await Future.wait(futurs).timeout(const Duration(seconds: 45), onTimeout: () => <void>[]);
    if (res.isEmpty) {
      throw 'Aucun parcours calculé. ${_derniereErreur ?? ''}';
    }
    note = _notes.isEmpty ? null : _notes.join('\n');
    return res.take(3).toList();
  }

  /// Itinéraire à vélo pour rejoindre un point (ex. le tracé du parcours). Null si échec.
  static Future<List<LatLng>?> itineraireVers(LatLng depuis, LatLng vers) async {
    try {
      final t = await _calculerTrace([depuis, vers], ['trekking']);
      return t.points.length >= 2 ? t.points : null;
    } catch (_) {
      return null;
    }
  }

  /// Départ + 4 points répartis sur un cercle passant par le départ + retour au départ.
  static List<LatLng> _pointsDeBoucle(LatLng depart, double distanceKm, double cap, double facteur) {
    final diametre = distanceKm * 1000 / (math.pi * facteur);
    final centre = _calc.offset(depart, diametre / 2, cap);
    final capDepuisCentre = (cap + 180) % 360;
    final pts = <LatLng>[depart];
    for (int k = 1; k <= 4; k++) {
      pts.add(_calc.offset(centre, diametre / 2, (capDepuisCentre + 72.0 * k) % 360));
    }
    pts.add(depart);
    return pts;
  }

  static List<String> _profilsBrouter(String profil) {
    switch (profil) {
      case 'route':
        // Route : profil sur mesure (routes revêtues, peu de circulation, pas de chemins ni de pavés)
        return ['custom:route', 'fastbike', 'trekking'];
      case 'vtt':
        // VTT : profil sur mesure qui favorise pistes et sentiers
        return ['custom:vtt', 'mtb', 'trekking'];
      default:
        // Balade : profil sur mesure (pistes cyclables, voies vertes, rues calmes)
        return ['custom:balade', 'safety', 'trekking'];
    }
  }

  static const Map<String, String> _nomsStyles = {
    'custom:route': 'route',
    'custom:vtt': 'VTT',
    'custom:balade': 'balade',
  };

  static Future<_Trace> _calculerTrace(List<LatLng> pts, List<String> profils) async {
    Object? derniere;
    for (final nom in profils) {
      String p = nom;
      try {
        if (nom.startsWith('custom:')) {
          final id = await _profilPerso(nom);
          if (id == null) {
            _notes.add('Le profil ${_nomsStyles[nom]} n\'a pas pu être chargé : parcours calculés avec un profil standard.');
            continue;
          }
          p = id;
        }
        final lonlats = pts
            .map((q) => '${q.longitude.toStringAsFixed(6)},${q.latitude.toStringAsFixed(6)}')
            .join('|');
        final uri = Uri.https('brouter.de', '/brouter', {
          'lonlats': lonlats,
          'profile': p,
          'alternativeidx': '0',
          'format': 'geojson',
        });
        final r = await http
            .get(uri, headers: {'User-Agent': 'AppVeloMobile/1.0'})
            .timeout(const Duration(seconds: 40));
        if (r.statusCode != 200) {
          final corps = r.body.length > 120 ? r.body.substring(0, 120) : r.body;
          throw 'BRouter (${r.statusCode}) : $corps';
        }
        return _lireGeoJson(r.body);
      } catch (e) {
        derniere = e;
        if (nom.startsWith('custom:')) {
          _idsProfils.remove(nom); // le serveur l'a peut-être oublié : on le renverra
          _notes.add('Le profil ${_nomsStyles[nom]} n\'a pas pu être appliqué : parcours calculés avec un profil standard.');
        }
      }
    }
    throw derniere ?? 'Erreur de routage';
  }

  /// Envoie un de nos profils au serveur BRouter et garde son identifiant.
  static Future<String?> _profilPerso(String cle) async {
    final connu = _idsProfils[cle];
    if (connu != null) return connu;
    // Les boucles sont calculées en parallèle : un seul envoi pour toutes.
    final f = _envois[cle] ??= _envoyerProfil(cle);
    try {
      return await f;
    } finally {
      _envois.remove(cle);
    }
  }

  static Future<String?> _envoyerProfil(String cle) async {
    final texte = cle == 'custom:route'
        ? _texteProfilRoute
        : (cle == 'custom:vtt' ? _texteProfilVtt : _texteProfilBalade);
    try {
      final r = await http
          .post(
            Uri.https('brouter.de', '/brouter/profile'),
            headers: {'User-Agent': 'AppVeloMobile/1.0', 'Content-Type': 'text/plain'},
            body: texte,
          )
          .timeout(const Duration(seconds: 20));
      if (r.statusCode != 200) return null;
      final data = json.decode(r.body);
      final id = data is Map ? data['profileid'] : null;
      if (id is String && id.isNotEmpty) {
        _idsProfils[cle] = id;
        return id;
      }
    } catch (_) {}
    return null;
  }

  // Profil BRouter « Route » : routes revêtues (départementales), circulation évitée sur les axes
  // principaux, chemins / pavés / sentiers très pénalisés.
  static const String _texteProfilRoute = r'''
---context:global

assign validForBikes = 1
assign downhillcost = 0
assign downhillcutoff = 1.5
assign uphillcost = 0
assign uphillcutoff = 1.5

---context:way

assign turncost = 70
assign initialclassifier = 0

assign ispaved surface=asphalt|paved|concrete|paving_stones
assign isrough surface=cobblestone|sett|unpaved|gravel|ground|dirt|grass|compacted|fine_gravel|sand|mud|earth|pebblestone|clay|wood

assign badoneway =
  if reversedirection=yes then
    if oneway:bicycle=yes then true
    else if oneway= then junction=roundabout
    else oneway=yes|true|1
  else oneway=-1

assign onewaypenalty =
  if badoneway then ( if or oneway:bicycle=no cycleway=opposite|opposite_lane|opposite_track then 0 else 30 )
  else 0

assign interdit =
  or access=private|no
  or bicycle=no|private|dismount|use_sidepath
  or highway=
  highway=motorway|motorway_link|trunk|trunk_link|construction|proposed|abandoned|steps|bridleway

assign basecost =
  switch interdit 10000
  switch isrough
    switch highway=primary|primary_link|secondary|secondary_link|tertiary|tertiary_link|unclassified|residential 8
    14
  switch highway=primary|primary_link 2.6
  switch highway=secondary|secondary_link 1.3
  switch highway=tertiary|tertiary_link 1.1
  switch highway=unclassified 1.15
  switch highway=residential 1.6
  switch highway=living_street|service 3
  switch highway=cycleway 1.6
  switch highway=track|path
    switch ispaved 3
    switch tracktype=grade1 6
    14
  switch highway=footway|pedestrian 12
  4

assign costfactor = add onewaypenalty basecost

---context:node

assign initialcost = 0
''';

  // Profil BRouter « Balade » : pistes cyclables, voies vertes, parcs, bords de l'eau ;
  // routes à circulation très pénalisées ; on évite les côtes.
  static const String _texteProfilBalade = r'''
---context:global

assign validForBikes = 1
assign downhillcost = 0
assign downhillcutoff = 1.5
assign uphillcost = 90
assign uphillcutoff = 1.5

---context:way

assign turncost = 40
assign initialclassifier = 0

assign ispaved surface=asphalt|paved|concrete|paving_stones
assign isgood surface=compacted|gravel|fine_gravel
assign isbadsurface surface=mud|sand|ground|grass|earth|clay|dirt|pebblestone|cobblestone|sett|wood|unpaved

assign badoneway =
  if reversedirection=yes then
    if oneway:bicycle=yes then true
    else if oneway= then junction=roundabout
    else oneway=yes|true|1
  else oneway=-1

assign onewaypenalty =
  if badoneway then ( if or oneway:bicycle=no cycleway=opposite|opposite_lane|opposite_track then 0 else 30 )
  else 0

assign interdit =
  or access=private|no
  or bicycle=no|private|dismount|use_sidepath
  or highway=
  highway=motorway|motorway_link|trunk|trunk_link|construction|proposed|abandoned|steps

# bords de l'eau : bonus
assign riverpen =
  switch estimated_river_class=1 0.8
  switch estimated_river_class=2 0.6
  switch estimated_river_class=3 0.45
  switch estimated_river_class=4 0.3
  switch estimated_river_class=5 0.15
  switch estimated_river_class=6 0
  1.0

# parcs et forêts : bonus
assign forestpen =
  switch estimated_forest_class=1 0.5
  switch estimated_forest_class=2 0.4
  switch estimated_forest_class=3 0.3
  switch estimated_forest_class=4 0.2
  switch estimated_forest_class=5 0.1
  switch estimated_forest_class=6 0
  0.6

assign amenage or route_bicycle_lcn=yes or route_bicycle_rcn=yes or route_bicycle_ncn=yes or route_bicycle_icn=yes bicycle=designated

assign basecost =
  switch interdit 10000
  switch highway=primary|primary_link 60
  switch highway=secondary|secondary_link 20
  switch highway=tertiary|tertiary_link 6
  switch highway=cycleway
    switch isbadsurface 2.2 1.0
  switch highway=track|path|bridleway|footway|pedestrian
    switch highway=footway|pedestrian
      switch bicycle=yes|designated 1.3 8
    switch mtb:scale=3|4|5|6 15
    switch ispaved 1.1
    switch isgood 1.5
    switch isbadsurface 5
    switch tracktype=grade1 1.5
    switch tracktype=grade2 2.0
    2.2
  switch highway=living_street 1.2
  switch highway=residential 2.2
  switch highway=unclassified 2.8
  switch highway=service 3.0
  5

assign costfactor = add onewaypenalty add riverpen add forestpen max 1 multiply basecost switch amenage 0.85 1

---context:node

assign initialcost = 0
''';

  // Profil BRouter « VTT » : chemins, pistes et sentiers en forêt ; bitume quasi interdit (routes, pistes cyclables
  // goudronnées) ; forêts favorisées, villes évitées.
  static const String _texteProfilVtt = r'''
---context:global

assign validForBikes = 1
assign downhillcost = 0
assign downhillcutoff = 1.5
assign uphillcost = 0
assign uphillcutoff = 1.5

---context:way

assign turncost = 30
assign initialclassifier = 0

assign ispaved surface=asphalt|paved|concrete|paving_stones|sett|cobblestone

assign interdit =
  or access=private|no
  or bicycle=no|private|dismount|use_sidepath
  or highway=
  highway=motorway|motorway_link|trunk|trunk_link|construction|proposed|abandoned

# forêts : bonus ; villes : malus
assign forestpen =
  switch estimated_forest_class=1 0.5
  switch estimated_forest_class=2 0.4
  switch estimated_forest_class=3 0.3
  switch estimated_forest_class=4 0.2
  switch estimated_forest_class=5 0.1
  switch estimated_forest_class=6 0
  0.6

assign townpen =
  switch estimated_town_class=2 0.2
  switch estimated_town_class=3 0.4
  switch estimated_town_class=4 0.6
  switch estimated_town_class=5 0.8
  switch estimated_town_class=6 1.0
  0

# le bitume est quasi interdit : seuls les chemins comptent
assign basecost =
  switch interdit 10000
  switch highway=steps 25
  switch highway=primary|primary_link 200
  switch highway=secondary|secondary_link 80
  switch highway=tertiary|tertiary_link 30
  switch highway=residential|unclassified|living_street 14
  switch highway=cycleway 9
  switch highway=footway|pedestrian 6
  switch highway=service
    switch ispaved 12 5
  switch highway=track|bridleway
    switch ispaved 9
    switch tracktype=grade1 4
    switch tracktype=grade2|grade3|grade4|grade5 1.2
    1.4
  switch highway=path
    switch mtb:scale=4|5|6 14
    switch ispaved 9
    switch mtb:scale=3 3.5
    switch mtb:scale=2 1.6
    1.1
  12

assign costfactor = add forestpen add townpen basecost

---context:node

assign initialcost = 0
''';

  /// Répartition du trajet par type de voie, d'après les étiquettes OSM renvoyées par BRouter.
  static _Stats _calculerStats(dynamic messages) {
    final s = _Stats();
    try {
      if (messages is! List || messages.length < 2) return s;
      final entete = (messages.first as List).map((e) => e.toString()).toList();
      final iDist = entete.indexOf('Distance');
      final iTags = entete.indexOf('WayTags');
      if (iDist < 0 || iTags < 0) return s;
      final reRevetu = RegExp(r'surface=(asphalt|paved|concrete|paving_stones)');
      final rePaves = RegExp(r'surface=(cobblestone|sett)');
      final reNonRevetu = RegExp(
          r'surface=(unpaved|gravel|fine_gravel|dirt|ground|compacted|grass|earth|mud|sand|pebblestone|clay)');
      final reHighway = RegExp(r'highway=([a-z_]+)');
      final reRiviere = RegExp(r'estimated_river_class=(\d)');
      final reForet = RegExp(r'estimated_forest_class=(\d)');
      double total = 0;
      for (int i = 1; i < messages.length; i++) {
        final l = messages[i] as List;
        final d = double.tryParse(l[iDist].toString()) ?? 0;
        final t = l[iTags].toString();
        final hw = reHighway.firstMatch(t)?.group(1) ?? '';
        final revetu = reRevetu.hasMatch(t);
        final nonRevetu = reNonRevetu.hasMatch(t) && !revetu;
        final piste = {'track', 'path', 'bridleway'}.contains(hw);
        total += d;
        if ((piste && !revetu) || nonRevetu) s.chemins += d;
        if (hw == 'path' && !revetu) s.sentiers += d;
        if (rePaves.hasMatch(t)) s.paves += d;
        if (const {'primary', 'primary_link', 'secondary', 'secondary_link', 'trunk', 'trunk_link'}.contains(hw)) {
          s.grands += d;
        }
        if (hw == 'tertiary' || hw == 'tertiary_link') s.moyens += d;
        if (const {'secondary', 'secondary_link', 'tertiary', 'tertiary_link', 'unclassified'}.contains(hw) &&
            !nonRevetu) {
          s.secondaires += d;
        }
        if (const {'cycleway', 'living_street', 'pedestrian', 'footway'}.contains(hw) ||
            (piste && (revetu || RegExp(r'surface=(compacted|gravel|fine_gravel)').hasMatch(t)))) {
          s.douces += d;
        }
        if (hw == 'residential' || hw == 'service') s.residentiel += d;
        if (!nonRevetu &&
            (revetu ||
                const {
                  'primary', 'primary_link', 'secondary', 'secondary_link', 'tertiary', 'tertiary_link',
                  'trunk', 'trunk_link', 'unclassified', 'residential', 'living_street', 'service', 'cycleway'
                }.contains(hw))) {
          s.bitume += d;
        }
        final cr = int.tryParse(reRiviere.firstMatch(t)?.group(1) ?? '') ?? 0;
        final cf = int.tryParse(reForet.firstMatch(t)?.group(1) ?? '') ?? 0;
        if (cr >= 4) s.eau += d;
        if (cf >= 4) s.vert += d;
      }
      if (total > 0) {
        s.chemins /= total;
        s.sentiers /= total;
        s.paves /= total;
        s.grands /= total;
        s.moyens /= total;
        s.secondaires /= total;
        s.douces /= total;
        s.residentiel /= total;
        s.bitume /= total;
        s.eau /= total;
        s.vert /= total;
      }
    } catch (_) {}
    return s;
  }

  static _Trace _lireGeoJson(String corps) {
    final data = json.decode(corps) as Map<String, dynamic>;
    final features = data['features'] as List;
    if (features.isEmpty) throw 'Réponse BRouter vide';
    final coords = features.first['geometry']['coordinates'] as List;

    final points = <LatLng>[];
    final alt = <double>[];
    for (final c in coords) {
      final l = c as List;
      points.add(LatLng((l[1] as num).toDouble(), (l[0] as num).toDouble()));
      alt.add(l.length > 2 ? (l[2] as num).toDouble() : 0.0);
    }

    final cum = <double>[0.0];
    for (int i = 1; i < points.length; i++) {
      cum.add(cum.last + _calc.as(LengthUnit.Meter, points[i - 1], points[i]) / 1000);
    }
    final props = features.first['properties'];
    final stats = _calculerStats(props is Map ? props['messages'] : null);
    return _Trace(points, alt, cum, stats);
  }

  /// Moyenne mobile pour enlever le bruit de l'altitude.
  static List<double> _lisser(List<double> v, int fenetre) {
    final moitie = fenetre ~/ 2;
    final res = <double>[];
    for (int i = 0; i < v.length; i++) {
      final debut = math.max(0, i - moitie);
      final fin = math.min(v.length - 1, i + moitie);
      double somme = 0;
      for (int j = debut; j <= fin; j++) {
        somme += v[j];
      }
      res.add(somme / (fin - debut + 1));
    }
    return res;
  }

  /// Retourne [D+, D-] entre deux indices (variations < 3 m ignorées).
  static List<int> _denivele(List<double> alt, int debut, int fin) {
    double ref = alt[debut];
    double pos = 0;
    double neg = 0;
    for (int i = debut + 1; i <= fin; i++) {
      final diff = alt[i] - ref;
      if (diff >= 3) {
        pos += diff;
        ref = alt[i];
      } else if (diff <= -3) {
        neg += -diff;
        ref = alt[i];
      }
    }
    return [pos.round(), neg.round()];
  }
}
