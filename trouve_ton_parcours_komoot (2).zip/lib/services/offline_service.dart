import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:maplibre_gl/maplibre_gl.dart' as ml;
import '../models/parcours.dart';

/// Carte hors ligne : télécharge le fond de carte autour d'un parcours, pour le suivre sans réseau.
/// Le téléchargement est fait par le moteur de carte (MapLibre) et gardé sur le téléphone.
class OfflineService {
  /// Doit être le même style que celui de l'écran du parcours.
  static const String styleUrl = 'https://tiles.openfreemap.org/styles/liberty';

  static ml.LatLngBounds? _bornes(Parcours p) {
    if (p.traceGPS.isEmpty) return null;
    var minLat = p.traceGPS.first.latitude, maxLat = minLat;
    var minLon = p.traceGPS.first.longitude, maxLon = minLon;
    for (final pt in p.traceGPS) {
      minLat = math.min(minLat, pt.latitude);
      maxLat = math.max(maxLat, pt.latitude);
      minLon = math.min(minLon, pt.longitude);
      maxLon = math.max(maxLon, pt.longitude);
    }
    const marge = 0.03; // environ 3 km autour du tracé
    return ml.LatLngBounds(
      southwest: ml.LatLng(minLat - marge, minLon - marge),
      northeast: ml.LatLng(maxLat + marge, maxLon + marge),
    );
  }

  /// Plus la zone est grande, moins on descend en détail (pour garder un téléchargement raisonnable).
  static double _zoomMax(ml.LatLngBounds b) {
    final largeur = math.max(
      (b.northeast.latitude - b.southwest.latitude).abs(),
      (b.northeast.longitude - b.southwest.longitude).abs(),
    );
    if (largeur > 0.6) return 12.0;
    if (largeur > 0.3) return 13.0;
    return 14.0;
  }

  /// Retourne true si la carte est bien téléchargée, false en cas d'échec.
  static Future<bool> telecharger(Parcours p) async {
    if (kIsWeb) return false;
    final bornes = _bornes(p);
    if (bornes == null) return false;

    final fin = Completer<bool>();
    try {
      await ml.downloadOfflineRegion(
        ml.OfflineRegionDefinition(
          bounds: bornes,
          minZoom: 9.0,
          maxZoom: _zoomMax(bornes),
          mapStyleUrl: styleUrl,
        ),
        metadata: {'nom': p.titre},
        onEvent: (status) {
          if (status is ml.Success) {
            if (!fin.isCompleted) fin.complete(true);
          } else if (status is ml.Error) {
            if (!fin.isCompleted) fin.complete(false);
          }
        },
      );
    } catch (_) {
      return false;
    }
    return fin.future.timeout(const Duration(minutes: 10), onTimeout: () => false);
  }
}
