import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/parcours.dart';

/// Photo d'un lieu traversé par un parcours (ville ou village), prise sur Wikipédia / Wikimedia Commons.
class PhotoLieu {
  final String url;
  final String lieu;
  const PhotoLieu({required this.url, required this.lieu});
}

class PhotoService {
  static const String credit = 'Photos : Wikipédia / Wikimedia Commons (licences libres)';

  static final Map<String, Future<PhotoLieu?>> _parLieu = {};
  static final Map<String, Future<PhotoLieu?>> _parParcours = {};

  /// Photo d'une des villes traversées (la première qui en a une), sinon de la ville de départ.
  static Future<PhotoLieu?> pourParcours(Parcours p) {
    return _parParcours.putIfAbsent(p.id, () async {
      final noms = <String>[];
      for (final e in p.etapes) {
        if (e.nom.trim().isNotEmpty && !noms.contains(e.nom)) noms.add(e.nom);
      }
      if (p.ville.trim().isNotEmpty && !noms.contains(p.ville)) noms.add(p.ville);
      for (final nom in noms.take(4)) {
        final photo = await _pourLieu(nom);
        if (photo != null) return photo;
      }
      return null;
    });
  }

  static Future<PhotoLieu?> _pourLieu(String nom) {
    return _parLieu.putIfAbsent(nom, () async {
      try {
        final titre = nom.trim().replaceAll(' ', '_');
        final uri = Uri.https('fr.wikipedia.org', '/api/rest_v1/page/summary/$titre');
        final r = await http.get(uri, headers: {
          'User-Agent': 'TotoPa/1.0 (application de parcours velo)',
          'Accept': 'application/json',
        }).timeout(const Duration(seconds: 6));
        if (r.statusCode != 200) return null;
        final data = json.decode(utf8.decode(r.bodyBytes)) as Map<String, dynamic>;
        if (data['type'] == 'disambiguation') return null; // plusieurs lieux du même nom : on évite de se tromper
        final miniature = data['thumbnail'];
        if (miniature is Map && miniature['source'] is String) {
          return PhotoLieu(url: miniature['source'] as String, lieu: nom);
        }
        return null;
      } catch (_) {
        return null;
      }
    });
  }
}
