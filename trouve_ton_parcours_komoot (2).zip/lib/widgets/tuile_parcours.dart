import 'package:flutter/material.dart';
import '../models/parcours.dart';
import '../services/photo_service.dart';

/// Carte de parcours façon appli de vélo : photo d'un lieu traversé, numéro (le même que sur la carte),
/// titre, forme (boucle, aller-retour, point à point), distance / durée / dénivelé, mini profil d'altitude.
/// Quand elle est sélectionnée, un bouton « Ouvrir » apparaît.
class TuileParcours extends StatelessWidget {
  static const Color vert = Color(0xFF2ED573);

  final Parcours parcours;
  final int? numero; // numéro affiché sur la photo (même numéro que sur la carte)
  final bool selectionne;
  final bool afficherBouton;
  final VoidCallback onTap;
  final VoidCallback? onOuvrir;
  final Widget? fin; // ex. les boutons des favoris

  const TuileParcours({
    super.key,
    required this.parcours,
    required this.onTap,
    this.numero,
    this.selectionne = false,
    this.afficherBouton = false,
    this.onOuvrir,
    this.fin,
  });

  @override
  Widget build(BuildContext context) {
    final p = parcours;
    final Color accent = selectionne ? vert : const Color(0xFF9AA8A1);

    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Material(
        color: selectionne ? const Color(0xFF14261B) : const Color(0xFF151A17),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: BorderSide(
            color: selectionne ? vert : const Color(0xFF2A322E),
            width: selectionne ? 2 : 1,
          ),
        ),
        child: InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _PhotoLieu(parcours: p, numero: numero, selectionne: selectionne),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            p.titre,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w700,
                              color: Color(0xFFF1F5F2),
                            ),
                          ),
                          const SizedBox(height: 4),
                          _etiquettes(),
                          const SizedBox(height: 8),
                          _formeEtDifficulte(),
                        ],
                      ),
                    ),
                    if (fin != null) fin!,
                  ],
                ),
                const SizedBox(height: 12),
                Wrap(
                  spacing: 18,
                  runSpacing: 6,
                  children: [
                    _stat(Icons.straighten, p.distance),
                    _stat(Icons.schedule, p.duree),
                    _stat(Icons.trending_up, p.denivele),
                  ],
                ),
                if (p.altitudes.length >= 2) ...[
                  const SizedBox(height: 10),
                  SizedBox(
                    height: 34,
                    width: double.infinity,
                    child: CustomPaint(painter: _ProfilPainter(p.altitudes, accent)),
                  ),
                ],
                if (selectionne && afficherBouton && onOuvrir != null) ...[
                  const SizedBox(height: 12),
                  SizedBox(
                    width: double.infinity,
                    height: 46,
                    child: FilledButton.icon(
                      style: FilledButton.styleFrom(
                        backgroundColor: vert,
                        foregroundColor: const Color(0xFF06210F),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(23)),
                      ),
                      onPressed: onOuvrir,
                      icon: const Icon(Icons.navigation),
                      label: const Text(
                        'Ouvrir le parcours',
                        style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _etiquettes() {
    final p = parcours;
    final IconData icone;
    final Color couleur;
    final String texte;
    if (p.estRecommande) {
      icone = Icons.verified;
      couleur = const Color(0xFFFFC043);
      texte = p.popularite > 0 ? 'Recommandé · ${p.popularite} vues' : 'Recommandé';
    } else if (p.estPlanifie) {
      icone = Icons.edit_road;
      couleur = const Color(0xFFB794F6);
      texte = 'Planifié par toi';
    } else if (p.estOpenData) {
      icone = Icons.alt_route;
      couleur = const Color(0xFF5AA9FF);
      texte = p.detailSource.isNotEmpty ? 'Balisé · ${p.detailSource}' : 'Itinéraire balisé';
    } else {
      icone = Icons.auto_awesome;
      couleur = const Color(0xFF9AA8A1);
      texte = 'Généré pour toi';
    }
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icone, size: 15, color: couleur),
        const SizedBox(width: 4),
        Flexible(
          child: Text(
            texte,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(fontSize: 12.5, color: couleur, fontWeight: FontWeight.w600),
          ),
        ),
      ],
    );
  }

  Widget _formeEtDifficulte() {
    final p = parcours;
    final forme = p.forme;
    final IconData icone = forme == Parcours.formeBoucle
        ? Icons.loop
        : (forme == Parcours.formeAllerRetour ? Icons.swap_horiz : Icons.arrow_right_alt);
    return Wrap(
      spacing: 6,
      runSpacing: 6,
      children: [
        _puce(icone, Parcours.libelleForme(forme)),
        if (p.difficulte.isNotEmpty) _puce(Icons.speed, p.difficulte),
      ],
    );
  }

  Widget _puce(IconData icone, String texte) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: const Color(0xFF1F2723),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icone, size: 13, color: const Color(0xFF9AA8A1)),
          const SizedBox(width: 4),
          Text(texte, style: const TextStyle(fontSize: 12, color: Color(0xFFD5DDD8), fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }

  Widget _stat(IconData icone, String valeur) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icone, size: 18, color: const Color(0xFF9AA8A1)),
        const SizedBox(width: 5),
        Text(
          valeur,
          style: const TextStyle(fontSize: 14.5, fontWeight: FontWeight.w700, color: Color(0xFFF1F5F2)),
        ),
      ],
    );
  }
}

/// Encadré photo : une ville traversée (Wikipédia), avec le numéro du parcours en haut à gauche.
class _PhotoLieu extends StatelessWidget {
  final Parcours parcours;
  final int? numero;
  final bool selectionne;

  const _PhotoLieu({required this.parcours, required this.numero, required this.selectionne});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 96,
      height: 96,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(14),
        child: Stack(
          fit: StackFit.expand,
          children: [
            FutureBuilder<PhotoLieu?>(
              future: PhotoService.pourParcours(parcours),
              builder: (context, snap) {
                final photo = snap.data;
                if (photo == null) return _vide(snap.connectionState != ConnectionState.done);
                return Stack(
                  fit: StackFit.expand,
                  children: [
                    Image.network(
                      photo.url,
                      fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => _vide(false),
                      loadingBuilder: (c, child, progres) => progres == null ? child : _vide(true),
                    ),
                    Positioned(
                      left: 0,
                      right: 0,
                      bottom: 0,
                      child: Container(
                        padding: const EdgeInsets.fromLTRB(6, 10, 6, 4),
                        decoration: const BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: [Color(0x00000000), Color(0xCC000000)],
                          ),
                        ),
                        child: Text(
                          photo.lieu,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w600),
                        ),
                      ),
                    ),
                  ],
                );
              },
            ),
            if (numero != null)
              Positioned(
                left: 6,
                top: 6,
                child: Container(
                  width: 26,
                  height: 26,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: selectionne ? TuileParcours.vert : const Color(0xFF151A17),
                    shape: BoxShape.circle,
                    border: Border.all(color: Colors.white, width: 1.5),
                  ),
                  child: Text(
                    '$numero',
                    style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.bold,
                      color: selectionne ? const Color(0xFF06210F) : Colors.white,
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _vide(bool chargement) {
    return Container(
      color: const Color(0xFF1F2723),
      alignment: Alignment.center,
      child: chargement
          ? const SizedBox(
              width: 20,
              height: 20,
              child: CircularProgressIndicator(strokeWidth: 2, color: Color(0xFF3A4540)),
            )
          : const Icon(Icons.landscape, size: 34, color: Color(0xFF3A4540)),
    );
  }
}

/// Mini profil d'altitude (courbe + aire légère), sans axes.
class _ProfilPainter extends CustomPainter {
  final List<double> altitudes;
  final Color couleur;

  _ProfilPainter(this.altitudes, this.couleur);

  @override
  void paint(Canvas canvas, Size size) {
    final n = altitudes.length;
    if (n < 2) return;
    final pas = n > 120 ? n / 120 : 1.0;
    final pts = <double>[];
    for (double i = 0; i < n; i += pas) {
      pts.add(altitudes[i.floor()]);
    }
    pts.add(altitudes.last);

    double mn = pts.first, mx = pts.first;
    for (final a in pts) {
      if (a < mn) mn = a;
      if (a > mx) mx = a;
    }
    final plage = (mx - mn) < 10 ? 10.0 : (mx - mn);
    final dx = size.width / (pts.length - 1);

    final ligne = Path();
    final aire = Path();
    for (int i = 0; i < pts.length; i++) {
      final x = i * dx;
      final y = size.height - 3 - ((pts[i] - mn) / plage) * (size.height - 6);
      if (i == 0) {
        ligne.moveTo(x, y);
        aire.moveTo(x, size.height);
        aire.lineTo(x, y);
      } else {
        ligne.lineTo(x, y);
        aire.lineTo(x, y);
      }
    }
    aire.lineTo(size.width, size.height);
    aire.close();

    canvas.drawPath(aire, Paint()..color = couleur.withValues(alpha: 0.15));
    canvas.drawPath(
      ligne,
      Paint()
        ..color = couleur
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2
        ..strokeJoin = StrokeJoin.round,
    );
  }

  @override
  bool shouldRepaint(covariant _ProfilPainter old) =>
      old.altitudes != altitudes || old.couleur != couleur;
}
