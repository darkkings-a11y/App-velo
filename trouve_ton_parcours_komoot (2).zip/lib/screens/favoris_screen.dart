import 'package:flutter/material.dart';
import '../models/parcours.dart';
import '../services/export_gpx_service.dart';
import '../services/favoris_service.dart';
import '../widgets/import_gpx.dart';
import '../widgets/tuile_parcours.dart';
import 'a_propos_screen.dart';
import 'carte_screen.dart';

class FavorisScreen extends StatefulWidget {
  const FavorisScreen({super.key});

  @override
  State<FavorisScreen> createState() => _FavorisScreenState();
}

class _FavorisScreenState extends State<FavorisScreen> {
  List<Parcours>? _favoris;

  @override
  void initState() {
    super.initState();
    _recharger();
  }

  Future<void> _recharger() async {
    final liste = await FavorisService.charger();
    if (mounted) setState(() => _favoris = liste);
  }

  Future<void> _exporter(Parcours p) async {
    final messager = ScaffoldMessenger.of(context);
    try {
      final chemin = await ExportGpxService.exporter(p);
      if (chemin != null) {
        messager.showSnackBar(SnackBar(content: Text('« ${p.titre} » exporté en GPX ✅')));
      }
    } catch (e) {
      messager.showSnackBar(SnackBar(content: Text("L'export a échoué : $e")));
    }
  }

  @override
  Widget build(BuildContext context) {
    final favoris = _favoris;

    return Scaffold(
      backgroundColor: const Color(0xFF0B0F0D),
      appBar: AppBar(
        title: const Text('Mes parcours', style: TextStyle(fontWeight: FontWeight.bold)),
        backgroundColor: const Color(0xFF0B0F0D),
        foregroundColor: const Color(0xFFF1F5F2),
        elevation: 0,
        scrolledUnderElevation: 1,
        actions: [
          IconButton(
            icon: const Icon(Icons.info_outline),
            tooltip: 'À propos et confidentialité',
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const AProposScreen()),
            ),
          ),
          IconButton(
            icon: const Icon(Icons.upload_file),
            tooltip: 'Importer un fichier GPX',
            onPressed: () async {
              await importerGpx(context);
              _recharger();
            },
          ),
        ],
      ),
      body: favoris == null
          ? const Center(child: CircularProgressIndicator(color: TuileParcours.vert))
          : favoris.isEmpty
              ? const Center(
                  child: Padding(
                    padding: EdgeInsets.symmetric(horizontal: 32),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.favorite_border, size: 64, color: Color(0xFF7C8A84)),
                        SizedBox(height: 16),
                        Text(
                          'Aucun parcours enregistré.',
                          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Color(0xFFF1F5F2)),
                        ),
                        SizedBox(height: 8),
                        Text(
                          "Appuie sur le ❤ d'un parcours, ou importe un fichier GPX avec le bouton en haut.",
                          textAlign: TextAlign.center,
                          style: TextStyle(fontSize: 14, color: Color(0xFF9AA8A1)),
                        ),
                      ],
                    ),
                  ),
                )
              : ListView.builder(
                  padding: const EdgeInsets.fromLTRB(14, 14, 14, 24),
                  itemCount: favoris.length,
                  itemBuilder: (context, index) {
                    final p = favoris[index];
                    return TuileParcours(
                      parcours: p,
                      onTap: () async {
                        await Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => CarteScreen(parcours: p)),
                        );
                        _recharger();
                      },
                      fin: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          IconButton(
                            icon: const Icon(Icons.file_download_outlined, color: TuileParcours.vert),
                            tooltip: 'Exporter en GPX',
                            onPressed: () => _exporter(p),
                          ),
                          IconButton(
                            icon: const Icon(Icons.favorite, color: Colors.redAccent),
                            tooltip: 'Retirer des favoris',
                            onPressed: () async {
                              await FavorisService.retirer(p);
                              _recharger();
                            },
                          ),
                        ],
                      ),
                    );
                  },
                ),
    );
  }
}
