import 'package:flutter/material.dart';
import '../widgets/import_gpx.dart';
import 'carte_screen.dart';
import 'decouvrir_screen.dart';
import 'favoris_screen.dart';
import 'planificateur_screen.dart';

/// Coque de l'application : barre de navigation en bas
/// (Découvrir / Planifier / Favoris / Importer) autour des écrans principaux.
class AccueilScreen extends StatefulWidget {
  const AccueilScreen({super.key});

  @override
  State<AccueilScreen> createState() => _AccueilScreenState();
}

class _AccueilScreenState extends State<AccueilScreen> {
  int _onglet = 0; // 0 = Découvrir, 1 = Planifier, 2 = Favoris
  bool _planifierVu = false; // le planificateur n'est créé qu'à la première visite, puis gardé en vie
  int _versionFavoris = 0; // change pour forcer le rechargement de la liste des favoris

  Future<void> _importer() async {
    final p = await importerGpx(context);
    if (!mounted) return;
    setState(() => _versionFavoris++);
    if (p != null) {
      await Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => CarteScreen(parcours: p)),
      );
      if (mounted) setState(() => _versionFavoris++);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: _onglet,
        children: [
          // Découvrir et Planifier restent vivants en arrière-plan : cartes et points ne sont pas perdus.
          const DecouvrirScreen(),
          _planifierVu ? const PlanificateurScreen() : const SizedBox.shrink(),
          _onglet == 2 ? FavorisScreen(key: ValueKey(_versionFavoris)) : const SizedBox.shrink(),
        ],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _onglet,
        onDestinationSelected: (i) {
          if (i == 3) {
            _importer(); // « Importer » ouvre le sélecteur de fichiers sans changer d'onglet
            return;
          }
          setState(() {
            _onglet = i;
            if (i == 1) _planifierVu = true;
          });
        },
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.explore_outlined),
            selectedIcon: Icon(Icons.explore),
            label: 'Découvrir',
          ),
          NavigationDestination(
            icon: Icon(Icons.edit_road_outlined),
            selectedIcon: Icon(Icons.edit_road),
            label: 'Planifier',
          ),
          NavigationDestination(
            icon: Icon(Icons.favorite_border),
            selectedIcon: Icon(Icons.favorite),
            label: 'Favoris',
          ),
          NavigationDestination(
            icon: Icon(Icons.upload_file_outlined),
            selectedIcon: Icon(Icons.upload_file),
            label: 'Importer',
          ),
        ],
      ),
    );
  }
}
