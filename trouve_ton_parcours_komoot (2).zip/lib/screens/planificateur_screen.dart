import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:latlong2/latlong.dart';
import 'package:maplibre_gl/maplibre_gl.dart' as ml;
import '../models/parcours.dart';
import '../services/favoris_service.dart';
import '../services/geocoding_service.dart';
import '../services/gpx_service.dart';
import '../services/routage_service.dart';
import 'carte_screen.dart';

/// Planificateur : on touche la carte pour poser ses points, le tracé suit les routes et chemins du style choisi.
/// On voit tout de suite la distance, le dénivelé et la durée, puis on enregistre et on ouvre le parcours.
class PlanificateurScreen extends StatefulWidget {
  const PlanificateurScreen({super.key});

  @override
  State<PlanificateurScreen> createState() => _PlanificateurScreenState();
}

class _PlanificateurScreenState extends State<PlanificateurScreen> {
  static const String _styleUrl = 'https://tiles.openfreemap.org/styles/liberty';
  static const Color _vert = Color(0xFF2ED573);
  static const Color _surVert = Color(0xFF06210F);

  final TextEditingController _recherche = TextEditingController();

  ml.MapLibreMapController? _ctl;
  bool _styleOk = false;

  final List<LatLng> _points = [];
  String _profil = 'balade';
  ({List<LatLng> points, List<double> altitudes})? _trace;
  Parcours? _apercu;
  bool _calcul = false;
  bool _enregistrement = false;
  int _numero = 0; // pour ignorer un calcul devenu inutile

  @override
  void dispose() {
    _recherche.dispose();
    super.dispose();
  }

  void _message(String texte) {
    if (!mounted) return;
    final m = ScaffoldMessenger.of(context);
    m.hideCurrentSnackBar();
    m.showSnackBar(SnackBar(content: Text(texte)));
  }

  ml.LatLng _ml(LatLng p) => ml.LatLng(p.latitude, p.longitude);

  // ---------------- Points et calcul ----------------

  Future<void> _surClic(dynamic point, ml.LatLng ll) async {
    if (_enregistrement) return;
    _points.add(LatLng(ll.latitude, ll.longitude));
    await _recalculer(avertirSiEchec: true);
  }

  Future<void> _annuler() async {
    if (_points.isEmpty) return;
    _points.removeLast();
    await _recalculer();
  }

  Future<void> _effacer() async {
    _points.clear();
    await _recalculer();
  }

  Future<void> _boucler() async {
    if (_points.length < 2) return;
    _points.add(_points.first);
    await _recalculer(avertirSiEchec: true);
  }

  Future<void> _changerProfil(String id) async {
    if (id == _profil) return;
    setState(() => _profil = id);
    await _recalculer();
  }

  Future<void> _recalculer({bool avertirSiEchec = false}) async {
    final numero = ++_numero;
    if (_points.length < 2) {
      setState(() {
        _trace = null;
        _apercu = null;
        _calcul = false;
      });
      await _dessiner();
      return;
    }
    setState(() => _calcul = true);
    await _dessiner(); // montre au moins les points pendant le calcul
    final t = await RoutageService.itineraireEntre(List<LatLng>.of(_points), _profil);
    if (!mounted || numero != _numero) return;

    if (t == null) {
      // Pas d'itinéraire possible : on retire le dernier point pour rester cohérent.
      if (avertirSiEchec) {
        _points.removeLast();
        _message("Impossible de relier ces points à vélo. Essaie un point plus proche d'une route ou d'un chemin.");
      }
      setState(() => _calcul = false);
      if (avertirSiEchec && _points.length >= 2) {
        await _recalculer();
      } else if (avertirSiEchec) {
        setState(() {
          _trace = null;
          _apercu = null;
        });
        await _dessiner();
      }
      return;
    }

    Parcours? apercu;
    try {
      apercu = await GpxService.depuisPoints(
        t.points,
        t.altitudes,
        nom: 'Mon parcours',
        source: Parcours.sourcePlanifie,
        avecVilles: false,
        villeParDefaut: 'Départ',
      );
    } catch (_) {}
    if (!mounted || numero != _numero) return;
    setState(() {
      _trace = t;
      _apercu = apercu;
      _calcul = false;
    });
    await _dessiner();
  }

  // ---------------- Carte ----------------

  Future<void> _dessiner() async {
    final c = _ctl;
    if (c == null || !_styleOk) return;
    try {
      await c.clearLines();
      await c.clearSymbols();
      final t = _trace;
      if (t != null && t.points.length >= 2) {
        final geo = t.points.map(_ml).toList();
        await c.addLine(ml.LineOptions(
          geometry: geo,
          lineColor: '#FFFFFF',
          lineWidth: 11.0,
          lineOpacity: 0.95,
          lineJoin: 'round',
        ));
        await c.addLine(ml.LineOptions(
          geometry: geo,
          lineColor: '#1E9E4A',
          lineWidth: 6.0,
          lineJoin: 'round',
        ));
      }
      for (var i = 0; i < _points.length; i++) {
        final premier = i == 0;
        final dernier = i == _points.length - 1 && _points.length > 1;
        await c.addSymbol(ml.SymbolOptions(
          geometry: _ml(_points[i]),
          textField: '${i + 1}',
          textSize: 17.0,
          textColor: '#FFFFFF',
          textHaloColor: premier ? '#1E9E4A' : (dernier ? '#D93636' : '#37413C'),
          textHaloWidth: 4.0,
          fontNames: const ['Noto Sans Bold'],
        ));
      }
    } catch (_) {}
  }

  Future<void> _centrerSur(LatLng p, {double zoom = 13}) async {
    try {
      await _ctl?.animateCamera(ml.CameraUpdate.newLatLngZoom(_ml(p), zoom));
    } catch (_) {}
  }

  Future<void> _chercherVille() async {
    final nom = _recherche.text.trim();
    if (nom.isEmpty) return;
    FocusScope.of(context).unfocus();
    try {
      final coords = await GeocodingService.recupererCoordonnees(nom);
      if (coords == null) {
        _message("Ville introuvable. Vérifie l'orthographe !");
        return;
      }
      await _centrerSur(coords);
    } catch (e) {
      _message(e.toString());
    }
  }

  Future<void> _maPosition() async {
    FocusScope.of(context).unfocus();
    try {
      if (!await Geolocator.isLocationServiceEnabled()) {
        _message('Active la localisation de ton téléphone.');
        return;
      }
      var perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied) perm = await Geolocator.requestPermission();
      if (perm == LocationPermission.denied || perm == LocationPermission.deniedForever) {
        _message('La localisation est refusée : active-la dans les réglages du téléphone.');
        return;
      }
      final pos = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
      await _centrerSur(LatLng(pos.latitude, pos.longitude), zoom: 14);
    } catch (e) {
      _message('Impossible de récupérer la position : $e');
    }
  }

  // ---------------- Enregistrement ----------------

  Future<void> _enregistrer() async {
    final t = _trace;
    if (t == null) return;
    final controle = TextEditingController(text: 'Mon parcours');
    final nom = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Nom du parcours'),
        content: TextField(
          controller: controle,
          autofocus: true,
          textCapitalization: TextCapitalization.sentences,
          decoration: const InputDecoration(hintText: 'Ex. Sortie du dimanche'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Annuler')),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: _vert, foregroundColor: _surVert),
            onPressed: () => Navigator.pop(ctx, controle.text.trim()),
            child: const Text('Enregistrer'),
          ),
        ],
      ),
    );
    controle.dispose();
    if (nom == null) return;

    setState(() => _enregistrement = true);
    try {
      final p = await GpxService.depuisPoints(
        t.points,
        t.altitudes,
        nom: nom.isEmpty ? 'Mon parcours' : nom,
        source: Parcours.sourcePlanifie,
        avecVilles: true,
        villeParDefaut: 'Départ',
      );
      await FavorisService.ajouter(p);
      if (!mounted) return;
      setState(() => _enregistrement = false);
      _message('« ${p.titre} » enregistré dans tes favoris ✅');
      await Navigator.push(context, MaterialPageRoute(builder: (_) => CarteScreen(parcours: p)));
    } catch (e) {
      if (mounted) setState(() => _enregistrement = false);
      _message("L'enregistrement a échoué : $e");
    }
  }

  // ---------------- Interface ----------------

  @override
  Widget build(BuildContext context) {
    final haut = MediaQuery.of(context).padding.top;

    return Stack(
      children: [
        ml.MapLibreMap(
          styleString: _styleUrl,
          initialCameraPosition: const ml.CameraPosition(target: ml.LatLng(45.75, 4.85), zoom: 11),
          onMapCreated: (c) => _ctl = c,
          onStyleLoadedCallback: () async {
            _styleOk = true;
            await _dessiner();
          },
          onMapClick: _surClic,
          compassEnabled: false,
          tiltGesturesEnabled: false,
        ),

        // Recherche d'un lieu + styles
        Positioned(
          top: haut + 10,
          left: 12,
          right: 12,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Material(
                elevation: 5,
                color: const Color(0xFF1B211E),
                shape: const StadiumBorder(),
                child: Padding(
                  padding: const EdgeInsets.only(left: 16, right: 4),
                  child: Row(
                    children: [
                      const Icon(Icons.search, color: Color(0xFF9AA8A1)),
                      const SizedBox(width: 10),
                      Expanded(
                        child: TextField(
                          controller: _recherche,
                          textInputAction: TextInputAction.search,
                          onSubmitted: (_) => _chercherVille(),
                          style: const TextStyle(fontSize: 16, color: Color(0xFFF1F5F2)),
                          decoration: const InputDecoration(
                            hintText: 'Aller à une ville',
                            hintStyle: TextStyle(color: Color(0xFF7C8A84)),
                            border: InputBorder.none,
                            contentPadding: EdgeInsets.symmetric(vertical: 15),
                            isDense: true,
                          ),
                        ),
                      ),
                      IconButton(
                        tooltip: 'Ma position',
                        icon: const Icon(Icons.my_location, color: _vert),
                        onPressed: _maPosition,
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 10),
              Row(
                children: [
                  _puce('route', 'Route', Icons.directions_bike),
                  const SizedBox(width: 8),
                  _puce('balade', 'Balade', Icons.park),
                  const SizedBox(width: 8),
                  _puce('vtt', 'VTT', Icons.terrain),
                ],
              ),
            ],
          ),
        ),

        // Panneau du bas
        Positioned(
          left: 12,
          right: 12,
          bottom: 12,
          child: _panneau(),
        ),

        if (_enregistrement)
          const Positioned.fill(
            child: ColoredBox(
              color: Color(0x88000000),
              child: Center(child: CircularProgressIndicator(color: _vert)),
            ),
          ),
      ],
    );
  }

  Widget _puce(String id, String libelle, IconData icone) {
    final choisi = _profil == id;
    return Material(
      elevation: 3,
      color: choisi ? _vert : const Color(0xFF1B211E),
      shape: const StadiumBorder(),
      child: InkWell(
        customBorder: const StadiumBorder(),
        onTap: () => _changerProfil(id),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icone, size: 18, color: choisi ? _surVert : const Color(0xFFF1F5F2)),
              const SizedBox(width: 6),
              Text(libelle,
                  style: TextStyle(fontWeight: FontWeight.w700, color: choisi ? _surVert : const Color(0xFFF1F5F2))),
            ],
          ),
        ),
      ),
    );
  }

  Widget _panneau() {
    final a = _apercu;
    return Material(
      elevation: 8,
      color: const Color(0xFF151A17),
      borderRadius: BorderRadius.circular(20),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: _points.isEmpty
            ? const Row(
                children: [
                  Icon(Icons.touch_app, color: _vert),
                  SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      'Touche la carte pour poser ton départ, puis les points suivants. Le tracé suit les routes et les chemins.',
                      style: TextStyle(color: Color(0xFFD5DDD8), height: 1.3),
                    ),
                  ),
                ],
              )
            : Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      if (_calcul)
                        const SizedBox(
                          width: 18,
                          height: 18,
                          child: CircularProgressIndicator(strokeWidth: 2, color: _vert),
                        )
                      else if (a != null) ...[
                        _stat(Icons.straighten, a.distance),
                        const SizedBox(width: 16),
                        _stat(Icons.trending_up, a.denivele),
                        const SizedBox(width: 16),
                        _stat(Icons.schedule, a.duree),
                      ] else
                        const Text('Pose un 2e point pour voir le tracé',
                            style: TextStyle(color: Color(0xFF9AA8A1))),
                      const Spacer(),
                      IconButton(
                        tooltip: 'Annuler le dernier point',
                        icon: const Icon(Icons.undo, color: Color(0xFFF1F5F2)),
                        onPressed: _calcul ? null : _annuler,
                      ),
                      IconButton(
                        tooltip: 'Revenir au départ (boucle)',
                        icon: const Icon(Icons.loop, color: Color(0xFFF1F5F2)),
                        onPressed: _calcul || _points.length < 2 ? null : _boucler,
                      ),
                      IconButton(
                        tooltip: 'Tout effacer',
                        icon: const Icon(Icons.delete_outline, color: Color(0xFFF1F5F2)),
                        onPressed: _effacer,
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  SizedBox(
                    width: double.infinity,
                    height: 46,
                    child: FilledButton.icon(
                      style: FilledButton.styleFrom(
                        backgroundColor: _vert,
                        foregroundColor: _surVert,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(23)),
                      ),
                      onPressed: (_trace == null || _calcul) ? null : _enregistrer,
                      icon: const Icon(Icons.save_alt),
                      label: const Text('Enregistrer et ouvrir',
                          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                    ),
                  ),
                ],
              ),
      ),
    );
  }

  Widget _stat(IconData icone, String valeur) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icone, size: 18, color: const Color(0xFF9AA8A1)),
        const SizedBox(width: 5),
        Text(valeur,
            style: const TextStyle(fontSize: 14.5, fontWeight: FontWeight.w700, color: Color(0xFFF1F5F2))),
      ],
    );
  }
}
