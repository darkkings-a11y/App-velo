import 'package:flutter/material.dart';
import '../services/photo_service.dart';

/// À propos, confidentialité et sources des données.
class AProposScreen extends StatelessWidget {
  const AProposScreen({super.key});

  static const Color _texte = Color(0xFFF1F5F2);
  static const Color _doux = Color(0xFF9AA8A1);
  static const Color _vert = Color(0xFF2ED573);

  static const List<(String, String)> _services = [
    ('OpenFreeMap', 'Le fond de carte : la zone affichée sur la carte.'),
    ('Géoplateforme (IGN) et geo.api.gouv.fr', 'Le nom de la ville ou de la rue : le texte que tu tapes, ou les coordonnées d\u2019un point.'),
    ('OpenStreetMap (serveurs Overpass)', 'Les itinéraires balisés et les chemins : la zone autour de la ville cherchée.'),
    ('BRouter', 'Le calcul des parcours : les points de départ, de passage et d\u2019arrivée.'),
    ('Open-Meteo', 'La météo et les altitudes : les coordonnées du lieu.'),
    ('Wikipédia', 'Les photos des villes traversées : le nom des villes.'),
  ];

  Widget _titre(String t) => Padding(
        padding: const EdgeInsets.only(top: 22, bottom: 8),
        child: Text(t, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold, color: _texte)),
      );

  Widget _para(String t) => Padding(
        padding: const EdgeInsets.only(bottom: 8),
        child: Text(t, style: const TextStyle(fontSize: 14.5, color: _doux, height: 1.4)),
      );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0B0F0D),
      appBar: AppBar(
        title: const Text('À propos', style: TextStyle(fontWeight: FontWeight.bold)),
        backgroundColor: const Color(0xFF0B0F0D),
        foregroundColor: _texte,
        elevation: 0,
        scrolledUnderElevation: 1,
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 4, 20, 32),
        children: [
          _titre('TotoPa'),
          _para('Une application pour trouver, planifier et suivre des parcours à vélo : boucles, allers-retours et itinéraires point à point, en route, en balade ou en VTT. Version 1.0.'),

          _titre('Confidentialité'),
          _para('Pas de compte, pas de publicité, pas de suivi : l\u2019application n\u2019a pas de serveur à elle et ne collecte aucune donnée sur toi.'),
          _para('Sur ton téléphone, elle garde seulement tes parcours favoris et le nombre de fois où tu en as ouvert chacun. Tu peux les supprimer à tout moment depuis l\u2019onglet Favoris.'),
          _para('Ta position n\u2019est utilisée que si tu appuies sur « Autour de moi » ou sur le bouton de position, et uniquement pendant l\u2019utilisation de l\u2019appli. Pendant le guidage, elle sert à te situer sur le parcours.'),

          _titre('Services en ligne utilisés'),
          _para('Pour fonctionner, l\u2019appli interroge des services publics. Chacun reçoit uniquement ce qui est nécessaire à sa tâche, ainsi que l\u2019adresse IP de ton appareil, comme tout site internet :'),
          for (final s in _services)
            Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Padding(
                    padding: EdgeInsets.only(top: 3, right: 10),
                    child: Icon(Icons.circle, size: 7, color: _vert),
                  ),
                  Expanded(
                    child: Text.rich(
                      TextSpan(
                        children: [
                          TextSpan(text: s.$1, style: const TextStyle(fontWeight: FontWeight.bold, color: _texte)),
                          TextSpan(text: ' : ${s.$2}'),
                        ],
                      ),
                      style: const TextStyle(fontSize: 14.5, color: _doux, height: 1.4),
                    ),
                  ),
                ],
              ),
            ),
          _para('Quand tu exportes ou partages un parcours, le fichier GPX va là où tu le décides (dossier du téléphone, messagerie, e-mail…).'),

          _titre('Sources et licences'),
          _para('Cartes et itinéraires : © OpenStreetMap contributors, licence ODbL. Fond de carte : © OpenFreeMap.'),
          _para(PhotoService.credit),

          _titre('Prudence'),
          _para('Les parcours sont calculés automatiquement ou issus de données ouvertes : ils peuvent traverser des routes fréquentées ou des chemins difficiles. Respecte le code de la route et la signalisation, adapte-toi à ta forme et à la météo, et ne te fie pas qu\u2019à l\u2019appli.'),
        ],
      ),
    );
  }
}
