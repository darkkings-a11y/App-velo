import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:geolocator/geolocator.dart';
import 'package:latlong2/latlong.dart';
import 'package:maplibre_gl/maplibre_gl.dart' as ml;
import 'package:wakelock_plus/wakelock_plus.dart';
import '../models/parcours.dart';
import '../services/export_gpx_service.dart';
import '../services/favoris_service.dart';
import '../services/guidage_service.dart';
import '../services/offline_service.dart';
import '../services/popularite_service.dart';
import '../services/routage_service.dart';
import '../services/rues_service.dart';
import '../widgets/profil_altitude.dart';

class CarteScreen extends StatefulWidget {
  final Parcours parcours;

  const CarteScreen({super.key, required this.parcours});

  @override
  State<CarteScreen> createState() => _CarteScreenState();
}

class _CarteScreenState extends State<CarteScreen> {
  static const Color _vert = Color(0xFF00E676);
  static const Color _rouge = Color(0xFFFF1744);
  static const Color _bleu = Color(0xFF2979FF);
  static const Color _vertFonce = Color(0xFF1B7F3B);
  static final Distance _dist = Distance(roundResult: false);

  // Fond de carte vectoriel gratuit, sans clé API (OpenFreeMap, données OpenStreetMap).
  // Fond de carte en couleur « liberty » (autres styles : bright, positron, dark, fiord).
  // Pour changer de look : remplace par une autre URL de style MapLibre.
  static const String _styleUrl = 'https://tiles.openfreemap.org/styles/liberty';

  // Réglages de la caméra « effet TomTom » pendant le guidage.
  static const double _inclinaisonGuidage = 60; // 0 = vue du dessus, 60 = vue de derrière
  static const double _zoomGuidage = 17.5;
  // Décalage de la caméra vers l'avant : la position apparaît dans le bas de l'écran (effet TomTom).
  // Augmente la valeur pour descendre encore la position, diminue pour la remonter.
  static const double _decalageAvantM = 90;
  static const double _zoomSuivi = 15.5;

  ml.MapLibreMapController? _ctl;
  bool _styleOk = false;
  ml.Circle? _cerclePosition;
  bool _majPositionEnCours = false;
  StreamSubscription<Position>? _sub;

  // Favori
  bool _favori = false;

  // GPS
  LatLng? _position;
  double _cap = 0;
  double _vitesse = 0;
  bool _gpsActif = false;
  bool _suivre = false;
  double? _ecartM;

  // Mode « Parcours GPS » (guidage)
  bool _modeGps = false;
  bool _termine = false;
  int _idxProgres = 0;
  double _bearingCible = 0;

  // Orientation de la carte pendant le guidage (cap réel si on roule, sinon direction du tracé)
  double _capCarte = 0;
  bool _capConnu = false;

  // Sur / hors parcours (null tant qu'on n'a pas de position)
  bool? _surParcours;

  // Noms des rues le long du parcours (chargés à l'ouverture de la feuille de route)
  List<SegmentRue>? _rues;
  bool _ruesEchec = false;
  bool _ruesChargement = false;
  bool _ruesPrecises = false; // true quand les noms précis (OpenStreetMap) sont arrivés
  final ValueNotifier<int> _ruesVersion = ValueNotifier<int>(0);

  // Virages du parcours
  List<double> _cumParcours = const [];
  List<Virage> _viragesParcours = const [];

  // Itinéraire pour rejoindre le parcours quand on en est loin
  List<LatLng> _approche = [];
  List<double> _approcheCum = [];
  List<Virage> _viragesApproche = [];
  ml.Line? _ligneApproche;
  ml.Line? _ligneApprocheContour;
  bool _approcheEnCours = false;
  DateTime _derniereApproche = DateTime.fromMillisecondsSinceEpoch(0);
  LatLng? _origineApproche;

  // Consigne affichée dans le bandeau
  Virage? _prochainVirage;
  double _distVirageM = 0;
  double _distFinM = 0;

  @override
  void initState() {
    super.initState();
    _chargerFavori();
    PopulariteService.compter(widget.parcours); // +1 consultation si c'est un parcours recommandé
    final trace = widget.parcours.traceGPS;
    _cumParcours = Guidage.cumulM(trace);
    _viragesParcours = Guidage.detecterVirages(trace, _cumParcours);
    _chargerRues(); // les noms de rues se chargent pendant que tu regardes la carte
  }

  @override
  void dispose() {
    _sub?.cancel();
    _ruesVersion.dispose();
    WakelockPlus.disable();
    super.dispose();
  }

  void _message(String texte) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(texte)));
  }

  ml.LatLng _ml(LatLng p) => ml.LatLng(p.latitude, p.longitude);

  // ---------------- Partage et carte hors ligne ----------------

  bool _horsLigneEnCours = false;

  void _snack(String texte) {
    if (!mounted) return;
    final m = ScaffoldMessenger.of(context);
    m.hideCurrentSnackBar();
    m.showSnackBar(SnackBar(content: Text(texte)));
  }

  Future<void> _partager() async {
    try {
      await ExportGpxService.partager(widget.parcours);
    } catch (e) {
      _snack('Le partage a échoué : $e');
    }
  }

  Future<void> _telechargerHorsLigne() async {
    if (_horsLigneEnCours) return;
    setState(() => _horsLigneEnCours = true);
    _snack("Téléchargement de la carte en cours… garde l'appli ouverte.");
    final ok = await OfflineService.telecharger(widget.parcours);
    if (!mounted) return;
    setState(() => _horsLigneEnCours = false);
    _snack(ok
        ? 'Carte téléchargée : tu peux suivre ce parcours sans réseau.'
        : "Le téléchargement a échoué. Vérifie ta connexion et réessaie.");
  }

  // ---------------- Favoris ----------------

  Future<void> _chargerFavori() async {
    final f = await FavorisService.estFavori(widget.parcours);
    if (mounted) setState(() => _favori = f);
  }

  Future<void> _basculerFavori() async {
    if (_favori) {
      await FavorisService.retirer(widget.parcours);
      _message('Retiré des favoris');
    } else {
      await FavorisService.ajouter(widget.parcours);
      _message('Parcours ajouté aux favoris ❤️');
    }
    if (mounted) setState(() => _favori = !_favori);
  }

  // ---------------- Carte 3D (MapLibre) ----------------

  void _surCarteCreee(ml.MapLibreMapController c) {
    _ctl = c;
  }

  /// Appelé quand le fond de carte est prêt : on dessine le tracé, le départ et les villes.
  Future<void> _surStyleCharge() async {
    final c = _ctl;
    if (c == null) return;
    final p = widget.parcours;
    final trace = p.traceGPS.map(_ml).toList();

    if (trace.length > 1) {
      // Liseré blanc puis trait vert, pour bien ressortir sur le fond clair.
      await c.addLine(ml.LineOptions(
        geometry: trace,
        lineColor: '#FFFFFF',
        lineWidth: 10.0,
        lineOpacity: 0.9,
        lineJoin: 'round',
      ));
      await c.addLine(ml.LineOptions(
        geometry: trace,
        lineColor: '#00B84D',
        lineWidth: 6.0,
        lineJoin: 'round',
      ));
    }

    for (final e in p.etapes) {
      await c.addCircle(ml.CircleOptions(
        geometry: _ml(e.position),
        circleRadius: 5.0,
        circleColor: '#FFFFFF',
        circleStrokeColor: '#00B84D',
        circleStrokeWidth: 2.0,
      ));
      await c.addSymbol(ml.SymbolOptions(
        geometry: _ml(e.position),
        textField: e.nom,
        textSize: 13.0,
        textColor: '#111111',
        textHaloColor: '#FFFFFF',
        textHaloWidth: 2.0,
        textAnchor: 'top',
        textOffset: const Offset(0, 0.8),
        fontNames: const ['Noto Sans Bold'],
      ));
    }

    if (trace.isNotEmpty) {
      await c.addCircle(ml.CircleOptions(
        geometry: trace.first,
        circleRadius: 10.0,
        circleColor: '#00E676',
        circleStrokeColor: '#FFFFFF',
        circleStrokeWidth: 3.0,
      ));
    }

    _styleOk = true;
    if (!mounted) return;
    await _voirToutLeParcours(MediaQuery.of(context).size.height);
    if (_position != null) _majMarqueurPosition(_position!);
  }

  Future<void> _voirToutLeParcours(double hauteurEcran) async {
    final c = _ctl;
    final trace = widget.parcours.traceGPS;
    if (c == null || trace.length < 2) return;

    double minLat = trace.first.latitude, maxLat = trace.first.latitude;
    double minLon = trace.first.longitude, maxLon = trace.first.longitude;
    for (final p in trace) {
      minLat = math.min(minLat, p.latitude);
      maxLat = math.max(maxLat, p.latitude);
      minLon = math.min(minLon, p.longitude);
      maxLon = math.max(maxLon, p.longitude);
    }

    await c.animateCamera(
      ml.CameraUpdate.newLatLngBounds(
        ml.LatLngBounds(
          southwest: ml.LatLng(minLat, minLon),
          northeast: ml.LatLng(maxLat, maxLon),
        ),
        left: 40,
        top: 140,
        right: 40,
        bottom: hauteurEcran * (_modeGps ? 0.40 : 0.45),
      ),
      duration: const Duration(milliseconds: 600),
    );
    if (_suivre && mounted) setState(() => _suivre = false);
  }

  /// Caméra qui suit la position. En guidage : inclinée et tournée dans le sens de la marche.
  Future<void> _suivreCamera(LatLng pos) async {
    final c = _ctl;
    if (c == null) return;
    // En guidage on vise un point devant nous : la position se retrouve en bas de l'écran.
    final cible = _modeGps ? _dist.offset(pos, _decalageAvantM, _capCarte) : pos;
    await c.animateCamera(
      ml.CameraUpdate.newCameraPosition(
        ml.CameraPosition(
          target: _ml(cible),
          zoom: _modeGps ? _zoomGuidage : _zoomSuivi,
          tilt: _modeGps ? _inclinaisonGuidage : 0,
          bearing: _modeGps ? _capCarte : 0,
        ),
      ),
      duration: const Duration(milliseconds: 700),
    );
  }

  /// Remet la carte face au nord (et arrête le suivi, qui la ferait retourner dans le sens de la marche).
  Future<void> _remettreNord() async {
    final c = _ctl;
    if (c == null) return;
    if (_suivre) setState(() => _suivre = false);
    await c.animateCamera(
      ml.CameraUpdate.bearingTo(0),
      duration: const Duration(milliseconds: 500),
    );
  }

  /// Charge le nom des rues. Deux sources en parallèle : une rapide (rue à chaque virage, quelques secondes)
  /// et une précise (OpenStreetMap, toutes les rues du tracé) qui remplace la première quand elle arrive.
  void _chargerRues() {
    if (_ruesChargement) return;
    _ruesChargement = true;
    _ruesEchec = false;
    _ruesVersion.value++;
    int termines = 0;
    void fin() {
      termines++;
      if (termines < 2 || !mounted) return;
      _ruesChargement = false;
      _ruesEchec = _rues == null;
      _ruesVersion.value++;
    }

    final trace = widget.parcours.traceGPS;
    RuesService.chargerAuxTournants(trace, _cumParcours, _viragesParcours.map((v) => v.cumM).toList())
        .then((r) {
      if (!mounted || r == null || _ruesPrecises) return;
      _rues = r;
      _ruesVersion.value++;
    }).catchError((_) {}).whenComplete(fin);

    RuesService.charger(trace, _cumParcours).then((r) {
      if (!mounted || r == null) return;
      _rues = r;
      _ruesPrecises = true;
      _ruesVersion.value++;
    }).catchError((_) {}).whenComplete(fin);
  }

  /// Feuille de route écrite : chaque virage avec le nom de la rue, les distances, les villes traversées.
  void _ouvrirFeuilleDeRoute() {
    final p = widget.parcours;
    if (_ruesEchec && !_ruesChargement) {
      _ruesPrecises = false;
      _chargerRues(); // le chargement avait échoué : on réessaie
    }

    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) {
        return DraggableScrollableSheet(
          initialChildSize: 0.75,
          minChildSize: 0.4,
          maxChildSize: 0.95,
          expand: false,
          builder: (ctx, scroll) {
            return ValueListenableBuilder<int>(
              valueListenable: _ruesVersion,
              builder: (ctx, _, __) {
                final lignes = Guidage.feuilleDeRoute(p, _cumParcours, _viragesParcours, _rues);
                return Container(
                  decoration: const BoxDecoration(
                    color: Color(0xFF111614),
                    borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
                  ),
                  child: Column(
                    children: [
                      const SizedBox(height: 10),
                      Container(
                        width: 40,
                        height: 4,
                        decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(2)),
                      ),
                      Padding(
                        padding: const EdgeInsets.fromLTRB(16, 12, 8, 4),
                        child: Row(
                          children: [
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const Text('Feuille de route',
                                      style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
                                  Text('${p.distance} · ${p.duree} · ${p.denivele}',
                                      style: const TextStyle(color: Colors.white60, fontSize: 13)),
                                ],
                              ),
                            ),
                            TextButton.icon(
                              onPressed: () async {
                                await Clipboard.setData(ClipboardData(text: Guidage.texteFeuille(p, lignes)));
                                _message('Feuille de route copiée');
                              },
                              icon: const Icon(Icons.copy, size: 18, color: _vert),
                              label: const Text('Copier', style: TextStyle(color: _vert)),
                            ),
                          ],
                        ),
                      ),
                      if (_ruesChargement && _rues == null)
                        const Column(
                          children: [
                            LinearProgressIndicator(minHeight: 2, color: _vert, backgroundColor: Colors.white12),
                            Padding(
                              padding: EdgeInsets.symmetric(vertical: 6),
                              child: Text('Recherche des noms de rues…',
                                  style: TextStyle(color: Colors.white54, fontSize: 12)),
                            ),
                          ],
                        )
                      else if (_ruesEchec)
                        const Padding(
                          padding: EdgeInsets.symmetric(vertical: 6, horizontal: 16),
                          child: Text(
                            'Noms de rues indisponibles pour le moment (connexion ?). Rouvre la feuille pour réessayer.',
                            textAlign: TextAlign.center,
                            style: TextStyle(color: Color(0xFFFFB74D), fontSize: 12),
                          ),
                        )
                      else
                        const Divider(color: Colors.white12, height: 1),
                      Expanded(
                        child: ListView.builder(
                          controller: scroll,
                          padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
                          itemCount: lignes.length,
                          itemBuilder: (_, i) => _ligneRoute(lignes[i]),
                        ),
                      ),
                    ],
                  ),
                );
              },
            );
          },
        );
      },
    );
  }

  Widget _ligneRoute(LigneRoute l) {
    IconData icone;
    Color couleur = Colors.white;
    switch (l.genre) {
      case GenreLigne.depart:
        icone = Icons.play_circle_fill;
        couleur = _vert;
        break;
      case GenreLigne.arrivee:
        icone = Icons.flag;
        couleur = _vert;
        break;
      case GenreLigne.virage:
        icone = _iconeVirage(l.virage ?? TypeVirage.droite);
        break;
      case GenreLigne.ville:
        icone = Icons.location_city;
        couleur = const Color(0xFF82B1FF);
        break;
      case GenreLigne.toutDroit:
        icone = Icons.straight;
        couleur = Colors.white70;
        break;
    }
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 11),
      decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: Colors.white12))),
      child: Row(
        children: [
          Icon(icone, color: couleur, size: 28),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  l.texte,
                  style: const TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w600),
                ),
                if (l.detail != null)
                  Padding(
                    padding: const EdgeInsets.only(top: 2),
                    child: Text(l.detail!, style: const TextStyle(color: Colors.white54, fontSize: 13)),
                  ),
              ],
            ),
          ),
          Text(Guidage.formaterKm(l.km), style: const TextStyle(color: Colors.white54, fontSize: 13)),
        ],
      ),
    );
  }

  /// Point bleu de la position courante.
  Future<void> _majMarqueurPosition(LatLng pos) async {
    final c = _ctl;
    if (c == null || !_styleOk || _majPositionEnCours) return;
    _majPositionEnCours = true;
    try {
      final g = _ml(pos);
      if (_cerclePosition == null) {
        _cerclePosition = await c.addCircle(ml.CircleOptions(
          geometry: g,
          circleRadius: 9.0,
          circleColor: '#2979FF',
          circleStrokeColor: '#FFFFFF',
          circleStrokeWidth: 3.0,
        ));
      } else {
        await c.updateCircle(_cerclePosition!, ml.CircleOptions(geometry: g));
      }
    } catch (_) {
      // on réessaiera à la prochaine position
    } finally {
      _majPositionEnCours = false;
    }
  }

  // ---------------- GPS en direct ----------------

  Future<void> _boutonGps() async {
    if (_modeGps) {
      setState(() => _suivre = true);
      if (_position != null) _suivreCamera(_position!);
      return;
    }
    if (!_gpsActif) {
      await _demarrerGps();
      return;
    }
    if (!_suivre) {
      setState(() => _suivre = true);
      if (_position != null) _suivreCamera(_position!);
      return;
    }
    _arreterGps();
  }

  Future<void> _demarrerGps() async {
    final actif = await Geolocator.isLocationServiceEnabled();
    if (!actif) {
      _message('Active la localisation de ton téléphone.');
      return;
    }
    var perm = await Geolocator.checkPermission();
    if (perm == LocationPermission.denied) {
      perm = await Geolocator.requestPermission();
    }
    if (perm == LocationPermission.denied || perm == LocationPermission.deniedForever) {
      _message('Autorisation de localisation refusée.');
      return;
    }
    if (!mounted) return;

    setState(() {
      _gpsActif = true;
      _suivre = true;
    });

    _sub = Geolocator.getPositionStream(
      locationSettings: const LocationSettings(
        accuracy: LocationAccuracy.high,
        distanceFilter: 5,
      ),
    ).listen(_surPosition, onError: (_) => _message('Signal GPS perdu.'));
  }

  void _arreterGps() {
    _sub?.cancel();
    _sub = null;
    final c = _ctl;
    final cercle = _cerclePosition;
    if (c != null && cercle != null) {
      c.removeCircle(cercle);
    }
    _cerclePosition = null;
    _effacerApproche();
    if (!mounted) return;
    setState(() {
      _gpsActif = false;
      _surParcours = null;
      _prochainVirage = null;
      _suivre = false;
      _position = null;
      _ecartM = null;
    });
  }

  // ---------------- Rejoindre le parcours ----------------

  Future<void> _majApproche(LatLng pos, LatLng cible) async {
    if (_approcheEnCours) return;
    final now = DateTime.now();
    if (_approche.isNotEmpty) {
      final bouge = _origineApproche == null ||
          _dist.as(LengthUnit.Meter, _origineApproche!, pos) > 60;
      final ancien = now.difference(_derniereApproche).inSeconds > 20;
      if (!(bouge && ancien)) return;
    }
    _approcheEnCours = true;
    _derniereApproche = now;
    _origineApproche = pos;
    try {
      final pts = await RoutageService.itineraireVers(pos, cible) ?? [pos, cible];
      if (!mounted || _surParcours == true) return;
      final cum = Guidage.cumulM(pts);
      _approche = pts;
      _approcheCum = cum;
      _viragesApproche = Guidage.detecterVirages(pts, cum);
      await _dessinerApproche();
    } finally {
      _approcheEnCours = false;
      if (mounted) setState(() {});
    }
  }

  Future<void> _dessinerApproche() async {
    final c = _ctl;
    if (c == null || !_styleOk || _approche.length < 2) return;
    final g = _approche.map(_ml).toList();
    try {
      if (_ligneApproche == null) {
        _ligneApprocheContour = await c.addLine(ml.LineOptions(
          geometry: g,
          lineColor: '#FFFFFF',
          lineWidth: 10.0,
          lineOpacity: 0.9,
          lineJoin: 'round',
        ));
        _ligneApproche = await c.addLine(ml.LineOptions(
          geometry: g,
          lineColor: '#2979FF',
          lineWidth: 6.0,
          lineJoin: 'round',
        ));
      } else {
        await c.updateLine(_ligneApprocheContour!, ml.LineOptions(geometry: g));
        await c.updateLine(_ligneApproche!, ml.LineOptions(geometry: g));
      }
    } catch (_) {
      // on réessaiera au prochain calcul
    }
  }

  void _effacerApproche() {
    final c = _ctl;
    if (c != null) {
      if (_ligneApprocheContour != null) c.removeLine(_ligneApprocheContour!);
      if (_ligneApproche != null) c.removeLine(_ligneApproche!);
    }
    _ligneApprocheContour = null;
    _ligneApproche = null;
    _approche = [];
    _approcheCum = [];
    _viragesApproche = [];
    _origineApproche = null;
  }

  double _normaliser(double b) => ((b % 360) + 360) % 360;

  void _surPosition(Position p) {
    if (!mounted) return;
    final pos = LatLng(p.latitude, p.longitude);
    final trace = widget.parcours.traceGPS;
    final dists = widget.parcours.distancesKm;
    final n = trace.length;

    int meilleur = _idxProgres;
    double ecart = double.infinity;

    if (n > 0) {
      // On cherche d'abord juste devant la progression (évite de sauter d'un bout à l'autre de la boucle)
      final debut = math.max(0, _idxProgres - 10);
      final fin = math.min(n - 1, _idxProgres + 400);
      for (int i = debut; i <= fin; i++) {
        final d = _dist.as(LengthUnit.Meter, pos, trace[i]);
        if (d < ecart) {
          ecart = d;
          meilleur = i;
        }
      }
      // Si on est très loin, recherche sur tout le tracé
      if (ecart > 400) {
        for (int i = 0; i < n; i++) {
          final d = _dist.as(LengthUnit.Meter, pos, trace[i]);
          if (d < ecart) {
            ecart = d;
            meilleur = i;
          }
        }
      }
    }

    // Sur / hors parcours, avec une marge pour éviter que le point clignote avec le bruit GPS
    final bool sur;
    if (_surParcours == true) {
      sur = ecart <= 50;
    } else if (_surParcours == false) {
      sur = ecart <= 30;
    } else {
      sur = ecart <= 40;
    }

    if (sur) {
      if (_approche.isNotEmpty) _effacerApproche();
    } else if (_modeGps && n > 0) {
      _majApproche(pos, trace[meilleur]);
    }

    // Consigne : prochain virage sur l'itinéraire pour rejoindre le parcours, ou sur le parcours lui-même
    Virage? virage;
    double distVirage = 0;
    double distFin = 0;
    double bearing = _bearingCible;
    if (!sur && _approche.length > 1) {
      int idx = 0;
      double best = double.infinity;
      for (int i = 0; i < _approche.length; i++) {
        final d = _dist.as(LengthUnit.Meter, pos, _approche[i]);
        if (d < best) {
          best = d;
          idx = i;
        }
      }
      final ici = _approcheCum[idx];
      for (final v in _viragesApproche) {
        if (v.cumM > ici + 5) {
          virage = v;
          distVirage = v.cumM - ici;
          break;
        }
      }
      distFin = math.max(0.0, _approcheCum.last - ici);
      int j = idx;
      while (j < _approche.length - 1 && _approcheCum[j] < ici + 40) {
        j++;
      }
      bearing = _normaliser(_dist.bearing(pos, _approche[j]));
    } else if (n > 0) {
      final ici = _cumParcours.length == n ? _cumParcours[meilleur] : 0.0;
      if (sur && _cumParcours.length == n) {
        for (final v in _viragesParcours) {
          if (v.cumM > ici + 5) {
            virage = v;
            distVirage = v.cumM - ici;
            break;
          }
        }
        distFin = math.max(0.0, _cumParcours.last - ici);
      } else {
        distFin = ecart.isFinite ? ecart : 0;
      }
      // Point à viser : ~200 m devant si on est sur le tracé, sinon le tracé le plus proche
      LatLng cible = trace[meilleur];
      if (sur) {
        int j = meilleur;
        if (dists.length == n) {
          final limite = dists[meilleur] + 0.2;
          while (j < n - 1 && dists[j] < limite) {
            j++;
          }
        } else {
          j = math.min(n - 1, meilleur + 20);
        }
        cible = trace[j];
      }
      bearing = _normaliser(_dist.bearing(pos, cible));
    }

    // Orientation de la carte : cap réel si on roule, sinon direction du tracé au départ.
    final enMouvement = p.speed >= 1.0 && p.heading >= 0;
    if (enMouvement) {
      _capCarte = p.heading;
      _capConnu = true;
    } else if (!_capConnu) {
      _capCarte = bearing;
    }

    bool fini = _termine;
    if (_modeGps && !fini && n > 10 && meilleur >= n - 8 && ecart < 60) {
      final total = dists.isNotEmpty ? dists.last : 0.0;
      final parcouru = dists.length == n ? dists[meilleur] : 0.0;
      if (total > 0 && parcouru > total * 0.5) {
        fini = true;
        _message('Parcours terminé, bravo ! 🎉');
      }
    }

    setState(() {
      _position = pos;
      _cap = p.heading >= 0 ? p.heading : 0;
      _vitesse = p.speed >= 0 ? p.speed : 0;
      _ecartM = ecart.isFinite ? ecart : null;
      _idxProgres = meilleur;
      _bearingCible = bearing;
      _termine = fini;
      _surParcours = sur;
      _prochainVirage = virage;
      _distVirageM = distVirage;
      _distFinM = distFin;
    });

    _majMarqueurPosition(pos);
    if (_suivre) _suivreCamera(pos);
  }

  // ---------------- Mode « Parcours GPS » ----------------

  Future<void> _demarrerModeGps() async {
    if (!_gpsActif) {
      await _demarrerGps();
    }
    if (!_gpsActif) return; // autorisation refusée ou GPS désactivé

    await WakelockPlus.enable(); // garde l'écran allumé pendant le guidage
    if (!mounted) return;
    setState(() {
      _modeGps = true;
      _suivre = true;
      _termine = false;
      _idxProgres = 0;
      _capConnu = false;
    });
    if (_position != null) _suivreCamera(_position!);
  }

  Future<void> _terminerModeGps() async {
    await WakelockPlus.disable();
    _arreterGps();
    if (!mounted) return;
    setState(() {
      _modeGps = false;
      _termine = false;
    });
    _voirToutLeParcours(MediaQuery.of(context).size.height);
  }

  // ---------------- Interface ----------------

  @override
  Widget build(BuildContext context) {
    final p = widget.parcours;
    final trace = p.traceGPS;
    final hauteur = MediaQuery.of(context).size.height;
    final haut = MediaQuery.of(context).padding.top;

    IconData iconeGps = Icons.my_location;
    Color couleurGps = Colors.white;
    if (_gpsActif && _suivre) {
      couleurGps = _vert;
    } else if (_gpsActif) {
      iconeGps = Icons.location_searching;
      couleurGps = const Color(0xFF2979FF);
    }

    final depart = trace.isNotEmpty ? trace.first : const LatLng(45.75, 4.85);

    return Scaffold(
      backgroundColor: const Color(0xFF0B0F0D),
      body: Stack(
        children: [
          // Carte 3D : on coupe le suivi dès que l'utilisateur touche la carte.
          Listener(
            onPointerDown: (_) {
              if (_suivre) setState(() => _suivre = false);
            },
            child: ml.MapLibreMap(
              styleString: _styleUrl,
              initialCameraPosition: ml.CameraPosition(
                target: _ml(depart),
                zoom: 12,
              ),
              onMapCreated: _surCarteCreee,
              onStyleLoadedCallback: _surStyleCharge,
              compassEnabled: false,
              rotateGesturesEnabled: true,
              tiltGesturesEnabled: true,
            ),
          ),

          // Titre + cœur favori (masqué pendant le guidage : le bandeau prend sa place)
          if (!_modeGps)
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            child: Container(
              padding: EdgeInsets.fromLTRB(8, haut + 6, 8, 24),
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Color(0xDD000000), Color(0x00000000)],
                ),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  IconButton(
                    icon: const Icon(Icons.arrow_back, color: Colors.white),
                    onPressed: () => Navigator.pop(context),
                  ),
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.only(top: 8),
                      child: Text(
                        p.titre,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                  IconButton(
                    tooltip: 'Partager le parcours (GPX)',
                    visualDensity: VisualDensity.compact,
                    icon: const Icon(Icons.ios_share, color: Colors.white),
                    onPressed: _partager,
                  ),
                  IconButton(
                    tooltip: 'Télécharger la carte pour la hors ligne',
                    visualDensity: VisualDensity.compact,
                    icon: _horsLigneEnCours
                        ? const SizedBox(
                            width: 22,
                            height: 22,
                            child: CircularProgressIndicator(strokeWidth: 2.5, color: Colors.white),
                          )
                        : const Icon(Icons.download_for_offline_outlined, color: Colors.white),
                    onPressed: _horsLigneEnCours ? null : _telechargerHorsLigne,
                  ),
                  IconButton(
                    tooltip: _favori ? 'Retirer des favoris' : 'Ajouter aux favoris',
                    icon: Icon(
                      _favori ? Icons.favorite : Icons.favorite_border,
                      color: _favori ? Colors.redAccent : Colors.white,
                      size: 28,
                    ),
                    onPressed: _basculerFavori,
                  ),
                ],
              ),
            ),
          ),

          // Guidage : bandeau de consigne + pastille sur/hors parcours
          if (_modeGps)
            Positioned(
              top: haut + 8,
              left: 12,
              right: 12,
              child: Column(
                children: [
                  _bandeauGuidage(),
                  if (_surParcours != null) ...[
                    const SizedBox(height: 8),
                    _pastilleParcours(),
                  ],
                ],
              ),
            )
          else if (_gpsActif && _surParcours != null)
            Positioned(
              top: haut + 84,
              left: 0,
              right: 0,
              child: Center(child: _pastilleParcours()),
            ),

          // Boutons ronds à droite
          Positioned(
            right: 14,
            bottom: _modeGps ? 200 : hauteur * 0.40 + 14,
            child: Column(
              children: [
                _BoutonRond(
                  icone: Icons.list_alt,
                  couleur: Colors.white,
                  onTap: _ouvrirFeuilleDeRoute,
                ),
                const SizedBox(height: 12),
                _BoutonRond(
                  icone: Icons.explore,
                  couleur: Colors.white,
                  onTap: _remettreNord,
                ),
                const SizedBox(height: 12),
                _BoutonRond(
                  icone: iconeGps,
                  couleur: couleurGps,
                  onTap: _boutonGps,
                ),
                const SizedBox(height: 12),
                _BoutonRond(
                  icone: Icons.zoom_out_map,
                  couleur: Colors.white,
                  onTap: () => _voirToutLeParcours(hauteur),
                ),
              ],
            ),
          ),

          // Panneau du bas : guidage GPS ou résumé du parcours
          if (_modeGps)
            Positioned(left: 0, right: 0, bottom: 0, child: _panneauGps())
          else
            DraggableScrollableSheet(
              initialChildSize: 0.40,
              minChildSize: 0.40,
              maxChildSize: 0.90,
              builder: (context, scroll) {
                return Container(
                  decoration: const BoxDecoration(
                    color: Color(0xFF111614),
                    borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
                    boxShadow: [BoxShadow(color: Colors.black54, blurRadius: 12)],
                  ),
                  child: ListView(
                    controller: scroll,
                    padding: const EdgeInsets.fromLTRB(16, 10, 16, 24),
                    children: [
                      Center(
                        child: Container(
                          width: 40,
                          height: 4,
                          decoration: BoxDecoration(
                            color: Colors.white24,
                            borderRadius: BorderRadius.circular(2),
                          ),
                        ),
                      ),
                      const SizedBox(height: 14),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          _stat('Distance totale', '${p.distanceKm.toStringAsFixed(1)} km', Colors.white),
                          _stat('Dénivelé positif', '+${p.denivelePos} m', _vert),
                          _stat('Dénivelé négatif', '-${p.deniveleNeg} m', const Color(0xFFFF8A65)),
                        ],
                      ),
                      const SizedBox(height: 14),
                      SizedBox(
                        height: 130,
                        child: ProfilAltitude(
                          distancesKm: p.distancesKm,
                          altitudes: p.altitudes,
                          repereKm: p.etapes.map((e) => e.distanceKm).toList(),
                        ),
                      ),
                      const SizedBox(height: 14),
                      SizedBox(
                        height: 50,
                        child: ElevatedButton.icon(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFF2E9E4F),
                            foregroundColor: Colors.white,
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(25)),
                          ),
                          onPressed: _demarrerModeGps,
                          icon: const Icon(Icons.navigation),
                          label: const Text(
                            'Parcours GPS',
                            style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
                          ),
                        ),
                      ),
                      if (p.troncons.isNotEmpty) ...[
                        const SizedBox(height: 70),
                        const Text(
                          'Détail par tronçon',
                          style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold),
                        ),
                        const SizedBox(height: 6),
                        ...p.troncons.map(_ligneTroncon),
                      ],
                      const SizedBox(height: 16),
                      const Text(
                        '© OpenStreetMap contributors · © OpenFreeMap',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Colors.white30, fontSize: 10),
                      ),
                    ],
                  ),
                );
              },
            ),
        ],
      ),
    );
  }

  /// Icône de la consigne selon le type de virage.
  IconData _iconeVirage(TypeVirage t) {
    switch (t) {
      case TypeVirage.gauche:
        return Icons.turn_left;
      case TypeVirage.droite:
        return Icons.turn_right;
      case TypeVirage.legerGauche:
        return Icons.turn_slight_left;
      case TypeVirage.legerDroite:
        return Icons.turn_slight_right;
      case TypeVirage.demiTour:
        return Icons.u_turn_left;
    }
  }

  /// Bandeau en haut de l'écran, comme sur un GPS de voiture : icône du virage, distance, consigne.
  Widget _bandeauGuidage() {
    Color fond;
    IconData icone;
    String ligne1;
    String ligne2;

    if (_termine) {
      fond = _vertFonce;
      icone = Icons.emoji_events;
      ligne1 = 'Arrivée';
      ligne2 = 'Parcours terminé, bravo !';
    } else if (_position == null || _surParcours == null) {
      fond = const Color(0xFF37413C);
      icone = Icons.gps_not_fixed;
      ligne1 = 'Recherche du GPS…';
      ligne2 = 'Patiente quelques secondes';
    } else {
      final sur = _surParcours!;
      fond = sur ? _vertFonce : _bleu;
      final v = _prochainVirage;
      if (v != null && _distVirageM < 2000) {
        icone = _iconeVirage(v.type);
        ligne1 = Guidage.formaterDistance(_distVirageM);
        ligne2 = v.texte;
      } else if (sur) {
        icone = _distFinM < 300 ? Icons.flag : Icons.straight;
        ligne1 = Guidage.formaterDistance(_distFinM);
        ligne2 = _distFinM < 300 ? 'Arrivée' : 'Continuez tout droit';
      } else {
        icone = Icons.straight;
        ligne1 = Guidage.formaterDistance(_distFinM);
        ligne2 = 'Rejoignez le parcours';
      }
      if (!sur && v != null) {
        ligne2 = '${v.texte} pour rejoindre le parcours';
      }
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: fond,
        borderRadius: BorderRadius.circular(18),
        boxShadow: const [BoxShadow(color: Colors.black54, blurRadius: 10)],
      ),
      child: Row(
        children: [
          Icon(icone, color: Colors.white, size: 52),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  ligne1,
                  style: const TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.bold),
                ),
                Text(
                  ligne2,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: Colors.white, fontSize: 16),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  /// Petit point rouge/vert avec la phrase « Vous êtes / n'êtes pas sur le parcours ».
  Widget _pastilleParcours() {
    final sur = _surParcours ?? false;
    final couleur = sur ? _vert : _rouge;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      decoration: BoxDecoration(
        color: const Color(0xEE111614),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: couleur, width: 1.5),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 14,
            height: 14,
            decoration: BoxDecoration(
              color: couleur,
              shape: BoxShape.circle,
              boxShadow: [BoxShadow(color: couleur.withValues(alpha: 0.7), blurRadius: 8)],
            ),
          ),
          const SizedBox(width: 10),
          Text(
            sur ? 'Vous êtes sur le parcours' : "Vous n'êtes pas sur le parcours",
            style: TextStyle(color: couleur, fontSize: 15, fontWeight: FontWeight.bold),
          ),
        ],
      ),
    );
  }

  /// Panneau du bas pendant le guidage : compact, pour laisser la carte visible.
  Widget _panneauGps() {
    final p = widget.parcours;
    final n = p.traceGPS.length;
    final aDonnees = n > 0 && p.distancesKm.length == n;

    final idx = math.max(0, math.min(_idxProgres, n - 1));
    final parcouru = aDonnees ? p.distancesKm[idx] : 0.0;
    final restant = math.max(0.0, p.distanceKm - parcouru);

    EtapeVille? prochaine;
    for (final e in p.etapes) {
      if (e.distanceKm > parcouru + 0.05) {
        prochaine = e;
        break;
      }
    }

    return Container(
      padding: EdgeInsets.fromLTRB(16, 12, 16, 12 + MediaQuery.of(context).padding.bottom),
      decoration: const BoxDecoration(
        color: Color(0xFF111614),
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        boxShadow: [BoxShadow(color: Colors.black54, blurRadius: 12)],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _stat('Parcouru', '${parcouru.toStringAsFixed(1)} km', Colors.white),
              _stat('Restant', '${restant.toStringAsFixed(1)} km', Colors.white),
              _stat(
                prochaine != null ? 'Prochaine : ${prochaine.nom}' : 'Arrivée',
                prochaine != null
                    ? 'dans ${math.max(0.0, prochaine.distanceKm - parcouru).toStringAsFixed(1)} km'
                    : '${restant.toStringAsFixed(1)} km',
                _vert,
              ),
            ],
          ),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            height: 44,
            child: OutlinedButton.icon(
              style: OutlinedButton.styleFrom(
                foregroundColor: const Color(0xFFFF8A65),
                side: const BorderSide(color: Color(0xFFFF8A65)),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
              ),
              onPressed: _terminerModeGps,
              icon: const Icon(Icons.stop_circle_outlined),
              label: const Text('Arrêter le GPS', style: TextStyle(fontWeight: FontWeight.bold)),
            ),
          ),
        ],
      ),
    );
  }

  Widget _stat(String label, String valeur, Color couleur) {
    return Column(
      children: [
        ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 120),
          child: Text(
            label,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(color: Colors.white60, fontSize: 11),
          ),
        ),
        const SizedBox(height: 4),
        Text(valeur, style: TextStyle(color: couleur, fontSize: 18, fontWeight: FontWeight.bold)),
      ],
    );
  }

  Widget _ligneTroncon(TronconParcours t) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 10),
      decoration: const BoxDecoration(
        border: Border(bottom: BorderSide(color: Colors.white12)),
      ),
      child: Row(
        children: [
          Expanded(
            child: Text(
              '${t.depart} → ${t.arrivee}',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(color: Colors.white, fontSize: 14),
            ),
          ),
          Text('${t.distanceKm.toStringAsFixed(1)} km',
              style: const TextStyle(color: Colors.white70, fontSize: 13)),
          const SizedBox(width: 12),
          Text('+${t.denivelePos} m', style: const TextStyle(color: _vert, fontSize: 13)),
          const SizedBox(width: 8),
          Text('-${t.deniveleNeg} m', style: const TextStyle(color: Color(0xFFFF8A65), fontSize: 13)),
        ],
      ),
    );
  }
}

class _BoutonRond extends StatelessWidget {
  final IconData icone;
  final Color couleur;
  final VoidCallback onTap;

  const _BoutonRond({required this.icone, required this.couleur, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: const Color(0xEE1B211E),
      shape: const CircleBorder(side: BorderSide(color: Colors.white24)),
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Icon(icone, color: couleur, size: 24),
        ),
      ),
    );
  }
}
