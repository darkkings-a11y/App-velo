import 'dart:convert';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;
import 'package:latlong2/latlong.dart';
import 'package:maplibre_gl/maplibre_gl.dart' as ml;
import '../models/parcours.dart';
import '../services/base_gpx_service.dart';
import '../services/geocoding_service.dart';
import '../services/itineraires_osm_service.dart';
import '../services/photo_service.dart';
import '../services/routage_service.dart';
import '../widgets/tuile_parcours.dart';
import 'carte_screen.dart';

/// Écran « Découvrir » façon Komoot : carte plein écran, barre de recherche flottante,
/// choix du type de sortie et de la distance, et TOUS les parcours trouvés tracés sur la carte.
/// Le parcours sélectionné est en vert, les autres en gris ; on choisit en touchant la carte ou la liste.
class DecouvrirScreen extends StatefulWidget {
  const DecouvrirScreen({super.key});

  @override
  State<DecouvrirScreen> createState() => _DecouvrirScreenState();
}

class _DecouvrirScreenState extends State<DecouvrirScreen> {
  static const String _styleUrl = 'https://tiles.openfreemap.org/styles/liberty';
  static const Color _vert = Color(0xFF2ED573);
  static const String _vertCarte = '#1E9E4A';
  static const String _grisCarte = '#7C8A84';
  static final Distance _dist = Distance(roundResult: false);

  final TextEditingController _recherche = TextEditingController();

  ml.MapLibreMapController? _ctl;
  bool _styleOk = false;
  ml.Circle? _cercleMoi;
  LatLng? _positionMoi;

  String _profil = 'balade';
  int _distanceKm = 30;

  // Filtres
  String _forme = 'tous'; // tous, boucle, aller_retour, lineaire
  String _difficulte = 'toutes'; // toutes, Facile, Modéré, Sportif
  int _denivMax = 2000; // 2000 = pas de limite
  List<Parcours> _bruts = []; // tout ce qui a été trouvé, avant filtres

  int get _nbFiltres =>
      (_forme != 'tous' ? 1 : 0) + (_difficulte != 'toutes' ? 1 : 0) + (_denivMax < 2000 ? 1 : 0);

  bool _chargement = false;
  bool _aCherche = false;
  int _numero = 0; // numéro de la recherche en cours (pour ignorer une réponse trop tardive)
  LatLng? _centre;
  String _villeNom = '';
  List<Parcours> _resultats = [];
  int _sel = 0;

  String? _meteoTemp;
  String? _meteoVent;
  int _meteoCode = -1;

  @override
  void dispose() {
    _recherche.dispose();
    super.dispose();
  }

  void _message(String texte) {
    if (!mounted) return;
    final m = ScaffoldMessenger.of(context);
    m.hideCurrentSnackBar();
    m.showSnackBar(SnackBar(content: Text(texte)));
  }

  ml.LatLng _ml(LatLng p) => ml.LatLng(p.latitude, p.longitude);

  // ---------------- Recherche ----------------

  Future<void> _chercherVille() async {
    final nom = _recherche.text.trim();
    if (nom.isEmpty) return;
    FocusScope.of(context).unfocus();
    setState(() => _chargement = true);
    try {
      final coords = await GeocodingService.recupererCoordonnees(nom);
      if (coords == null) {
        _message("Ville introuvable. Vérifie l'orthographe !");
        if (mounted) setState(() => _chargement = false);
        return;
      }
      await _lancer(coords, nom);
    } catch (e) {
      _message(e.toString());
      if (mounted) setState(() => _chargement = false);
    }
  }

  Future<void> _utiliserMaPosition() async {
    FocusScope.of(context).unfocus();
    setState(() => _chargement = true);
    try {
      final actif = await Geolocator.isLocationServiceEnabled();
      if (!actif) {
        _message('Active la localisation de ton téléphone.');
        if (mounted) setState(() => _chargement = false);
        return;
      }
      var perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied) {
        perm = await Geolocator.requestPermission();
      }
      if (perm == LocationPermission.denied) {
        _message('Les permissions de localisation ont été refusées.');
        if (mounted) setState(() => _chargement = false);
        return;
      }
      if (perm == LocationPermission.deniedForever) {
        _message('Les permissions sont définitivement refusées, active-les dans les réglages.');
        if (mounted) setState(() => _chargement = false);
        return;
      }
      final pos = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
      final coords = LatLng(pos.latitude, pos.longitude);
      _recherche.text = 'Ma position actuelle';
      _positionMoi = coords;
      await _poserMoi();
      await _lancer(coords, 'Ma position');
    } catch (e) {
      _message('Impossible de récupérer la position : $e');
      if (mounted) setState(() => _chargement = false);
    }
  }

  /// Lance (ou relance) la recherche autour d'un point, avec le style et la distance choisis.
  Future<void> _lancer(LatLng centre, String nom) async {
    final numero = ++_numero;
    setState(() {
      _chargement = true;
      _aCherche = true;
      _centre = centre;
      _villeNom = nom;
      _resultats = [];
      _bruts = [];
      _sel = 0;
      _meteoTemp = null;
      _meteoVent = null;
      _meteoCode = -1;
    });
    await _dessiner(); // efface les anciens tracés
    try {
      await Future.wait([
        _recupererMeteo(centre),
        _genererParcours(centre, nom, numero),
      ]);
    } catch (e) {
      _message(e.toString());
    } finally {
      if (mounted && numero == _numero) setState(() => _chargement = false);
    }
  }

  Future<void> _genererParcours(LatLng centre, String nom, int numero) async {
    // 1. GPX recommandés de ta base, 2. itinéraires balisés réels d'OpenStreetMap, 3. 3 parcours générés (BRouter).
    String? erreurGeneration;
    final resultats = await Future.wait([
      BaseGpxService.pourVille(centre: centre, profil: _profil, distanceKm: _distanceKm),
      ItinerairesOsmService.pourVille(
        centre: centre,
        profil: _profil,
        distanceKm: _distanceKm,
        villeNom: nom,
      ),
      (_forme == Parcours.formeAllerRetour || _forme == Parcours.formeLineaire
              ? RoutageService.genererOuverts(
                  latitude: centre.latitude,
                  longitude: centre.longitude,
                  distanceKm: _distanceKm,
                  villeNom: nom,
                  forme: _forme,
                  profil: _profil,
                )
              : RoutageService.genererParcours(
                  latitude: centre.latitude,
                  longitude: centre.longitude,
                  distanceKm: _distanceKm,
                  villeNom: nom,
                  profil: _profil,
                ))
          .catchError((e) {
        erreurGeneration = e.toString();
        return <Parcours>[];
      }),
    ]);
    if (!mounted || numero != _numero) return;

    final bruts = <Parcours>[...resultats[0], ...resultats[1], ...resultats[2].take(3)];
    if (bruts.isEmpty) {
      throw erreurGeneration ?? 'Aucun parcours trouvé.';
    }
    final note = [ItinerairesOsmService.note, RoutageService.note].whereType<String>().join('\n');

    setState(() {
      _bruts = bruts;
      _resultats = _filtrer(bruts);
      _sel = 0;
    });
    if (_resultats.isEmpty && _nbFiltres > 0) {
      _message('Aucun parcours ne correspond aux filtres : assouplis-les pour en voir plus.');
    }
    await _dessiner();
    await _cadrer();
    if (note.isNotEmpty) _message(note);
  }

  Future<void> _recupererMeteo(LatLng c) async {
    try {
      final url = Uri.parse(
        'https://api.open-meteo.com/v1/forecast?latitude=${c.latitude}&longitude=${c.longitude}&current_weather=true',
      );
      final r = await http.get(url);
      if (r.statusCode == 200 && mounted) {
        final w = json.decode(r.body)['current_weather'];
        setState(() {
          _meteoTemp = '${w['temperature']}°C';
          _meteoVent = '${w['windspeed']} km/h';
          _meteoCode = (w['weathercode'] as num).toInt();
        });
      }
    } catch (_) {}
  }

  IconData _iconeMeteo(int code) {
    if (code == 0) return Icons.wb_sunny;
    if (code >= 1 && code <= 3) return Icons.wb_cloudy;
    if (code >= 45 && code <= 48) return Icons.cloud;
    if (code >= 51 && code <= 67) return Icons.umbrella;
    if (code >= 71 && code <= 77) return Icons.ac_unit;
    if (code >= 95) return Icons.bolt;
    return Icons.wb_twilight;
  }

  Future<void> _changerProfil(String id) async {
    if (id == _profil) return;
    setState(() => _profil = id);
    final c = _centre;
    if (c != null && !_chargement) await _lancer(c, _villeNom);
  }

  Future<void> _choisirDistance() async {
    var valeur = _distanceKm.toDouble();
    final choix = await showModalBottomSheet<int>(
      context: context,
      backgroundColor: const Color(0xFF151A17),
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (ctx) {
        return StatefulBuilder(
          builder: (ctx, setLocal) {
            return Padding(
              padding: const EdgeInsets.fromLTRB(24, 20, 24, 28),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text('Distance de la sortie',
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Color(0xFFF1F5F2))),
                  const SizedBox(height: 8),
                  Text('${valeur.round()} km',
                      style: const TextStyle(fontSize: 32, fontWeight: FontWeight.bold, color: _vert)),
                  Slider(
                    value: valeur,
                    min: 10,
                    max: 100,
                    divisions: 9,
                    activeColor: _vert,
                    onChanged: (v) => setLocal(() => valeur = v),
                  ),
                  const SizedBox(height: 8),
                  SizedBox(
                    width: double.infinity,
                    height: 48,
                    child: FilledButton(
                      style: FilledButton.styleFrom(
                        backgroundColor: _vert,
                        foregroundColor: const Color(0xFF06210F),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
                      ),
                      onPressed: () => Navigator.pop(ctx, valeur.round()),
                      child: const Text('Appliquer', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
    if (choix == null || choix == _distanceKm) return;
    setState(() => _distanceKm = choix);
    final c = _centre;
    if (c != null && !_chargement) await _lancer(c, _villeNom);
  }

  // ---------------- Filtres ----------------

  List<Parcours> _filtrer(List<Parcours> liste) {
    return liste.where((p) {
      if (_forme != 'tous' && p.forme != _forme) return false;
      if (_difficulte != 'toutes' && p.difficulte != _difficulte) return false;
      if (_denivMax < 2000 && p.denivelePos > _denivMax) return false;
      return true;
    }).toList();
  }

  Future<void> _refiltrer() async {
    setState(() {
      _resultats = _filtrer(_bruts);
      _sel = 0;
    });
    await _dessiner();
    await _cadrer();
  }

  Future<void> _ouvrirFiltres() async {
    var forme = _forme;
    var difficulte = _difficulte;
    var denivMax = _denivMax.toDouble();
    final appliquer = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFF151A17),
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (ctx) {
        return StatefulBuilder(
          builder: (ctx, setLocal) {
            Widget choix(String titre, List<(String, String)> options, String actuel, void Function(String) surChoix) {
              return Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(titre,
                      style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: Color(0xFFF1F5F2))),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      for (final o in options)
                        ChoiceChip(
                          label: Text(o.$2),
                          selected: actuel == o.$1,
                          selectedColor: _vert,
                          backgroundColor: const Color(0xFF1B211E),
                          labelStyle: TextStyle(
                            fontWeight: FontWeight.w600,
                            color: actuel == o.$1 ? const Color(0xFF06210F) : const Color(0xFFF1F5F2),
                          ),
                          side: BorderSide.none,
                          showCheckmark: false,
                          onSelected: (_) => setLocal(() => surChoix(o.$1)),
                        ),
                    ],
                  ),
                ],
              );
            }

            return Padding(
              padding: EdgeInsets.fromLTRB(22, 20, 22, 22 + MediaQuery.of(ctx).viewInsets.bottom),
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Filtres',
                        style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Color(0xFFF1F5F2))),
                    const SizedBox(height: 18),
                    choix(
                      'Type de parcours',
                      const [
                        ('tous', 'Tous'),
                        ('boucle', 'Boucle'),
                        ('aller_retour', 'Aller-retour'),
                        ('lineaire', 'Point à point'),
                      ],
                      forme,
                      (v) => forme = v,
                    ),
                    const SizedBox(height: 6),
                    const Text(
                      'Boucle : on revient au départ par un autre chemin. Aller-retour : on repart par le même chemin. Point à point : l’arrivée est ailleurs.',
                      style: TextStyle(fontSize: 12.5, color: Color(0xFF9AA8A1), height: 1.3),
                    ),
                    const SizedBox(height: 18),
                    choix(
                      'Difficulté',
                      const [
                        ('toutes', 'Toutes'),
                        ('Facile', 'Facile'),
                        ('Modéré', 'Modéré'),
                        ('Sportif', 'Sportif'),
                      ],
                      difficulte,
                      (v) => difficulte = v,
                    ),
                    const SizedBox(height: 18),
                    Text(
                      denivMax >= 2000 ? 'Dénivelé positif : sans limite' : 'Dénivelé positif : ${denivMax.round()} m maximum',
                      style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: Color(0xFFF1F5F2)),
                    ),
                    Slider(
                      value: denivMax,
                      min: 100,
                      max: 2000,
                      divisions: 19,
                      activeColor: _vert,
                      onChanged: (v) => setLocal(() => denivMax = v),
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Expanded(
                          child: OutlinedButton(
                            style: OutlinedButton.styleFrom(
                              foregroundColor: const Color(0xFFF1F5F2),
                              side: const BorderSide(color: Color(0xFF3A4540)),
                              minimumSize: const Size.fromHeight(48),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
                            ),
                            onPressed: () => setLocal(() {
                              forme = 'tous';
                              difficulte = 'toutes';
                              denivMax = 2000;
                            }),
                            child: const Text('Réinitialiser'),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: FilledButton(
                            style: FilledButton.styleFrom(
                              backgroundColor: _vert,
                              foregroundColor: const Color(0xFF06210F),
                              minimumSize: const Size.fromHeight(48),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
                            ),
                            onPressed: () => Navigator.pop(ctx, true),
                            child: const Text('Appliquer', style: TextStyle(fontWeight: FontWeight.bold)),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
    if (appliquer != true) return;

    final formeChangee = forme != _forme;
    setState(() {
      _forme = forme;
      _difficulte = difficulte;
      _denivMax = denivMax.round();
    });
    final c = _centre;
    if (c == null || _chargement) return;
    if (formeChangee) {
      await _lancer(c, _villeNom); // la forme change la façon de calculer les parcours
    } else if (_bruts.isNotEmpty) {
      await _refiltrer();
    }
  }

  // ---------------- Carte ----------------

  Future<void> _surStyleCharge() async {
    _styleOk = true;
    if (_resultats.isNotEmpty) {
      await _dessiner();
      await _cadrer();
    }
    await _poserMoi();
  }

  /// Dessine tous les parcours : les non sélectionnés en gris d'abord, le sélectionné en vert par-dessus.
  /// Chaque parcours porte son numéro (le même que dans la liste).
  Future<void> _dessiner() async {
    final c = _ctl;
    if (c == null || !_styleOk) return;
    try {
      await c.clearLines();
      await c.clearCircles();
      await c.clearSymbols();
      _cercleMoi = null;

      final ordre = <int>[];
      for (var i = 0; i < _resultats.length; i++) {
        if (i != _sel) ordre.add(i);
      }
      if (_sel >= 0 && _sel < _resultats.length) ordre.add(_sel);

      for (final i in ordre) {
        final trace = _resultats[i].traceGPS;
        if (trace.length < 2) continue;
        final choisi = i == _sel;
        final geo = trace.map(_ml).toList();
        await c.addLine(ml.LineOptions(
          geometry: geo,
          lineColor: '#FFFFFF',
          lineWidth: choisi ? 11.0 : 8.0,
          lineOpacity: 0.95,
          lineJoin: 'round',
        ));
        await c.addLine(ml.LineOptions(
          geometry: geo,
          lineColor: choisi ? _vertCarte : _grisCarte,
          lineWidth: choisi ? 6.0 : 4.5,
          lineJoin: 'round',
        ));
      }

      // Pastilles numérotées au milieu de chaque tracé (texte + halo de couleur).
      for (final i in ordre) {
        final trace = _resultats[i].traceGPS;
        if (trace.length < 2) continue;
        final choisi = i == _sel;
        await c.addSymbol(ml.SymbolOptions(
          geometry: _ml(trace[trace.length ~/ 2]),
          textField: '${i + 1}',
          textSize: choisi ? 18.0 : 16.0,
          textColor: choisi ? '#FFFFFF' : '#37413C',
          textHaloColor: choisi ? _vertCarte : '#FFFFFF',
          textHaloWidth: 4.0,
          fontNames: const ['Noto Sans Bold'],
        ));
      }

      // Départ du parcours sélectionné.
      if (_sel >= 0 && _sel < _resultats.length && _resultats[_sel].traceGPS.isNotEmpty) {
        await c.addCircle(ml.CircleOptions(
          geometry: _ml(_resultats[_sel].traceGPS.first),
          circleRadius: 9.0,
          circleColor: _vertCarte,
          circleStrokeColor: '#FFFFFF',
          circleStrokeWidth: 3.0,
        ));
      }
    } catch (_) {
      // le prochain dessin réessaiera
    }
    await _poserMoi();
  }

  /// Point bleu de la position de l'utilisateur.
  Future<void> _poserMoi() async {
    final c = _ctl;
    final pos = _positionMoi;
    if (c == null || !_styleOk || pos == null) return;
    try {
      if (_cercleMoi == null) {
        _cercleMoi = await c.addCircle(ml.CircleOptions(
          geometry: _ml(pos),
          circleRadius: 8.0,
          circleColor: '#2979FF',
          circleStrokeColor: '#FFFFFF',
          circleStrokeWidth: 3.0,
        ));
      } else {
        await c.updateCircle(_cercleMoi!, ml.CircleOptions(geometry: _ml(pos)));
      }
    } catch (_) {}
  }

  /// Cadre la caméra sur tous les parcours (ou sur un seul), en laissant la place à la feuille du bas.
  Future<void> _cadrer({int? seulement}) async {
    final c = _ctl;
    if (c == null || _resultats.isEmpty || !mounted) return;
    final traces = seulement != null
        ? [_resultats[seulement].traceGPS]
        : _resultats.map((p) => p.traceGPS).toList();

    double? minLat, maxLat, minLon, maxLon;
    for (final t in traces) {
      for (final p in t) {
        minLat = minLat == null ? p.latitude : math.min(minLat, p.latitude);
        maxLat = maxLat == null ? p.latitude : math.max(maxLat, p.latitude);
        minLon = minLon == null ? p.longitude : math.min(minLon, p.longitude);
        maxLon = maxLon == null ? p.longitude : math.max(maxLon, p.longitude);
      }
    }
    if (minLat == null || maxLat == null || minLon == null || maxLon == null) return;
    if ((maxLat - minLat).abs() < 0.0003 && (maxLon - minLon).abs() < 0.0003) return;

    final h = MediaQuery.of(context).size.height;
    try {
      await c.animateCamera(
        ml.CameraUpdate.newLatLngBounds(
          ml.LatLngBounds(
            southwest: ml.LatLng(minLat, minLon),
            northeast: ml.LatLng(maxLat, maxLon),
          ),
          left: 40,
          top: 190,
          right: 40,
          bottom: h * 0.46,
        ),
        duration: const Duration(milliseconds: 600),
      );
    } catch (_) {}
  }

  Future<void> _selectionner(int i, {bool cadrer = true}) async {
    if (i < 0 || i >= _resultats.length) return;
    setState(() => _sel = i);
    await _dessiner();
    if (cadrer) await _cadrer(seulement: i);
  }

  /// Toucher la carte près d'un tracé sélectionne ce parcours.
  void _surClicCarte(math.Point<double> point, ml.LatLng ll) {
    if (_resultats.length < 2) return;
    final zoom = _ctl?.cameraPosition?.zoom ?? 12.0;
    final metresParPixel = 156543.03392 * math.cos(ll.latitude * math.pi / 180) / math.pow(2, zoom);
    final seuil = 28 * metresParPixel;
    final tap = LatLng(ll.latitude, ll.longitude);

    int? meilleur;
    double meilleureDist = double.infinity;
    for (var i = 0; i < _resultats.length; i++) {
      final t = _resultats[i].traceGPS;
      if (t.isEmpty) continue;
      final pas = math.max(1, t.length ~/ 600);
      for (var k = 0; k < t.length; k += pas) {
        final d = _dist.as(LengthUnit.Meter, tap, t[k]);
        if (d < meilleureDist) {
          meilleureDist = d;
          meilleur = i;
        }
      }
    }
    if (meilleur != null && meilleureDist < seuil && meilleur != _sel) {
      _selectionner(meilleur, cadrer: false);
    }
  }

  void _ouvrir(Parcours p) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => CarteScreen(parcours: p)));
  }

  // ---------------- Interface ----------------

  @override
  Widget build(BuildContext context) {
    final haut = MediaQuery.of(context).padding.top;

    return Stack(
      children: [
        ml.MapLibreMap(
          styleString: _styleUrl,
          initialCameraPosition: const ml.CameraPosition(target: ml.LatLng(45.75, 4.85), zoom: 11),
          onMapCreated: (c) => _ctl = c,
          onStyleLoadedCallback: _surStyleCharge,
          onMapClick: _surClicCarte,
          compassEnabled: false,
          rotateGesturesEnabled: true,
          tiltGesturesEnabled: false,
        ),

        // Barre de recherche + filtres
        Positioned(
          top: haut + 10,
          left: 12,
          right: 12,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _barreRecherche(),
              const SizedBox(height: 10),
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: [
                    _puce(id: 'route', libelle: 'Route', icone: Icons.directions_bike),
                    const SizedBox(width: 8),
                    _puce(id: 'balade', libelle: 'Balade', icone: Icons.park),
                    const SizedBox(width: 8),
                    _puce(id: 'vtt', libelle: 'VTT', icone: Icons.terrain),
                    const SizedBox(width: 8),
                    _puceDistance(),
                    const SizedBox(width: 8),
                    _puceFiltres(),
                  ],
                ),
              ),
            ],
          ),
        ),

        // Feuille du bas : liste des parcours
        DraggableScrollableSheet(
          initialChildSize: 0.42,
          minChildSize: 0.14,
          maxChildSize: 0.92,
          snap: true,
          snapSizes: const [0.14, 0.42, 0.92],
          builder: (context, scroll) {
            return Container(
              decoration: const BoxDecoration(
                color: Color(0xFF111614),
                borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
                boxShadow: [BoxShadow(color: Color(0x33000000), blurRadius: 14)],
              ),
              child: ListView(
                controller: scroll,
                padding: const EdgeInsets.fromLTRB(14, 10, 14, 24),
                children: [
                  Center(
                    child: Container(
                      width: 40,
                      height: 4,
                      decoration: BoxDecoration(
                        color: const Color(0xFF3A4540),
                        borderRadius: BorderRadius.circular(2),
                      ),
                    ),
                  ),
                  const SizedBox(height: 14),
                  ..._contenuFeuille(),
                ],
              ),
            );
          },
        ),
      ],
    );
  }

  Widget _barreRecherche() {
    return Material(
      elevation: 5,
      color: const Color(0xFF1B211E),
      shape: const StadiumBorder(),
      child: Padding(
        padding: const EdgeInsets.only(left: 16, right: 4),
        child: Row(
          children: [
            const Icon(Icons.search, color: Color(0xFF9AA8A1)),
            const SizedBox(width: 10),
            Expanded(
              child: TextField(
                controller: _recherche,
                textInputAction: TextInputAction.search,
                onSubmitted: (_) => _chercherVille(),
                style: const TextStyle(fontSize: 16, color: Color(0xFFF1F5F2)),
                decoration: const InputDecoration(
                  hintText: 'Où veux-tu rouler ?',
                  hintStyle: TextStyle(color: Color(0xFF7C8A84)),
                  border: InputBorder.none,
                  contentPadding: EdgeInsets.symmetric(vertical: 15),
                  isDense: true,
                ),
              ),
            ),
            IconButton(
              tooltip: 'Autour de moi',
              icon: const Icon(Icons.my_location, color: _vert),
              onPressed: _chargement ? null : _utiliserMaPosition,
            ),
          ],
        ),
      ),
    );
  }

  Widget _puce({required String id, required String libelle, required IconData icone}) {
    final choisi = _profil == id;
    return Material(
      elevation: 3,
      color: choisi ? _vert : const Color(0xFF1B211E),
      shape: const StadiumBorder(),
      child: InkWell(
        customBorder: const StadiumBorder(),
        onTap: () => _changerProfil(id),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icone, size: 18, color: choisi ? const Color(0xFF06210F) : const Color(0xFFF1F5F2)),
              const SizedBox(width: 6),
              Text(
                libelle,
                style: TextStyle(
                  fontWeight: FontWeight.w700,
                  color: choisi ? const Color(0xFF06210F) : const Color(0xFFF1F5F2),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _puceDistance() {
    return Material(
      elevation: 3,
      color: const Color(0xFF1B211E),
      shape: const StadiumBorder(),
      child: InkWell(
        customBorder: const StadiumBorder(),
        onTap: _choisirDistance,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.straighten, size: 18, color: Color(0xFFF1F5F2)),
              const SizedBox(width: 6),
              Text('$_distanceKm km',
                  style: const TextStyle(fontWeight: FontWeight.w700, color: Color(0xFFF1F5F2))),
              const Icon(Icons.keyboard_arrow_down, size: 18, color: Color(0xFFF1F5F2)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _puceFiltres() {
    final actif = _nbFiltres > 0;
    return Material(
      elevation: 3,
      color: actif ? _vert : const Color(0xFF1B211E),
      shape: const StadiumBorder(),
      child: InkWell(
        customBorder: const StadiumBorder(),
        onTap: _ouvrirFiltres,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.tune, size: 18, color: actif ? const Color(0xFF06210F) : const Color(0xFFF1F5F2)),
              const SizedBox(width: 6),
              Text(
                actif ? 'Filtres ($_nbFiltres)' : 'Filtres',
                style: TextStyle(
                  fontWeight: FontWeight.w700,
                  color: actif ? const Color(0xFF06210F) : const Color(0xFFF1F5F2),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  List<Widget> _contenuFeuille() {
    if (_chargement) {
      return [
        const Text('Recherche de parcours…',
            style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold, color: Color(0xFFF1F5F2))),
        const SizedBox(height: 4),
        Text(
          _villeNom.isEmpty ? 'Un instant' : 'Calcul des boucles autour de $_villeNom',
          style: const TextStyle(color: Color(0xFF9AA8A1)),
        ),
        const SizedBox(height: 14),
        const ClipRRect(
          borderRadius: BorderRadius.all(Radius.circular(4)),
          child: LinearProgressIndicator(minHeight: 5, color: _vert, backgroundColor: Color(0xFF2A322E)),
        ),
      ];
    }

    if (!_aCherche) {
      return [
        const Text('Découvre des parcours',
            style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold, color: Color(0xFFF1F5F2))),
        const SizedBox(height: 6),
        const Text(
          'Tape une ville en haut, ou pars de là où tu es. Choisis Route, Balade ou VTT, puis la distance : tous les parcours apparaissent sur la carte.',
          style: TextStyle(color: Color(0xFF9AA8A1), height: 1.35),
        ),
        const SizedBox(height: 16),
        SizedBox(
          height: 48,
          child: FilledButton.icon(
            style: FilledButton.styleFrom(
              backgroundColor: _vert,
              foregroundColor: const Color(0xFF06210F),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
            ),
            onPressed: _utiliserMaPosition,
            icon: const Icon(Icons.my_location),
            label: const Text('Autour de moi', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          ),
        ),
      ];
    }

    if (_resultats.isEmpty) {
      return [
        const Text('Aucun parcours trouvé',
            style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold, color: Color(0xFFF1F5F2))),
        const SizedBox(height: 6),
        Text(
          _bruts.isNotEmpty && _nbFiltres > 0
              ? '${_bruts.length} parcours trouvés, mais aucun ne correspond à tes filtres.'
              : 'Essaie une autre distance, un autre type de sortie ou une ville voisine.',
          style: const TextStyle(color: Color(0xFF9AA8A1)),
        ),
        if (_bruts.isNotEmpty && _nbFiltres > 0) ...[
          const SizedBox(height: 14),
          OutlinedButton.icon(
            style: OutlinedButton.styleFrom(
              foregroundColor: const Color(0xFFF1F5F2),
              side: const BorderSide(color: Color(0xFF3A4540)),
            ),
            onPressed: () {
              setState(() {
                _forme = 'tous';
                _difficulte = 'toutes';
                _denivMax = 2000;
              });
              final c = _centre;
              if (c != null) _lancer(c, _villeNom);
            },
            icon: const Icon(Icons.filter_alt_off),
            label: const Text('Retirer les filtres'),
          ),
        ],
      ];
    }

    return [
      Row(
        children: [
          Expanded(
            child: Text(
              '${_resultats.length} parcours · $_villeNom',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Color(0xFFF1F5F2)),
            ),
          ),
          if (_meteoTemp != null) _pastilleMeteo(),
        ],
      ),
      const SizedBox(height: 12),
      for (var i = 0; i < _resultats.length; i++)
        TuileParcours(
          parcours: _resultats[i],
          numero: i + 1,
          selectionne: i == _sel,
          afficherBouton: true,
          onTap: () => _selectionner(i),
          onOuvrir: () => _ouvrir(_resultats[i]),
        ),
      const SizedBox(height: 6),
      const Text(
        '© OpenStreetMap contributors · © OpenFreeMap\n${PhotoService.credit}',
        textAlign: TextAlign.center,
        style: TextStyle(color: Color(0xFF7C8A84), fontSize: 10),
      ),
    ];
  }

  Widget _pastilleMeteo() {
    return Container(
      margin: const EdgeInsets.only(left: 8),
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: const Color(0xFF1B211E),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFF2A322E)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(_iconeMeteo(_meteoCode), size: 16, color: const Color(0xFFFFC043)),
          const SizedBox(width: 5),
          Text('$_meteoTemp · $_meteoVent',
              style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, color: Color(0xFFF1F5F2))),
        ],
      ),
    );
  }
}
